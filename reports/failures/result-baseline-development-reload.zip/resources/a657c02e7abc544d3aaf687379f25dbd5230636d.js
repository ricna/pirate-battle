import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/GameCanvas.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport11_react_jsxDevRuntime["Fragment"];import { Application } from "/node_modules/.vite/deps/pixi__js.js?v=4e6cb03b";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=4e6cb03b";
import { loadTiledMap } from "/src/game/tiledMap.ts?t=1791840048673";
import { MapRenderer } from "/src/game/mapRenderer.ts";
import { loadGameTextures } from "/src/game/assets.ts";
import { ArenaRenderer } from "/src/game/renderer.ts?t=1791841466585";
import { Simulation } from "/src/game/simulation.ts?t=1791841662802";
import { InputController } from "/src/game/input.ts";
import { audio } from "/src/game/audio.ts";
import { Button, ControlsHelp, Dialog, uiAsset } from "/src/ui/components.tsx";
import "/src/ui/GameCanvas.css?t=1791841426865";
var _jsxFileName = "C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e6cb03b";
var _s = $RefreshSig$();
const commands = [
	{
		action: "left",
		label: "Turn left",
		icon: "turn_left"
	},
	{
		action: "forward",
		label: "Forward",
		icon: "forward"
	},
	{
		action: "right",
		label: "Turn right",
		icon: "turn_right"
	},
	{
		action: "port",
		label: "Left broadside",
		icon: "fire_left"
	},
	{
		action: "front",
		label: "Front cannon",
		icon: "fire_front"
	},
	{
		action: "starboard",
		label: "Right broadside",
		icon: "fire_right"
	}
];
export function GameCanvas({ config, onComplete, onAbandon }) {
	_s();
	const rootRef = useRef(null);
	const viewportRef = useRef(null);
	const canvasRef = useRef(null);
	const queue = useRef(Promise.resolve());
	const simRef = useRef(null);
	const inputRef = useRef(null);
	const callbacks = useRef({
		onComplete,
		onAbandon
	});
	callbacks.current = {
		onComplete,
		onAbandon
	};
	const [status, setStatus] = useState("loading");
	const [error, setError] = useState("");
	const [progress, setProgress] = useState(0);
	const [attempt, setAttempt] = useState(0);
	const [snapshot, setSnapshot] = useState(null);
	const [abandon, setAbandon] = useState(false);
	function pause() {
		const sim = simRef.current;
		if (!sim || sim.status !== "playing") return;
		sim.pause();
		inputRef.current?.setActive(false);
		rootRef.current?.querySelectorAll(".command").forEach((button) => delete button.dataset.held);
		audio.ambience(false, false);
		audio.play("game_pause");
		setSnapshot(sim.snapshot());
	}
	function resume() {
		const sim = simRef.current;
		if (!sim || sim.status !== "paused" || document.hidden) return;
		if (matchMedia("(orientation: portrait)").matches) return;
		sim.resume();
		inputRef.current?.setActive(true);
		audio.play("game_resume");
		setSnapshot(sim.snapshot());
		requestAnimationFrame(() => rootRef.current?.focus());
	}
	useEffect(() => {
		const root = rootRef.current;
		const canvas = canvasRef.current;
		const host = viewportRef.current;
		if (!root || !canvas || !host) throw new Error("The arena requires its authored viewport and canvas.");
		let disposed = false;
		let initialized = false;
		let app = null;
		let mapView = null;
		let arena = null;
		let resize = null;
		let frame = 0;
		let last = 0;
		let accumulator = 0;
		let publishAt = 0;
		let finished = false;
		const abort = new AbortController();
		const manual = new URLSearchParams(location.search).get("test") === "1";
		const instrument = manual || new URLSearchParams(location.search).get("profile") === "1";
		const samples = [];
		let entityPeak = 0;
		const focusLost = () => {
			const sim = simRef.current;
			if (sim?.status === "playing") {
				sim.pause();
				inputRef.current?.setActive(false);
				root.querySelectorAll(".command").forEach((button) => delete button.dataset.held);
				audio.ambience(false, false);
				audio.play("game_pause");
				setSnapshot(sim.snapshot());
			}
			accumulator = 0;
			last = 0;
		};
		const visibility = () => {
			if (document.hidden) focusLost();
		};
		const orientation = () => {
			if (matchMedia("(orientation: portrait)").matches) focusLost();
		};
		function destroy() {
			cancelAnimationFrame(frame);
			resize?.disconnect();
			resize = null;
			inputRef.current?.destroy();
			inputRef.current = null;
			simRef.current = null;
			audio.stop();
			delete window.pirateTest;
			window.removeEventListener("blur", focusLost);
			document.removeEventListener("visibilitychange", visibility);
			window.removeEventListener("resize", orientation);
			arena?.destroy();
			arena = null;
			mapView?.destroy();
			mapView = null;
			if (app) {
				if (app.renderer) app.destroy({ removeView: false }, { children: true });
				else app.stage.destroy({ children: true });
				app = null;
			}
		}
		async function initialize() {
			if (disposed) return;
			setStatus("loading");
			setProgress(0);
			setSnapshot(null);
			const application = new Application();
			app = application;
			try {
				await application.init({
					canvas,
					width: Math.max(1, host.clientWidth),
					height: Math.max(1, host.clientHeight),
					resolution: Math.min(devicePixelRatio, 2),
					autoDensity: true,
					preference: "webgl",
					background: "#123744",
					autoStart: false,
					sharedTicker: false
				});
				initialized = true;
				if (disposed) {
					destroy();
					return;
				}
				const map = await loadTiledMap(abort.signal, (p) => {
					if (!disposed) setProgress(Math.round(p * .6));
				});
				const textures = await loadGameTextures((p) => {
					if (!disposed) setProgress(60 + Math.round(p * 40));
				});
				if (disposed) {
					destroy();
					return;
				}
				const simulation = new Simulation(config, map);
				simRef.current = simulation;
				mapView = new MapRenderer(map);
				application.stage.addChild(mapView.world);
				arena = new ArenaRenderer(mapView.world, simulation, textures);
				const resizeCanvas = () => {
					if (disposed) return;
					application.renderer.resize(Math.max(1, host.clientWidth), Math.max(1, host.clientHeight));
					mapView?.resize(application.screen.width, application.screen.height);
					application.render();
				};
				resize = new ResizeObserver(resizeCanvas);
				resize.observe(host);
				resizeCanvas();
				const requestPause = () => focusLost();
				inputRef.current = new InputController(root, requestPause);
				window.addEventListener("blur", focusLost);
				document.addEventListener("visibilitychange", visibility);
				window.addEventListener("resize", orientation);
				const update = (seconds) => {
					if (simulation.status !== "playing") {
						accumulator = 0;
						return;
					}
					accumulator += seconds;
					while (accumulator + 1e-9 >= config.fixedStep && simulation.status === "playing") {
						simulation.step(config.fixedStep, inputRef.current.read());
						accumulator -= config.fixedStep;
					}
					audio.events(simulation.drainEvents());
					if (simulation.snapshot().status === "ended" && !finished) {
						finished = true;
						inputRef.current?.setActive(false);
						if (instrument) window.pirateMetrics = {
							frames: [...samples],
							entityPeak,
							elapsed: simulation.elapsed,
							score: simulation.score,
							reason: simulation.reason
						};
						audio.stop();
						audio.play(simulation.reason === "time" ? "game_complete" : "game_over");
						callbacks.current.onComplete(simulation.snapshot());
					}
				};
				if (instrument) {
					delete window.pirateMetrics;
					window.pirateTest = {
						observe: (includeFrames = false) => structuredClone({
							snapshot: simulation.snapshot(),
							player: simulation.player,
							enemies: simulation.enemies,
							projectiles: simulation.projectiles,
							effects: simulation.effects.length,
							config,
							colliders: map.colliders,
							frames: includeFrames ? samples : [],
							entityPeak
						}),
						...manual ? { advance: (seconds) => {
							if (!Number.isFinite(seconds) || seconds < 0 || seconds > 180) throw new Error("Invalid test clock advance.");
							update(seconds);
							arena?.draw();
							application.render();
							setSnapshot(simulation.snapshot());
						} } : {}
					};
				}
				function tick(now) {
					if (disposed) return;
					const delta = last ? (now - last) / 1e3 : 0;
					last = now;
					if (simulation.status === "playing") {
						if (!manual) update(Math.min(delta, .25));
						if (instrument && delta > 0 && simulation.elapsed > 5) {
							samples.push(delta * 1e3);
							if (samples.length > 2e4) samples.shift();
						}
						entityPeak = Math.max(entityPeak, simulation.enemies.length + simulation.projectiles.length + simulation.effects.length + 1);
					} else accumulator = 0;
					audio.ambience(simulation.status === "playing", inputRef.current?.read().has("forward") ?? false);
					arena?.draw();
					application.render();
					if (now >= publishAt) {
						setSnapshot(simulation.snapshot());
						publishAt = now + 250;
					}
					frame = requestAnimationFrame(tick);
				}
				setStatus("ready");
				setSnapshot(simulation.snapshot());
				root.focus();
				audio.play("game_start");
				if (document.hidden || matchMedia("(orientation: portrait)").matches) focusLost();
				frame = requestAnimationFrame(tick);
			} catch (cause) {
				destroy();
				if (!disposed) {
					setError(cause instanceof Error ? cause.message : "Unknown asset loading error.");
					setStatus("error");
				}
			}
		}
		queue.current = queue.current.then(initialize);
		return () => {
			disposed = true;
			abort.abort();
			if (initialized) destroy();
		};
	}, [attempt, config]);
	const paused = snapshot?.status === "paused";
	return /* @__PURE__ */ _jsxDEV("section", {
		ref: rootRef,
		className: "game",
		tabIndex: 0,
		"aria-label": "Gameplay controls",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "hud",
				"aria-label": "Match status",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_heart"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Health ", /* @__PURE__ */ _jsxDEV("strong", { children: snapshot?.health ?? config.player.health }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 92
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 79
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_score"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Score ", /* @__PURE__ */ _jsxDEV("strong", { children: snapshot?.score ?? 0 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 91
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 79
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_time"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Time ", /* @__PURE__ */ _jsxDEV("strong", { children: [Math.ceil(snapshot?.remaining ?? config.sessionSeconds), "s"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 89
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 78
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "round-button",
						"aria-label": "Pause game",
						disabled: status !== "ready" || paused,
						onClick: pause,
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: uiAsset("controls/icon_pause"),
							alt: ""
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 120
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: viewportRef,
				className: "arena",
				"aria-busy": status === "loading",
				children: [
					/* @__PURE__ */ _jsxDEV("canvas", {
						ref: canvasRef,
						"aria-label": "Naval battle arena"
					}, attempt, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 7
					}, this),
					status === "loading" && /* @__PURE__ */ _jsxDEV("div", {
						className: "arena-message",
						role: "status",
						children: [
							"Loading arena… ",
							progress,
							"%"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 32
					}, this),
					status === "error" && /* @__PURE__ */ _jsxDEV("div", {
						className: "arena-message",
						role: "alert",
						children: [
							/* @__PURE__ */ _jsxDEV("p", { children: "Unable to load the arena." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 74
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 106
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => setAttempt((v) => v + 1),
								children: "Try again"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: onAbandon,
								children: "Main Menu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 76
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 30
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "combat-footer",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "touch-controls",
					children: commands.map(({ action, label, icon }) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: `round-button command command-${action}`,
						"aria-label": label,
						disabled: status !== "ready" || paused,
						onPointerDown: (e) => {
							e.preventDefault();
							e.currentTarget.setPointerCapture(e.pointerId);
							rootRef.current?.focus();
							inputRef.current?.press(`touch-${e.pointerId}`, action);
							e.currentTarget.dataset.held = "true";
						},
						onPointerUp: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onPointerCancel: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onLostPointerCapture: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onKeyDown: (e) => {
							if (e.code === "Space" || e.code === "Enter") {
								e.preventDefault();
								inputRef.current?.press(`button-${action}`, action);
							}
						},
						onKeyUp: () => inputRef.current?.release(`button-${action}`),
						onBlur: () => inputRef.current?.release(`button-${action}`),
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: uiAsset(`controls/icon_${icon}`),
							alt: ""
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 9
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 62
						}, this)]
					}, action, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 82
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV(ControlsHelp, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "sr-only",
				role: "status",
				children: status === "loading" ? "Loading arena" : paused ? "Game paused" : "Game active"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 5
			}, this),
			paused && /* @__PURE__ */ _jsxDEV(Dialog, {
				title: abandon ? "Leave this battle?" : "Battle paused",
				onClose: () => {
					if (abandon) setAbandon(false);
					else resume();
				},
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: abandon ? "This unfinished battle will not be saved." : "Time, movement and weapons are suspended. Resume when you are ready." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "portrait-hint",
						children: "Rotate your device to landscape before resuming."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 7
					}, this),
					abandon ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setAbandon(false),
						children: "Stay here"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 20
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: onAbandon,
						children: "Leave battle"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 80
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 18
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
						onClick: resume,
						children: "Resume"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setAbandon(true),
						children: "Main Menu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 53
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 16
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 123,
		columnNumber: 10
	}, this);
}
_s(GameCanvas, "d/tNm/6pP1UQuIo+6lDqU6Cfgpk=");
_c = GameCanvas;
var _c;
$RefreshReg$(_c, "GameCanvas");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/GameCanvas.tsx?t=1791841801784";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBRTVDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsYUFBYTtBQUN0QixTQUFTLFFBQVEsY0FBYyxRQUFRLGVBQWU7QUFDdEQsT0FBTzs7OztBQU1QLE1BQU0sV0FBOEQ7Q0FDbEU7RUFBRSxRQUFRO0VBQVEsT0FBTztFQUFhLE1BQU07Q0FBWTtDQUFHO0VBQUUsUUFBUTtFQUFXLE9BQU87RUFBVyxNQUFNO0NBQVU7Q0FDbEg7RUFBRSxRQUFRO0VBQVMsT0FBTztFQUFjLE1BQU07Q0FBYTtDQUFHO0VBQUUsUUFBUTtFQUFRLE9BQU87RUFBa0IsTUFBTTtDQUFZO0NBQzNIO0VBQUUsUUFBUTtFQUFTLE9BQU87RUFBZ0IsTUFBTTtDQUFhO0NBQUc7RUFBRSxRQUFRO0VBQWEsT0FBTztFQUFtQixNQUFNO0NBQWE7QUFDdEk7QUFDQSxPQUFPLFNBQVMsV0FBVyxFQUFFLFFBQVEsWUFBWSxhQUU5Qzs7Q0FDRCxNQUFNLFVBQVUsT0FBb0IsSUFBSTtDQUFHLE1BQU0sY0FBYyxPQUF1QixJQUFJO0NBQzFGLE1BQU0sWUFBWSxPQUEwQixJQUFJO0NBQUcsTUFBTSxRQUFRLE9BQXNCLFFBQVEsUUFBUSxDQUFDO0NBQ3hHLE1BQU0sU0FBUyxPQUEwQixJQUFJO0NBQUcsTUFBTSxXQUFXLE9BQStCLElBQUk7Q0FDcEcsTUFBTSxZQUFZLE9BQU87RUFBRTtFQUFZO0NBQVUsQ0FBQztDQUFHLFVBQVUsVUFBVTtFQUFFO0VBQVk7Q0FBVTtDQUNqRyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXdDLFNBQVM7Q0FDN0UsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FBRyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDO0NBQzdILE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBMEIsSUFBSTtDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzdHLFNBQVMsUUFBUTtFQUFFLE1BQU0sTUFBTSxPQUFPO0VBQVMsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLFdBQVc7RUFDbkYsSUFBSSxNQUFNO0VBQUcsU0FBUyxTQUFTLFVBQVUsS0FBSztFQUFHLFFBQVEsU0FBUyxpQkFBOEIsVUFBVSxDQUFDLENBQUMsU0FBUyxXQUFXLE9BQU8sT0FBTyxRQUFRLElBQUk7RUFDMUosTUFBTSxTQUFTLE9BQU8sS0FBSztFQUFHLE1BQU0sS0FBSyxZQUFZO0VBQUcsWUFBWSxJQUFJLFNBQVMsQ0FBQztDQUFHO0NBQ3ZGLFNBQVMsU0FBUztFQUFFLE1BQU0sTUFBTSxPQUFPO0VBQVMsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLFlBQVksU0FBUyxRQUFRO0VBQ3RHLElBQUksV0FBVyx5QkFBeUIsQ0FBQyxDQUFDLFNBQVM7RUFDbkQsSUFBSSxPQUFPO0VBQUcsU0FBUyxTQUFTLFVBQVUsSUFBSTtFQUFHLE1BQU0sS0FBSyxhQUFhO0VBQUcsWUFBWSxJQUFJLFNBQVMsQ0FBQztFQUN0Ryw0QkFBNEIsUUFBUSxTQUFTLE1BQU0sQ0FBQztDQUFHO0NBQ3pELGdCQUFnQjtFQUNkLE1BQU0sT0FBTyxRQUFRO0VBQVMsTUFBTSxTQUFTLFVBQVU7RUFBUyxNQUFNLE9BQU8sWUFBWTtFQUN6RixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLE1BQU0sSUFBSSxNQUFNLHNEQUFzRDtFQUNyRyxJQUFJLFdBQVc7RUFBTyxJQUFJLGNBQWM7RUFBTyxJQUFJLE1BQTBCO0VBQzdFLElBQUksVUFBOEI7RUFBTSxJQUFJLFFBQThCO0VBQzFFLElBQUksU0FBZ0M7RUFBTSxJQUFJLFFBQVE7RUFBRyxJQUFJLE9BQU87RUFBRyxJQUFJLGNBQWM7RUFBRyxJQUFJLFlBQVk7RUFBRyxJQUFJLFdBQVc7RUFDOUgsTUFBTSxRQUFRLElBQUksZ0JBQWdCO0VBQUcsTUFBTSxTQUFTLElBQUksZ0JBQWdCLFNBQVMsTUFBTSxDQUFDLENBQUMsSUFBSSxNQUFNLE1BQU07RUFDekcsTUFBTSxhQUFhLFVBQVUsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLFNBQVMsTUFBTTtFQUNyRixNQUFNLFVBQW9CLENBQUM7RUFBRyxJQUFJLGFBQWE7RUFDL0MsTUFBTSxrQkFBa0I7R0FBRSxNQUFNLE1BQU0sT0FBTztHQUFTLElBQUksS0FBSyxXQUFXLFdBQVc7SUFDbkYsSUFBSSxNQUFNO0lBQUcsU0FBUyxTQUFTLFVBQVUsS0FBSztJQUFHLEtBQU0saUJBQThCLFVBQVUsQ0FBQyxDQUFDLFNBQVMsV0FBVyxPQUFPLE9BQU8sUUFBUSxJQUFJO0lBQy9JLE1BQU0sU0FBUyxPQUFPLEtBQUs7SUFBRyxNQUFNLEtBQUssWUFBWTtJQUFHLFlBQVksSUFBSSxTQUFTLENBQUM7R0FBRztHQUNyRixjQUFjO0dBQUcsT0FBTztFQUMxQjtFQUNBLE1BQU0sbUJBQW1CO0dBQUUsSUFBSSxTQUFTLFFBQVEsVUFBVTtFQUFHO0VBQzdELE1BQU0sb0JBQW9CO0dBQUUsSUFBSSxXQUFXLHlCQUF5QixDQUFDLENBQUMsU0FBUyxVQUFVO0VBQUc7RUFDNUYsU0FBUyxVQUFVO0dBQ2pCLHFCQUFxQixLQUFLO0dBQUcsUUFBUSxXQUFXO0dBQUcsU0FBUztHQUFNLFNBQVMsU0FBUyxRQUFRO0dBQUcsU0FBUyxVQUFVO0dBQ2xILE9BQU8sVUFBVTtHQUFNLE1BQU0sS0FBSztHQUFHLE9BQU8sT0FBTztHQUNuRCxPQUFPLG9CQUFvQixRQUFRLFNBQVM7R0FBRyxTQUFTLG9CQUFvQixvQkFBb0IsVUFBVTtHQUMxRyxPQUFPLG9CQUFvQixVQUFVLFdBQVc7R0FDaEQsT0FBTyxRQUFRO0dBQUcsUUFBUTtHQUFNLFNBQVMsUUFBUTtHQUFHLFVBQVU7R0FDOUQsSUFBSSxLQUFLO0lBQUUsSUFBSSxJQUFJLFVBQVUsSUFBSSxRQUFRLEVBQUUsWUFBWSxNQUFNLEdBQUcsRUFBRSxVQUFVLEtBQUssQ0FBQztTQUFRLElBQUksTUFBTSxRQUFRLEVBQUUsVUFBVSxLQUFLLENBQUM7SUFBRyxNQUFNO0dBQU07RUFDL0k7RUFDQSxlQUFlLGFBQWE7R0FDMUIsSUFBSSxVQUFVO0dBQVEsVUFBVSxTQUFTO0dBQUcsWUFBWSxDQUFDO0dBQUcsWUFBWSxJQUFJO0dBQzVFLE1BQU0sY0FBYyxJQUFJLFlBQVk7R0FBRyxNQUFNO0dBQzdDLElBQUk7SUFDRixNQUFNLFlBQVksS0FBSztLQUFVO0tBQVMsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFNLFdBQVc7S0FBRyxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQU0sWUFBWTtLQUNySCxZQUFZLEtBQUssSUFBSSxrQkFBa0IsQ0FBQztLQUFHLGFBQWE7S0FBTSxZQUFZO0tBQVMsWUFBWTtLQUFXLFdBQVc7S0FBTyxjQUFjO0lBQU0sQ0FBQztJQUNuSixjQUFjO0lBQU0sSUFBSSxVQUFVO0tBQUUsUUFBUTtLQUFHO0lBQVE7SUFDdkQsTUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNLFNBQVMsTUFBTTtLQUFFLElBQUksQ0FBQyxVQUFVLFlBQVksS0FBSyxNQUFNLElBQUksRUFBRyxDQUFDO0lBQUcsQ0FBQztJQUN4RyxNQUFNLFdBQVcsTUFBTSxrQkFBa0IsTUFBTTtLQUFFLElBQUksQ0FBQyxVQUFVLFlBQVksS0FBSyxLQUFLLE1BQU0sSUFBSSxFQUFFLENBQUM7SUFBRyxDQUFDO0lBQ3ZHLElBQUksVUFBVTtLQUFFLFFBQVE7S0FBRztJQUFRO0lBQ25DLE1BQU0sYUFBYSxJQUFJLFdBQVcsUUFBUSxHQUFHO0lBQUcsT0FBTyxVQUFVO0lBQ2pFLFVBQVUsSUFBSSxZQUFZLEdBQUc7SUFBRyxZQUFZLE1BQU0sU0FBUyxRQUFRLEtBQUs7SUFDeEUsUUFBUSxJQUFJLGNBQWMsUUFBUSxPQUFPLFlBQVksUUFBUTtJQUM3RCxNQUFNLHFCQUFxQjtLQUFFLElBQUksVUFBVTtLQUN6QyxZQUFZLFNBQVMsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksR0FBRyxLQUFNLFlBQVksQ0FBQztLQUMzRixTQUFTLE9BQU8sWUFBWSxPQUFPLE9BQU8sWUFBWSxPQUFPLE1BQU07S0FBRyxZQUFZLE9BQU87SUFBRztJQUM5RixTQUFTLElBQUksZUFBZSxZQUFZO0lBQUcsT0FBTyxRQUFRLElBQUs7SUFBRyxhQUFhO0lBQy9FLE1BQU0scUJBQXFCLFVBQVU7SUFBRyxTQUFTLFVBQVUsSUFBSSxnQkFBZ0IsTUFBTyxZQUFZO0lBQ2xHLE9BQU8saUJBQWlCLFFBQVEsU0FBUztJQUFHLFNBQVMsaUJBQWlCLG9CQUFvQixVQUFVO0lBQ3BHLE9BQU8saUJBQWlCLFVBQVUsV0FBVztJQUM3QyxNQUFNLFVBQVUsWUFBb0I7S0FDbEMsSUFBSSxXQUFXLFdBQVcsV0FBVztNQUFFLGNBQWM7TUFBRztLQUFRO0tBQ2hFLGVBQWU7S0FDZixPQUFPLGNBQWMsUUFBUSxPQUFPLGFBQWEsV0FBVyxXQUFXLFdBQVc7TUFDaEYsV0FBVyxLQUFLLE9BQU8sV0FBVyxTQUFTLFFBQVMsS0FBSyxDQUFDO01BQUcsZUFBZSxPQUFPO0tBQ3JGO0tBQ0EsTUFBTSxPQUFPLFdBQVcsWUFBWSxDQUFDO0tBQ3JDLElBQUksV0FBVyxTQUFTLENBQUMsQ0FBQyxXQUFXLFdBQVcsQ0FBQyxVQUFVO01BQUUsV0FBVztNQUFNLFNBQVMsU0FBUyxVQUFVLEtBQUs7TUFDN0csSUFBSSxZQUFZLE9BQU8sZ0JBQWdCO09BQUUsUUFBUSxDQUFDLEdBQUcsT0FBTztPQUFHO09BQVksU0FBUyxXQUFXO09BQVMsT0FBTyxXQUFXO09BQU8sUUFBUSxXQUFXO01BQU87TUFDM0osTUFBTSxLQUFLO01BQUcsTUFBTSxLQUFLLFdBQVcsV0FBVyxTQUFTLGtCQUFrQixXQUFXO01BQUcsVUFBVSxRQUFRLFdBQVcsV0FBVyxTQUFTLENBQUM7S0FBRztJQUNqSjtJQUNBLElBQUksWUFBWTtLQUFFLE9BQU8sT0FBTztLQUFlLE9BQU8sYUFBYTtNQUFFLFVBQVUsZ0JBQWdCLFVBQVUsZ0JBQWdCO09BQUUsVUFBVSxXQUFXLFNBQVM7T0FBRyxRQUFRLFdBQVc7T0FDN0ssU0FBUyxXQUFXO09BQVMsYUFBYSxXQUFXO09BQWEsU0FBUyxXQUFXLFFBQVE7T0FDOUY7T0FBUSxXQUFXLElBQUk7T0FBVyxRQUFRLGdCQUFnQixVQUFVLENBQUM7T0FBRztNQUFXLENBQUM7TUFDcEYsR0FBSSxTQUFTLEVBQUUsVUFBVSxZQUFvQjtPQUFFLElBQUksQ0FBQyxPQUFPLFNBQVMsT0FBTyxLQUFLLFVBQVUsS0FBSyxVQUFVLEtBQUssTUFBTSxJQUFJLE1BQU0sNkJBQTZCO09BQ3pKLE9BQU8sT0FBTztPQUFHLE9BQU8sS0FBSztPQUFHLFlBQVksT0FBTztPQUFHLFlBQVksV0FBVyxTQUFTLENBQUM7TUFBRyxFQUFFLElBQUksQ0FBQztLQUFHO0lBQUc7SUFDM0csU0FBUyxLQUFLLEtBQWE7S0FDekIsSUFBSSxVQUFVO0tBQ2QsTUFBTSxRQUFRLFFBQVEsTUFBTSxRQUFRLE1BQU87S0FBRyxPQUFPO0tBQ3JELElBQUksV0FBVyxXQUFXLFdBQVc7TUFDbkMsSUFBSSxDQUFDLFFBQVEsT0FBTyxLQUFLLElBQUksT0FBTyxHQUFJLENBQUM7TUFDekMsSUFBSSxjQUFjLFFBQVEsS0FBSyxXQUFXLFVBQVUsR0FBRztPQUFFLFFBQVEsS0FBSyxRQUFRLEdBQUk7T0FBRyxJQUFJLFFBQVEsU0FBUyxLQUFPLFFBQVEsTUFBTTtNQUFHO01BQ2xJLGFBQWEsS0FBSyxJQUFJLFlBQVksV0FBVyxRQUFRLFNBQVMsV0FBVyxZQUFZLFNBQVMsV0FBVyxRQUFRLFNBQVMsQ0FBQztLQUM3SCxPQUFPLGNBQWM7S0FDckIsTUFBTSxTQUFTLFdBQVcsV0FBVyxXQUFXLFNBQVMsU0FBUyxLQUFLLENBQUMsQ0FBQyxJQUFJLFNBQVMsS0FBSyxLQUFLO0tBQ2hHLE9BQU8sS0FBSztLQUFHLFlBQVksT0FBTztLQUNsQyxJQUFJLE9BQU8sV0FBVztNQUFFLFlBQVksV0FBVyxTQUFTLENBQUM7TUFBRyxZQUFZLE1BQU07S0FBSztLQUNuRixRQUFRLHNCQUFzQixJQUFJO0lBQ3BDO0lBQ0EsVUFBVSxPQUFPO0lBQUcsWUFBWSxXQUFXLFNBQVMsQ0FBQztJQUFHLEtBQU0sTUFBTTtJQUFHLE1BQU0sS0FBSyxZQUFZO0lBQzlGLElBQUksU0FBUyxVQUFVLFdBQVcseUJBQXlCLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEYsUUFBUSxzQkFBc0IsSUFBSTtHQUNwQyxTQUFTLE9BQU87SUFBRSxRQUFRO0lBQUcsSUFBSSxDQUFDLFVBQVU7S0FBRSxTQUFTLGlCQUFpQixRQUFRLE1BQU0sVUFBVSw4QkFBOEI7S0FBRyxVQUFVLE9BQU87SUFBRztHQUFFO0VBQ3pKO0VBQ0EsTUFBTSxVQUFVLE1BQU0sUUFBUSxLQUFLLFVBQVU7RUFDN0MsYUFBYTtHQUFFLFdBQVc7R0FBTSxNQUFNLE1BQU07R0FBRyxJQUFJLGFBQWEsUUFBUTtFQUFHO0NBQzdFLEdBQUcsQ0FBQyxTQUFTLE1BQU0sQ0FBQztDQUNwQixNQUFNLFNBQVMsVUFBVSxXQUFXO0NBQ3BDLE9BQU8sd0JBQUMsV0FBRDtFQUFTLEtBQUs7RUFBUyxXQUFVO0VBQU8sVUFBVTtFQUFHLGNBQVc7WUFBaEU7R0FDTCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFNLGNBQVc7Y0FBbkM7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF5Qix3QkFBQyxPQUFEO1FBQUssS0FBSyxRQUFRLGdCQUFnQjtRQUFHLEtBQUk7T0FBSTs7Ozs7T0FBQztPQUFDLHdCQUFDLFFBQUQsYUFBTSxXQUFPLHdCQUFDLFVBQUQsWUFBUyxVQUFVLFVBQVUsT0FBTyxPQUFPLE9BQWU7Ozs7ZUFBTzs7Ozs7TUFBTTs7Ozs7O0tBQzVKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQXlCLHdCQUFDLE9BQUQ7UUFBSyxLQUFLLFFBQVEsZ0JBQWdCO1FBQUcsS0FBSTtPQUFJOzs7OztPQUFDO09BQUMsd0JBQUMsUUFBRCxhQUFNLFVBQU0sd0JBQUMsVUFBRCxZQUFTLFVBQVUsU0FBUyxFQUFVOzs7O2VBQU87Ozs7O01BQU07Ozs7OztLQUN2SSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF5Qix3QkFBQyxPQUFEO1FBQUssS0FBSyxRQUFRLGVBQWU7UUFBRyxLQUFJO09BQUk7Ozs7O09BQUM7T0FBQyx3QkFBQyxRQUFELGFBQU0sU0FBSyx3QkFBQyxVQUFELGFBQVMsS0FBSyxLQUFLLFVBQVUsYUFBYSxPQUFPLGNBQWMsR0FBRSxHQUFTOzs7O2VBQU87Ozs7O01BQU07Ozs7OztLQUN6Syx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFlLGNBQVc7TUFBYSxVQUFVLFdBQVcsV0FBVztNQUFRLFNBQVM7Z0JBQU8sd0JBQUMsT0FBRDtPQUFLLEtBQUssUUFBUSxxQkFBcUI7T0FBRyxLQUFJO01BQUk7Ozs7O0tBQVM7Ozs7O0lBQ3RLOzs7Ozs7R0FDUix3QkFBQyxPQUFEO0lBQUssS0FBSztJQUFhLFdBQVU7SUFBUSxhQUFXLFdBQVc7Y0FBL0Q7S0FDRSx3QkFBQyxVQUFEO01BQXNCLEtBQUs7TUFBVyxjQUFXO0tBQXNCLEdBQTFEOzs7O1lBQTBEO0tBQ3RFLFdBQVcsYUFBYSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFnQixNQUFLO2dCQUFwQztPQUE2QztPQUFnQjtPQUFTO01BQU07Ozs7OztLQUNwRyxXQUFXLFdBQVcsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBZ0IsTUFBSztnQkFBcEM7T0FBNEMsd0JBQUMsS0FBRCxZQUFHLDRCQUE0Qjs7Ozs7T0FBQyx3QkFBQyxLQUFELFlBQUksTUFBUzs7Ozs7T0FDOUcsd0JBQUMsUUFBRDtRQUFRLGVBQWUsWUFBWSxNQUFNLElBQUksQ0FBQztrQkFBRztPQUFpQjs7Ozs7T0FBQyx3QkFBQyxRQUFEO1FBQVEsU0FBUztrQkFBVztPQUFpQjs7Ozs7TUFBTTs7Ozs7O0lBQ3JIOzs7Ozs7R0FDTCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWtCLFNBQVMsS0FBSyxFQUFFLFFBQVEsT0FBTyxXQUFXLHdCQUFDLFVBQUQ7TUFBcUIsTUFBSztNQUNuRyxXQUFXLGdDQUFnQztNQUFVLGNBQVk7TUFBTyxVQUFVLFdBQVcsV0FBVztNQUN4RyxnQkFBZ0IsTUFBTTtPQUFFLEVBQUUsZUFBZTtPQUFHLEVBQUUsY0FBYyxrQkFBa0IsRUFBRSxTQUFTO09BQUcsUUFBUSxTQUFTLE1BQU07T0FDakgsU0FBUyxTQUFTLE1BQU0sU0FBUyxFQUFFLGFBQWEsTUFBTTtPQUFHLEVBQUUsY0FBYyxRQUFRLE9BQU87TUFBUTtNQUNsRyxjQUFjLE1BQU07T0FBRSxTQUFTLFNBQVMsUUFBUSxTQUFTLEVBQUUsV0FBVztPQUFHLE9BQU8sRUFBRSxjQUFjLFFBQVE7TUFBTTtNQUM5RyxrQkFBa0IsTUFBTTtPQUFFLFNBQVMsU0FBUyxRQUFRLFNBQVMsRUFBRSxXQUFXO09BQUcsT0FBTyxFQUFFLGNBQWMsUUFBUTtNQUFNO01BQ2xILHVCQUF1QixNQUFNO09BQUUsU0FBUyxTQUFTLFFBQVEsU0FBUyxFQUFFLFdBQVc7T0FBRyxPQUFPLEVBQUUsY0FBYyxRQUFRO01BQU07TUFDdkgsWUFBWSxNQUFNO09BQUUsSUFBSSxFQUFFLFNBQVMsV0FBVyxFQUFFLFNBQVMsU0FBUztRQUFFLEVBQUUsZUFBZTtRQUFHLFNBQVMsU0FBUyxNQUFNLFVBQVUsVUFBVSxNQUFNO09BQUc7TUFBRTtNQUMvSSxlQUFlLFNBQVMsU0FBUyxRQUFRLFVBQVUsUUFBUTtNQUFHLGNBQWMsU0FBUyxTQUFTLFFBQVEsVUFBVSxRQUFRO2dCQVIvQyxDQVN6RSx3QkFBQyxPQUFEO09BQUssS0FBSyxRQUFRLGlCQUFpQixNQUFNO09BQUcsS0FBSTtNQUFJOzs7O2dCQUFDLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2NBQVM7UUFUSzs7OztZQVNMLENBQUM7SUFBTzs7OztjQUMzRix3QkFBQyxjQUFELENBQWU7Ozs7WUFDVDs7Ozs7O0dBQ1Isd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBVSxNQUFLO2NBQVUsV0FBVyxZQUFZLGtCQUFrQixTQUFTLGdCQUFnQjtHQUFpQjs7Ozs7R0FDeEgsVUFBVSx3QkFBQyxRQUFEO0lBQVEsT0FBTyxVQUFVLHVCQUF1QjtJQUFpQixlQUFlO0tBQUUsSUFBSSxTQUFTLFdBQVcsS0FBSztVQUFRLE9BQU87SUFBRztjQUFqSTtLQUNULHdCQUFDLEtBQUQsWUFBSSxVQUFVLDhDQUE4Qyx1RUFBMEU7Ozs7O0tBQ3RJLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnQjtLQUFtRDs7Ozs7S0FDL0UsVUFBVSxnREFBRSx3QkFBQyxRQUFEO01BQVEsZUFBZSxXQUFXLEtBQUs7Z0JBQUc7S0FBaUI7Ozs7ZUFBQyx3QkFBQyxRQUFEO01BQVEsU0FBUztnQkFBVztLQUFvQjs7OzthQUFHOzs7O2dCQUN4SCxnREFBRSx3QkFBQyxRQUFEO01BQVEsU0FBUztnQkFBUTtLQUFjOzs7O2VBQUMsd0JBQUMsUUFBRDtNQUFRLGVBQWUsV0FBVyxJQUFJO2dCQUFHO0tBQWlCOzs7O2FBQUc7Ozs7O0lBQ3JHOzs7Ozs7RUFDRDs7Ozs7O0FBQ1giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2FtZUNhbnZhcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwbGljYXRpb24gfSBmcm9tICdwaXhpLmpzJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgR2FtZUNvbmZpZyB9IGZyb20gJy4uL2dhbWUvY29uZmlnJztcbmltcG9ydCB7IGxvYWRUaWxlZE1hcCB9IGZyb20gJy4uL2dhbWUvdGlsZWRNYXAnO1xuaW1wb3J0IHsgTWFwUmVuZGVyZXIgfSBmcm9tICcuLi9nYW1lL21hcFJlbmRlcmVyJztcbmltcG9ydCB7IGxvYWRHYW1lVGV4dHVyZXMgfSBmcm9tICcuLi9nYW1lL2Fzc2V0cyc7XG5pbXBvcnQgeyBBcmVuYVJlbmRlcmVyIH0gZnJvbSAnLi4vZ2FtZS9yZW5kZXJlcic7XG5pbXBvcnQgeyBTaW11bGF0aW9uIH0gZnJvbSAnLi4vZ2FtZS9zaW11bGF0aW9uJztcbmltcG9ydCB0eXBlIHsgQWN0aW9uLCBTbmFwc2hvdCB9IGZyb20gJy4uL2dhbWUvc2ltdWxhdGlvbic7XG5pbXBvcnQgeyBJbnB1dENvbnRyb2xsZXIgfSBmcm9tICcuLi9nYW1lL2lucHV0JztcbmltcG9ydCB7IGF1ZGlvIH0gZnJvbSAnLi4vZ2FtZS9hdWRpbyc7XG5pbXBvcnQgeyBCdXR0b24sIENvbnRyb2xzSGVscCwgRGlhbG9nLCB1aUFzc2V0IH0gZnJvbSAnLi9jb21wb25lbnRzJztcbmltcG9ydCAnLi9HYW1lQ2FudmFzLmNzcyc7XG5leHBvcnQgaW50ZXJmYWNlIEdhbWVPYnNlcnZhdGlvbiB7IHNuYXBzaG90OiBTbmFwc2hvdDsgcGxheWVyOiBTaW11bGF0aW9uWydwbGF5ZXInXTsgZW5lbWllczogU2ltdWxhdGlvblsnZW5lbWllcyddO1xuICBwcm9qZWN0aWxlczogU2ltdWxhdGlvblsncHJvamVjdGlsZXMnXTsgZWZmZWN0czogbnVtYmVyOyBjb25maWc6IEdhbWVDb25maWc7XG4gIGNvbGxpZGVyczogU2ltdWxhdGlvblsnbWFwJ11bJ2NvbGxpZGVycyddOyBmcmFtZXM6IG51bWJlcltdOyBlbnRpdHlQZWFrOiBudW1iZXIgfVxuZGVjbGFyZSBnbG9iYWwgeyBpbnRlcmZhY2UgV2luZG93IHsgcGlyYXRlVGVzdD86IHsgb2JzZXJ2ZTogKGluY2x1ZGVGcmFtZXM/OiBib29sZWFuKSA9PiBHYW1lT2JzZXJ2YXRpb247IGFkdmFuY2U/OiAoc2Vjb25kczogbnVtYmVyKSA9PiB2b2lkIH07XG4gIHBpcmF0ZU1ldHJpY3M/OiB7IGZyYW1lczogbnVtYmVyW107IGVudGl0eVBlYWs6IG51bWJlcjsgZWxhcHNlZDogbnVtYmVyOyBzY29yZTogbnVtYmVyOyByZWFzb246IHN0cmluZyB8IG51bGwgfSB9IH1cbmNvbnN0IGNvbW1hbmRzOiB7IGFjdGlvbjogQWN0aW9uOyBsYWJlbDogc3RyaW5nOyBpY29uOiBzdHJpbmcgfVtdID0gW1xuICB7IGFjdGlvbjogJ2xlZnQnLCBsYWJlbDogJ1R1cm4gbGVmdCcsIGljb246ICd0dXJuX2xlZnQnIH0sIHsgYWN0aW9uOiAnZm9yd2FyZCcsIGxhYmVsOiAnRm9yd2FyZCcsIGljb246ICdmb3J3YXJkJyB9LFxuICB7IGFjdGlvbjogJ3JpZ2h0JywgbGFiZWw6ICdUdXJuIHJpZ2h0JywgaWNvbjogJ3R1cm5fcmlnaHQnIH0sIHsgYWN0aW9uOiAncG9ydCcsIGxhYmVsOiAnTGVmdCBicm9hZHNpZGUnLCBpY29uOiAnZmlyZV9sZWZ0JyB9LFxuICB7IGFjdGlvbjogJ2Zyb250JywgbGFiZWw6ICdGcm9udCBjYW5ub24nLCBpY29uOiAnZmlyZV9mcm9udCcgfSwgeyBhY3Rpb246ICdzdGFyYm9hcmQnLCBsYWJlbDogJ1JpZ2h0IGJyb2Fkc2lkZScsIGljb246ICdmaXJlX3JpZ2h0JyB9LFxuXTtcbmV4cG9ydCBmdW5jdGlvbiBHYW1lQ2FudmFzKHsgY29uZmlnLCBvbkNvbXBsZXRlLCBvbkFiYW5kb24gfToge1xuICBjb25maWc6IEdhbWVDb25maWc7IG9uQ29tcGxldGU6IChzbmFwc2hvdDogU25hcHNob3QpID0+IHZvaWQ7IG9uQWJhbmRvbjogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3Qgcm9vdFJlZiA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7IGNvbnN0IHZpZXdwb3J0UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50PihudWxsKTsgY29uc3QgcXVldWUgPSB1c2VSZWY8UHJvbWlzZTx2b2lkPj4oUHJvbWlzZS5yZXNvbHZlKCkpO1xuICBjb25zdCBzaW1SZWYgPSB1c2VSZWY8U2ltdWxhdGlvbiB8IG51bGw+KG51bGwpOyBjb25zdCBpbnB1dFJlZiA9IHVzZVJlZjxJbnB1dENvbnRyb2xsZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgY2FsbGJhY2tzID0gdXNlUmVmKHsgb25Db21wbGV0ZSwgb25BYmFuZG9uIH0pOyBjYWxsYmFja3MuY3VycmVudCA9IHsgb25Db21wbGV0ZSwgb25BYmFuZG9uIH07XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTwnbG9hZGluZycgfCAncmVhZHknIHwgJ2Vycm9yJz4oJ2xvYWRpbmcnKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7IGNvbnN0IFtwcm9ncmVzcywgc2V0UHJvZ3Jlc3NdID0gdXNlU3RhdGUoMCk7IGNvbnN0IFthdHRlbXB0LCBzZXRBdHRlbXB0XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbc25hcHNob3QsIHNldFNuYXBzaG90XSA9IHVzZVN0YXRlPFNuYXBzaG90IHwgbnVsbD4obnVsbCk7IGNvbnN0IFthYmFuZG9uLCBzZXRBYmFuZG9uXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgZnVuY3Rpb24gcGF1c2UoKSB7IGNvbnN0IHNpbSA9IHNpbVJlZi5jdXJyZW50OyBpZiAoIXNpbSB8fCBzaW0uc3RhdHVzICE9PSAncGxheWluZycpIHJldHVybjtcbiAgICBzaW0ucGF1c2UoKTsgaW5wdXRSZWYuY3VycmVudD8uc2V0QWN0aXZlKGZhbHNlKTsgcm9vdFJlZi5jdXJyZW50Py5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PignLmNvbW1hbmQnKS5mb3JFYWNoKChidXR0b24pID0+IGRlbGV0ZSBidXR0b24uZGF0YXNldC5oZWxkKTtcbiAgICBhdWRpby5hbWJpZW5jZShmYWxzZSwgZmFsc2UpOyBhdWRpby5wbGF5KCdnYW1lX3BhdXNlJyk7IHNldFNuYXBzaG90KHNpbS5zbmFwc2hvdCgpKTsgfVxuICBmdW5jdGlvbiByZXN1bWUoKSB7IGNvbnN0IHNpbSA9IHNpbVJlZi5jdXJyZW50OyBpZiAoIXNpbSB8fCBzaW0uc3RhdHVzICE9PSAncGF1c2VkJyB8fCBkb2N1bWVudC5oaWRkZW4pIHJldHVybjtcbiAgICBpZiAobWF0Y2hNZWRpYSgnKG9yaWVudGF0aW9uOiBwb3J0cmFpdCknKS5tYXRjaGVzKSByZXR1cm47XG4gICAgc2ltLnJlc3VtZSgpOyBpbnB1dFJlZi5jdXJyZW50Py5zZXRBY3RpdmUodHJ1ZSk7IGF1ZGlvLnBsYXkoJ2dhbWVfcmVzdW1lJyk7IHNldFNuYXBzaG90KHNpbS5zbmFwc2hvdCgpKTtcbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gcm9vdFJlZi5jdXJyZW50Py5mb2N1cygpKTsgfVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSByb290UmVmLmN1cnJlbnQ7IGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50OyBjb25zdCBob3N0ID0gdmlld3BvcnRSZWYuY3VycmVudDtcbiAgICBpZiAoIXJvb3QgfHwgIWNhbnZhcyB8fCAhaG9zdCkgdGhyb3cgbmV3IEVycm9yKCdUaGUgYXJlbmEgcmVxdWlyZXMgaXRzIGF1dGhvcmVkIHZpZXdwb3J0IGFuZCBjYW52YXMuJyk7XG4gICAgbGV0IGRpc3Bvc2VkID0gZmFsc2U7IGxldCBpbml0aWFsaXplZCA9IGZhbHNlOyBsZXQgYXBwOiBBcHBsaWNhdGlvbiB8IG51bGwgPSBudWxsO1xuICAgIGxldCBtYXBWaWV3OiBNYXBSZW5kZXJlciB8IG51bGwgPSBudWxsOyBsZXQgYXJlbmE6IEFyZW5hUmVuZGVyZXIgfCBudWxsID0gbnVsbDtcbiAgICBsZXQgcmVzaXplOiBSZXNpemVPYnNlcnZlciB8IG51bGwgPSBudWxsOyBsZXQgZnJhbWUgPSAwOyBsZXQgbGFzdCA9IDA7IGxldCBhY2N1bXVsYXRvciA9IDA7IGxldCBwdWJsaXNoQXQgPSAwOyBsZXQgZmluaXNoZWQgPSBmYWxzZTtcbiAgICBjb25zdCBhYm9ydCA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTsgY29uc3QgbWFudWFsID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldCgndGVzdCcpID09PSAnMSc7XG4gICAgY29uc3QgaW5zdHJ1bWVudCA9IG1hbnVhbCB8fCBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCkuZ2V0KCdwcm9maWxlJykgPT09ICcxJztcbiAgICBjb25zdCBzYW1wbGVzOiBudW1iZXJbXSA9IFtdOyBsZXQgZW50aXR5UGVhayA9IDA7XG4gICAgY29uc3QgZm9jdXNMb3N0ID0gKCkgPT4geyBjb25zdCBzaW0gPSBzaW1SZWYuY3VycmVudDsgaWYgKHNpbT8uc3RhdHVzID09PSAncGxheWluZycpIHtcbiAgICAgIHNpbS5wYXVzZSgpOyBpbnB1dFJlZi5jdXJyZW50Py5zZXRBY3RpdmUoZmFsc2UpOyByb290IS5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PignLmNvbW1hbmQnKS5mb3JFYWNoKChidXR0b24pID0+IGRlbGV0ZSBidXR0b24uZGF0YXNldC5oZWxkKTtcbiAgICAgIGF1ZGlvLmFtYmllbmNlKGZhbHNlLCBmYWxzZSk7IGF1ZGlvLnBsYXkoJ2dhbWVfcGF1c2UnKTsgc2V0U25hcHNob3Qoc2ltLnNuYXBzaG90KCkpOyB9XG4gICAgICBhY2N1bXVsYXRvciA9IDA7IGxhc3QgPSAwO1xuICAgIH07XG4gICAgY29uc3QgdmlzaWJpbGl0eSA9ICgpID0+IHsgaWYgKGRvY3VtZW50LmhpZGRlbikgZm9jdXNMb3N0KCk7IH07XG4gICAgY29uc3Qgb3JpZW50YXRpb24gPSAoKSA9PiB7IGlmIChtYXRjaE1lZGlhKCcob3JpZW50YXRpb246IHBvcnRyYWl0KScpLm1hdGNoZXMpIGZvY3VzTG9zdCgpOyB9O1xuICAgIGZ1bmN0aW9uIGRlc3Ryb3koKSB7XG4gICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZSk7IHJlc2l6ZT8uZGlzY29ubmVjdCgpOyByZXNpemUgPSBudWxsOyBpbnB1dFJlZi5jdXJyZW50Py5kZXN0cm95KCk7IGlucHV0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgc2ltUmVmLmN1cnJlbnQgPSBudWxsOyBhdWRpby5zdG9wKCk7IGRlbGV0ZSB3aW5kb3cucGlyYXRlVGVzdDtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdibHVyJywgZm9jdXNMb3N0KTsgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIHZpc2liaWxpdHkpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIG9yaWVudGF0aW9uKTtcbiAgICAgIGFyZW5hPy5kZXN0cm95KCk7IGFyZW5hID0gbnVsbDsgbWFwVmlldz8uZGVzdHJveSgpOyBtYXBWaWV3ID0gbnVsbDtcbiAgICAgIGlmIChhcHApIHsgaWYgKGFwcC5yZW5kZXJlcikgYXBwLmRlc3Ryb3koeyByZW1vdmVWaWV3OiBmYWxzZSB9LCB7IGNoaWxkcmVuOiB0cnVlIH0pOyBlbHNlIGFwcC5zdGFnZS5kZXN0cm95KHsgY2hpbGRyZW46IHRydWUgfSk7IGFwcCA9IG51bGw7IH1cbiAgICB9XG4gICAgYXN5bmMgZnVuY3Rpb24gaW5pdGlhbGl6ZSgpIHtcbiAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuOyBzZXRTdGF0dXMoJ2xvYWRpbmcnKTsgc2V0UHJvZ3Jlc3MoMCk7IHNldFNuYXBzaG90KG51bGwpO1xuICAgICAgY29uc3QgYXBwbGljYXRpb24gPSBuZXcgQXBwbGljYXRpb24oKTsgYXBwID0gYXBwbGljYXRpb247XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBhcHBsaWNhdGlvbi5pbml0KHsgY2FudmFzOiBjYW52YXMhLCB3aWR0aDogTWF0aC5tYXgoMSwgaG9zdCEuY2xpZW50V2lkdGgpLCBoZWlnaHQ6IE1hdGgubWF4KDEsIGhvc3QhLmNsaWVudEhlaWdodCksXG4gICAgICAgICAgcmVzb2x1dGlvbjogTWF0aC5taW4oZGV2aWNlUGl4ZWxSYXRpbywgMiksIGF1dG9EZW5zaXR5OiB0cnVlLCBwcmVmZXJlbmNlOiAnd2ViZ2wnLCBiYWNrZ3JvdW5kOiAnIzEyMzc0NCcsIGF1dG9TdGFydDogZmFsc2UsIHNoYXJlZFRpY2tlcjogZmFsc2UgfSk7XG4gICAgICAgIGluaXRpYWxpemVkID0gdHJ1ZTsgaWYgKGRpc3Bvc2VkKSB7IGRlc3Ryb3koKTsgcmV0dXJuOyB9XG4gICAgICAgIGNvbnN0IG1hcCA9IGF3YWl0IGxvYWRUaWxlZE1hcChhYm9ydC5zaWduYWwsIChwKSA9PiB7IGlmICghZGlzcG9zZWQpIHNldFByb2dyZXNzKE1hdGgucm91bmQocCAqIDAuNikpOyB9KTtcbiAgICAgICAgY29uc3QgdGV4dHVyZXMgPSBhd2FpdCBsb2FkR2FtZVRleHR1cmVzKChwKSA9PiB7IGlmICghZGlzcG9zZWQpIHNldFByb2dyZXNzKDYwICsgTWF0aC5yb3VuZChwICogNDApKTsgfSk7XG4gICAgICAgIGlmIChkaXNwb3NlZCkgeyBkZXN0cm95KCk7IHJldHVybjsgfVxuICAgICAgICBjb25zdCBzaW11bGF0aW9uID0gbmV3IFNpbXVsYXRpb24oY29uZmlnLCBtYXApOyBzaW1SZWYuY3VycmVudCA9IHNpbXVsYXRpb247XG4gICAgICAgIG1hcFZpZXcgPSBuZXcgTWFwUmVuZGVyZXIobWFwKTsgYXBwbGljYXRpb24uc3RhZ2UuYWRkQ2hpbGQobWFwVmlldy53b3JsZCk7XG4gICAgICAgIGFyZW5hID0gbmV3IEFyZW5hUmVuZGVyZXIobWFwVmlldy53b3JsZCwgc2ltdWxhdGlvbiwgdGV4dHVyZXMpO1xuICAgICAgICBjb25zdCByZXNpemVDYW52YXMgPSAoKSA9PiB7IGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgICAgIGFwcGxpY2F0aW9uLnJlbmRlcmVyLnJlc2l6ZShNYXRoLm1heCgxLCBob3N0IS5jbGllbnRXaWR0aCksIE1hdGgubWF4KDEsIGhvc3QhLmNsaWVudEhlaWdodCkpO1xuICAgICAgICAgIG1hcFZpZXc/LnJlc2l6ZShhcHBsaWNhdGlvbi5zY3JlZW4ud2lkdGgsIGFwcGxpY2F0aW9uLnNjcmVlbi5oZWlnaHQpOyBhcHBsaWNhdGlvbi5yZW5kZXIoKTsgfTtcbiAgICAgICAgcmVzaXplID0gbmV3IFJlc2l6ZU9ic2VydmVyKHJlc2l6ZUNhbnZhcyk7IHJlc2l6ZS5vYnNlcnZlKGhvc3QhKTsgcmVzaXplQ2FudmFzKCk7XG4gICAgICAgIGNvbnN0IHJlcXVlc3RQYXVzZSA9ICgpID0+IGZvY3VzTG9zdCgpOyBpbnB1dFJlZi5jdXJyZW50ID0gbmV3IElucHV0Q29udHJvbGxlcihyb290ISwgcmVxdWVzdFBhdXNlKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCBmb2N1c0xvc3QpOyBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywgdmlzaWJpbGl0eSk7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBvcmllbnRhdGlvbik7XG4gICAgICAgIGNvbnN0IHVwZGF0ZSA9IChzZWNvbmRzOiBudW1iZXIpID0+IHtcbiAgICAgICAgICBpZiAoc2ltdWxhdGlvbi5zdGF0dXMgIT09ICdwbGF5aW5nJykgeyBhY2N1bXVsYXRvciA9IDA7IHJldHVybjsgfVxuICAgICAgICAgIGFjY3VtdWxhdG9yICs9IHNlY29uZHM7XG4gICAgICAgICAgd2hpbGUgKGFjY3VtdWxhdG9yICsgMWUtOSA+PSBjb25maWcuZml4ZWRTdGVwICYmIHNpbXVsYXRpb24uc3RhdHVzID09PSAncGxheWluZycpIHtcbiAgICAgICAgICAgIHNpbXVsYXRpb24uc3RlcChjb25maWcuZml4ZWRTdGVwLCBpbnB1dFJlZi5jdXJyZW50IS5yZWFkKCkpOyBhY2N1bXVsYXRvciAtPSBjb25maWcuZml4ZWRTdGVwO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhdWRpby5ldmVudHMoc2ltdWxhdGlvbi5kcmFpbkV2ZW50cygpKTtcbiAgICAgICAgICBpZiAoc2ltdWxhdGlvbi5zbmFwc2hvdCgpLnN0YXR1cyA9PT0gJ2VuZGVkJyAmJiAhZmluaXNoZWQpIHsgZmluaXNoZWQgPSB0cnVlOyBpbnB1dFJlZi5jdXJyZW50Py5zZXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICAgICAgaWYgKGluc3RydW1lbnQpIHdpbmRvdy5waXJhdGVNZXRyaWNzID0geyBmcmFtZXM6IFsuLi5zYW1wbGVzXSwgZW50aXR5UGVhaywgZWxhcHNlZDogc2ltdWxhdGlvbi5lbGFwc2VkLCBzY29yZTogc2ltdWxhdGlvbi5zY29yZSwgcmVhc29uOiBzaW11bGF0aW9uLnJlYXNvbiB9O1xuICAgICAgICAgICAgYXVkaW8uc3RvcCgpOyBhdWRpby5wbGF5KHNpbXVsYXRpb24ucmVhc29uID09PSAndGltZScgPyAnZ2FtZV9jb21wbGV0ZScgOiAnZ2FtZV9vdmVyJyk7IGNhbGxiYWNrcy5jdXJyZW50Lm9uQ29tcGxldGUoc2ltdWxhdGlvbi5zbmFwc2hvdCgpKTsgfVxuICAgICAgICB9O1xuICAgICAgICBpZiAoaW5zdHJ1bWVudCkgeyBkZWxldGUgd2luZG93LnBpcmF0ZU1ldHJpY3M7IHdpbmRvdy5waXJhdGVUZXN0ID0geyBvYnNlcnZlOiAoaW5jbHVkZUZyYW1lcyA9IGZhbHNlKSA9PiBzdHJ1Y3R1cmVkQ2xvbmUoeyBzbmFwc2hvdDogc2ltdWxhdGlvbi5zbmFwc2hvdCgpLCBwbGF5ZXI6IHNpbXVsYXRpb24ucGxheWVyLFxuICAgICAgICAgIGVuZW1pZXM6IHNpbXVsYXRpb24uZW5lbWllcywgcHJvamVjdGlsZXM6IHNpbXVsYXRpb24ucHJvamVjdGlsZXMsIGVmZmVjdHM6IHNpbXVsYXRpb24uZWZmZWN0cy5sZW5ndGgsXG4gICAgICAgICAgY29uZmlnLCBjb2xsaWRlcnM6IG1hcC5jb2xsaWRlcnMsIGZyYW1lczogaW5jbHVkZUZyYW1lcyA/IHNhbXBsZXMgOiBbXSwgZW50aXR5UGVhayB9KSxcbiAgICAgICAgICAuLi4obWFudWFsID8geyBhZHZhbmNlOiAoc2Vjb25kczogbnVtYmVyKSA9PiB7IGlmICghTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpIHx8IHNlY29uZHMgPCAwIHx8IHNlY29uZHMgPiAxODApIHRocm93IG5ldyBFcnJvcignSW52YWxpZCB0ZXN0IGNsb2NrIGFkdmFuY2UuJyk7XG4gICAgICAgICAgICB1cGRhdGUoc2Vjb25kcyk7IGFyZW5hPy5kcmF3KCk7IGFwcGxpY2F0aW9uLnJlbmRlcigpOyBzZXRTbmFwc2hvdChzaW11bGF0aW9uLnNuYXBzaG90KCkpOyB9IH0gOiB7fSkgfTsgfVxuICAgICAgICBmdW5jdGlvbiB0aWNrKG5vdzogbnVtYmVyKSB7XG4gICAgICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICAgICAgY29uc3QgZGVsdGEgPSBsYXN0ID8gKG5vdyAtIGxhc3QpIC8gMTAwMCA6IDA7IGxhc3QgPSBub3c7XG4gICAgICAgICAgaWYgKHNpbXVsYXRpb24uc3RhdHVzID09PSAncGxheWluZycpIHtcbiAgICAgICAgICAgIGlmICghbWFudWFsKSB1cGRhdGUoTWF0aC5taW4oZGVsdGEsIDAuMjUpKTtcbiAgICAgICAgICAgIGlmIChpbnN0cnVtZW50ICYmIGRlbHRhID4gMCAmJiBzaW11bGF0aW9uLmVsYXBzZWQgPiA1KSB7IHNhbXBsZXMucHVzaChkZWx0YSAqIDEwMDApOyBpZiAoc2FtcGxlcy5sZW5ndGggPiAyMDAwMCkgc2FtcGxlcy5zaGlmdCgpOyB9XG4gICAgICAgICAgICBlbnRpdHlQZWFrID0gTWF0aC5tYXgoZW50aXR5UGVhaywgc2ltdWxhdGlvbi5lbmVtaWVzLmxlbmd0aCArIHNpbXVsYXRpb24ucHJvamVjdGlsZXMubGVuZ3RoICsgc2ltdWxhdGlvbi5lZmZlY3RzLmxlbmd0aCArIDEpO1xuICAgICAgICAgIH0gZWxzZSBhY2N1bXVsYXRvciA9IDA7XG4gICAgICAgICAgYXVkaW8uYW1iaWVuY2Uoc2ltdWxhdGlvbi5zdGF0dXMgPT09ICdwbGF5aW5nJywgaW5wdXRSZWYuY3VycmVudD8ucmVhZCgpLmhhcygnZm9yd2FyZCcpID8/IGZhbHNlKTtcbiAgICAgICAgICBhcmVuYT8uZHJhdygpOyBhcHBsaWNhdGlvbi5yZW5kZXIoKTtcbiAgICAgICAgICBpZiAobm93ID49IHB1Ymxpc2hBdCkgeyBzZXRTbmFwc2hvdChzaW11bGF0aW9uLnNuYXBzaG90KCkpOyBwdWJsaXNoQXQgPSBub3cgKyAyNTA7IH1cbiAgICAgICAgICBmcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICAgICAgfVxuICAgICAgICBzZXRTdGF0dXMoJ3JlYWR5Jyk7IHNldFNuYXBzaG90KHNpbXVsYXRpb24uc25hcHNob3QoKSk7IHJvb3QhLmZvY3VzKCk7IGF1ZGlvLnBsYXkoJ2dhbWVfc3RhcnQnKTtcbiAgICAgICAgaWYgKGRvY3VtZW50LmhpZGRlbiB8fCBtYXRjaE1lZGlhKCcob3JpZW50YXRpb246IHBvcnRyYWl0KScpLm1hdGNoZXMpIGZvY3VzTG9zdCgpO1xuICAgICAgICBmcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICAgIH0gY2F0Y2ggKGNhdXNlKSB7IGRlc3Ryb3koKTsgaWYgKCFkaXNwb3NlZCkgeyBzZXRFcnJvcihjYXVzZSBpbnN0YW5jZW9mIEVycm9yID8gY2F1c2UubWVzc2FnZSA6ICdVbmtub3duIGFzc2V0IGxvYWRpbmcgZXJyb3IuJyk7IHNldFN0YXR1cygnZXJyb3InKTsgfSB9XG4gICAgfVxuICAgIHF1ZXVlLmN1cnJlbnQgPSBxdWV1ZS5jdXJyZW50LnRoZW4oaW5pdGlhbGl6ZSk7XG4gICAgcmV0dXJuICgpID0+IHsgZGlzcG9zZWQgPSB0cnVlOyBhYm9ydC5hYm9ydCgpOyBpZiAoaW5pdGlhbGl6ZWQpIGRlc3Ryb3koKTsgfTtcbiAgfSwgW2F0dGVtcHQsIGNvbmZpZ10pO1xuICBjb25zdCBwYXVzZWQgPSBzbmFwc2hvdD8uc3RhdHVzID09PSAncGF1c2VkJztcbiAgcmV0dXJuIDxzZWN0aW9uIHJlZj17cm9vdFJlZn0gY2xhc3NOYW1lPVwiZ2FtZVwiIHRhYkluZGV4PXswfSBhcmlhLWxhYmVsPVwiR2FtZXBsYXkgY29udHJvbHNcIj5cbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImh1ZFwiIGFyaWEtbGFiZWw9XCJNYXRjaCBzdGF0dXNcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291bnRlclwiPjxpbWcgc3JjPXt1aUFzc2V0KCdodWQvaWNvbl9oZWFydCcpfSBhbHQ9XCJcIiAvPiA8c3Bhbj5IZWFsdGggPHN0cm9uZz57c25hcHNob3Q/LmhlYWx0aCA/PyBjb25maWcucGxheWVyLmhlYWx0aH08L3N0cm9uZz48L3NwYW4+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvdW50ZXJcIj48aW1nIHNyYz17dWlBc3NldCgnaHVkL2ljb25fc2NvcmUnKX0gYWx0PVwiXCIgLz4gPHNwYW4+U2NvcmUgPHN0cm9uZz57c25hcHNob3Q/LnNjb3JlID8/IDB9PC9zdHJvbmc+PC9zcGFuPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3VudGVyXCI+PGltZyBzcmM9e3VpQXNzZXQoJ2h1ZC9pY29uX3RpbWUnKX0gYWx0PVwiXCIgLz4gPHNwYW4+VGltZSA8c3Ryb25nPntNYXRoLmNlaWwoc25hcHNob3Q/LnJlbWFpbmluZyA/PyBjb25maWcuc2Vzc2lvblNlY29uZHMpfXM8L3N0cm9uZz48L3NwYW4+PC9kaXY+XG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInJvdW5kLWJ1dHRvblwiIGFyaWEtbGFiZWw9XCJQYXVzZSBnYW1lXCIgZGlzYWJsZWQ9e3N0YXR1cyAhPT0gJ3JlYWR5JyB8fCBwYXVzZWR9IG9uQ2xpY2s9e3BhdXNlfT48aW1nIHNyYz17dWlBc3NldCgnY29udHJvbHMvaWNvbl9wYXVzZScpfSBhbHQ9XCJcIiAvPjwvYnV0dG9uPlxuICAgIDwvaGVhZGVyPlxuICAgIDxkaXYgcmVmPXt2aWV3cG9ydFJlZn0gY2xhc3NOYW1lPVwiYXJlbmFcIiBhcmlhLWJ1c3k9e3N0YXR1cyA9PT0gJ2xvYWRpbmcnfT5cbiAgICAgIDxjYW52YXMga2V5PXthdHRlbXB0fSByZWY9e2NhbnZhc1JlZn0gYXJpYS1sYWJlbD1cIk5hdmFsIGJhdHRsZSBhcmVuYVwiIC8+XG4gICAgICB7c3RhdHVzID09PSAnbG9hZGluZycgJiYgPGRpdiBjbGFzc05hbWU9XCJhcmVuYS1tZXNzYWdlXCIgcm9sZT1cInN0YXR1c1wiPkxvYWRpbmcgYXJlbmHigKYge3Byb2dyZXNzfSU8L2Rpdj59XG4gICAgICB7c3RhdHVzID09PSAnZXJyb3InICYmIDxkaXYgY2xhc3NOYW1lPVwiYXJlbmEtbWVzc2FnZVwiIHJvbGU9XCJhbGVydFwiPjxwPlVuYWJsZSB0byBsb2FkIHRoZSBhcmVuYS48L3A+PHA+e2Vycm9yfTwvcD5cbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRBdHRlbXB0KCh2KSA9PiB2ICsgMSl9PlRyeSBhZ2FpbjwvQnV0dG9uPjxCdXR0b24gb25DbGljaz17b25BYmFuZG9ufT5NYWluIE1lbnU8L0J1dHRvbj48L2Rpdj59XG4gICAgPC9kaXY+XG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJjb21iYXQtZm9vdGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvdWNoLWNvbnRyb2xzXCI+e2NvbW1hbmRzLm1hcCgoeyBhY3Rpb24sIGxhYmVsLCBpY29uIH0pID0+IDxidXR0b24ga2V5PXthY3Rpb259IHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9e2Byb3VuZC1idXR0b24gY29tbWFuZCBjb21tYW5kLSR7YWN0aW9ufWB9IGFyaWEtbGFiZWw9e2xhYmVsfSBkaXNhYmxlZD17c3RhdHVzICE9PSAncmVhZHknIHx8IHBhdXNlZH1cbiAgICAgICAgb25Qb2ludGVyRG93bj17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBlLmN1cnJlbnRUYXJnZXQuc2V0UG9pbnRlckNhcHR1cmUoZS5wb2ludGVySWQpOyByb290UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgaW5wdXRSZWYuY3VycmVudD8ucHJlc3MoYHRvdWNoLSR7ZS5wb2ludGVySWR9YCwgYWN0aW9uKTsgZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaGVsZCA9ICd0cnVlJzsgfX1cbiAgICAgICAgb25Qb2ludGVyVXA9eyhlKSA9PiB7IGlucHV0UmVmLmN1cnJlbnQ/LnJlbGVhc2UoYHRvdWNoLSR7ZS5wb2ludGVySWR9YCk7IGRlbGV0ZSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5oZWxkOyB9fVxuICAgICAgICBvblBvaW50ZXJDYW5jZWw9eyhlKSA9PiB7IGlucHV0UmVmLmN1cnJlbnQ/LnJlbGVhc2UoYHRvdWNoLSR7ZS5wb2ludGVySWR9YCk7IGRlbGV0ZSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5oZWxkOyB9fVxuICAgICAgICBvbkxvc3RQb2ludGVyQ2FwdHVyZT17KGUpID0+IHsgaW5wdXRSZWYuY3VycmVudD8ucmVsZWFzZShgdG91Y2gtJHtlLnBvaW50ZXJJZH1gKTsgZGVsZXRlIGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmhlbGQ7IH19XG4gICAgICAgIG9uS2V5RG93bj17KGUpID0+IHsgaWYgKGUuY29kZSA9PT0gJ1NwYWNlJyB8fCBlLmNvZGUgPT09ICdFbnRlcicpIHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBpbnB1dFJlZi5jdXJyZW50Py5wcmVzcyhgYnV0dG9uLSR7YWN0aW9ufWAsIGFjdGlvbik7IH0gfX1cbiAgICAgICAgb25LZXlVcD17KCkgPT4gaW5wdXRSZWYuY3VycmVudD8ucmVsZWFzZShgYnV0dG9uLSR7YWN0aW9ufWApfSBvbkJsdXI9eygpID0+IGlucHV0UmVmLmN1cnJlbnQ/LnJlbGVhc2UoYGJ1dHRvbi0ke2FjdGlvbn1gKX0+XG4gICAgICAgIDxpbWcgc3JjPXt1aUFzc2V0KGBjb250cm9scy9pY29uXyR7aWNvbn1gKX0gYWx0PVwiXCIgLz48c3Bhbj57bGFiZWx9PC9zcGFuPjwvYnV0dG9uPil9PC9kaXY+XG4gICAgICA8Q29udHJvbHNIZWxwIC8+XG4gICAgPC9mb290ZXI+XG4gICAgPHAgY2xhc3NOYW1lPVwic3Itb25seVwiIHJvbGU9XCJzdGF0dXNcIj57c3RhdHVzID09PSAnbG9hZGluZycgPyAnTG9hZGluZyBhcmVuYScgOiBwYXVzZWQgPyAnR2FtZSBwYXVzZWQnIDogJ0dhbWUgYWN0aXZlJ308L3A+XG4gICAge3BhdXNlZCAmJiA8RGlhbG9nIHRpdGxlPXthYmFuZG9uID8gJ0xlYXZlIHRoaXMgYmF0dGxlPycgOiAnQmF0dGxlIHBhdXNlZCd9IG9uQ2xvc2U9eygpID0+IHsgaWYgKGFiYW5kb24pIHNldEFiYW5kb24oZmFsc2UpOyBlbHNlIHJlc3VtZSgpOyB9fT5cbiAgICAgIDxwPnthYmFuZG9uID8gJ1RoaXMgdW5maW5pc2hlZCBiYXR0bGUgd2lsbCBub3QgYmUgc2F2ZWQuJyA6ICdUaW1lLCBtb3ZlbWVudCBhbmQgd2VhcG9ucyBhcmUgc3VzcGVuZGVkLiBSZXN1bWUgd2hlbiB5b3UgYXJlIHJlYWR5Lid9PC9wPlxuICAgICAgPHAgY2xhc3NOYW1lPVwicG9ydHJhaXQtaGludFwiPlJvdGF0ZSB5b3VyIGRldmljZSB0byBsYW5kc2NhcGUgYmVmb3JlIHJlc3VtaW5nLjwvcD5cbiAgICAgIHthYmFuZG9uID8gPD48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFiYW5kb24oZmFsc2UpfT5TdGF5IGhlcmU8L0J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9e29uQWJhbmRvbn0+TGVhdmUgYmF0dGxlPC9CdXR0b24+PC8+XG4gICAgICAgIDogPD48QnV0dG9uIG9uQ2xpY2s9e3Jlc3VtZX0+UmVzdW1lPC9CdXR0b24+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRBYmFuZG9uKHRydWUpfT5NYWluIE1lbnU8L0J1dHRvbj48Lz59XG4gICAgPC9EaWFsb2c+fVxuICA8L3NlY3Rpb24+O1xufVxuIl19