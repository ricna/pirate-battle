import { angleDifference, angleTo, circleRect, distance, Navigation, segmentCircle, segmentRect } from "/src/game/geometry.ts";
export class Simulation {
	config;
	map;
	player;
	enemies = [];
	projectiles = [];
	effects = [];
	status = "playing";
	elapsed = 0;
	score = 0;
	reason = null;
	nextId = 1;
	randomState;
	spawnAt;
	spawnCount = 0;
	cooldown = {
		front: 0,
		port: 0,
		starboard: 0
	};
	events = [];
	navigation;
	warnedTime = false;
	warnedHealth = false;
	width;
	height;
	constructor(config, map) {
		this.config = config;
		this.map = map;
		this.width = map.width * map.tileWidth;
		this.height = map.height * map.tileHeight;
		this.randomState = config.seed;
		this.spawnAt = config.spawnSeconds;
		this.player = {
			...config.player,
			maxHealth: config.player.health,
			angle: 0,
			id: 0,
			kind: "player",
			alive: true,
			fireAt: 0,
			routeAt: 0,
			route: []
		};
		if (!this.free(this.player, this.player.radius)) throw new Error("Authored player spawn is obstructed.");
		for (const point of config.spawnPoints) if (!this.free(point, config.enemy.radius)) throw new Error("Authored enemy spawn is obstructed.");
		this.navigation = new Navigation(map.width, map.height, map.tileWidth, config.enemy.radius, map.colliders);
	}
	random() {
		this.randomState = 1664525 * this.randomState + 1013904223 >>> 0;
		return this.randomState / 4294967296;
	}
	free(p, r) {
		return p.x >= r && p.y >= r && p.x <= this.width - r && p.y <= this.height - r && !this.map.colliders.some((rect) => circleRect(p, r, rect));
	}
	visible(a, b, padding) {
		return !this.map.colliders.some((r) => segmentRect(a, b, r, padding) !== null);
	}
	move(ship, speed, dt) {
		const dx = Math.sin(ship.angle) * speed * dt;
		const dy = -Math.cos(ship.angle) * speed * dt;
		const next = {
			x: Math.max(ship.radius, Math.min(this.width - ship.radius, ship.x + dx)),
			y: Math.max(ship.radius, Math.min(this.height - ship.radius, ship.y + dy))
		};
		if (this.free(next, ship.radius)) {
			ship.x = next.x;
			ship.y = next.y;
		} else {
			// Axis sliding avoids sticking while preserving circle/rectangle contacts.
			if (this.free({
				x: next.x,
				y: ship.y
			}, ship.radius)) ship.x = next.x;
			if (this.free({
				x: ship.x,
				y: next.y
			}, ship.radius)) ship.y = next.y;
		}
	}
	effect(p, kind, angle = 0) {
		this.effects.push({
			...p,
			id: this.nextId++,
			kind,
			angle,
			age: 0,
			duration: this.config.effects[kind]
		});
	}
	shoot(ship, side) {
		const w = this.config.weapon;
		const angle = ship.angle + side * Math.PI / 2;
		const origin = {
			x: ship.x + Math.sin(angle) * (side ? w.sideOffset : w.frontOffset),
			y: ship.y - Math.cos(angle) * (side ? w.sideOffset : w.frontOffset)
		};
		const enemy = ship.kind !== "player";
		for (const shift of side ? [
			-w.parallelSpacing,
			0,
			w.parallelSpacing
		] : [0]) {
			this.projectiles.push({
				id: this.nextId++,
				x: origin.x + Math.sin(ship.angle) * shift,
				y: origin.y - Math.cos(ship.angle) * shift,
				vx: Math.sin(angle) * (enemy ? w.enemySpeed : w.speed),
				vy: -Math.cos(angle) * (enemy ? w.enemySpeed : w.speed),
				damage: enemy ? w.enemyDamage : side ? w.sideDamage : w.frontDamage,
				owner: enemy ? "enemy" : "player",
				age: 0
			});
		}
		this.effect(origin, "muzzle", angle);
		this.events.push(enemy ? "enemy-shot" : side ? "side-shot" : "front-shot");
	}
	damage(ship, amount, credited) {
		if (!ship.alive) return;
		ship.health = Math.max(0, ship.health - amount);
		this.events.push("impact");
		this.effect(ship, "impact");
		if (!ship.health) {
			ship.alive = false;
			this.effect(ship, "explosion");
			this.events.push("explosion");
			if (ship.kind !== "player" && credited) {
				this.score++;
				this.events.push("score");
			}
		}
		if (ship.kind === "player" && ship.health <= ship.maxHealth * .3 && !this.warnedHealth) {
			this.warnedHealth = true;
			this.events.push("low-health");
		}
	}
	spawn() {
		if (this.enemies.length >= this.config.enemy.maxCount) return;
		const valid = this.config.spawnPoints.filter((p) => distance(p, this.player) >= this.config.enemy.safeSpawnDistance && !this.enemies.some((e) => distance(e, p) < e.radius * 3));
		if (!valid.length) return;
		const point = valid[Math.floor(this.random() * valid.length)];
		const kind = this.spawnCount === 0 ? "chaser" : this.spawnCount === 1 ? "shooter" : this.random() < this.config.enemy.shooterWeight ? "shooter" : "chaser";
		const health = kind === "chaser" ? this.config.enemy.chaserHealth : this.config.enemy.shooterHealth;
		this.enemies.push({
			...point,
			id: this.nextId++,
			kind,
			radius: this.config.enemy.radius,
			health,
			maxHealth: health,
			angle: angleTo(point, this.player),
			alive: true,
			fireAt: 0,
			routeAt: 0,
			route: []
		});
		this.spawnCount++;
	}
	pause() {
		if (this.status === "playing") this.status = "paused";
	}
	resume() {
		if (this.status === "paused") this.status = "playing";
	}
	step(dt, input) {
		if (this.status !== "playing") return;
		dt = Math.min(dt, this.config.sessionSeconds - this.elapsed);
		this.elapsed += dt;
		this.player.angle += ((input.has("right") ? 1 : 0) - (input.has("left") ? 1 : 0)) * this.config.player.turnSpeed * dt;
		if (input.has("forward")) this.move(this.player, this.config.player.speed, dt);
		for (const action of [
			"front",
			"port",
			"starboard"
		]) {
			if (input.has(action) && this.elapsed + 1e-8 >= this.cooldown[action]) {
				this.shoot(this.player, action === "front" ? 0 : action === "port" ? -1 : 1);
				this.cooldown[action] = this.elapsed + (action === "front" ? this.config.weapon.frontCooldown : this.config.weapon.sideCooldown);
			}
		}
		while (this.elapsed + 1e-8 >= this.spawnAt) {
			this.spawn();
			this.spawnAt += this.config.spawnSeconds;
		}
		for (const enemy of this.enemies) {
			if (!enemy.alive || !this.player.alive) continue;
			const sight = this.visible(enemy, this.player, enemy.radius);
			let target = this.player;
			if (!sight) {
				if (this.elapsed >= enemy.routeAt) {
					enemy.route = this.navigation.route(enemy, this.player);
					enemy.routeAt = this.elapsed + this.config.enemy.routeInterval;
				}
				while (enemy.route.length && distance(enemy, enemy.route[0]) < 22) enemy.route.shift();
				target = enemy.route[0] ?? enemy;
			}
			const turn = angleDifference(angleTo(enemy, target), enemy.angle);
			enemy.angle += Math.max(-this.config.enemy.turnSpeed * dt, Math.min(this.config.enemy.turnSpeed * dt, turn));
			const inRange = distance(enemy, this.player) <= this.config.enemy.range && sight;
			if (!(enemy.kind === "shooter" && inRange) && Math.abs(turn) < 1.2) {
				this.move(enemy, enemy.kind === "shooter" ? this.config.enemy.shooterSpeed : this.config.enemy.chaserSpeed, dt);
			}
			if (enemy.kind === "shooter" && inRange && Math.abs(turn) < .18 && this.elapsed >= enemy.fireAt) {
				this.shoot(enemy, 0);
				enemy.fireAt = this.elapsed + this.config.enemy.cooldown;
			}
			if (enemy.kind === "chaser" && distance(enemy, this.player) < enemy.radius + this.player.radius) {
				this.damage(this.player, this.config.enemy.ramDamage, false);
				this.damage(enemy, enemy.health, false);
			}
		}
		if (!this.player.alive) {
			this.reason = "death";
			this.status = "ended";
			return;
		}
		this.projectiles = this.projectiles.filter((p) => {
			if (!this.player.alive) return false;
			const next = {
				x: p.x + p.vx * dt,
				y: p.y + p.vy * dt
			};
			let first = Infinity;
			let victim = null;
			for (const rect of this.map.colliders) {
				const t = segmentRect(p, next, rect, this.config.weapon.radius);
				if (t !== null && t < first) first = t;
			}
			for (const ship of p.owner === "player" ? this.enemies : [this.player]) {
				if (!ship.alive) continue;
				const t = segmentCircle(p, next, ship, ship.radius + this.config.weapon.radius);
				if (t !== null && t < first) {
					first = t;
					victim = ship;
				}
			}
			if (first !== Infinity) {
				if (victim) this.damage(victim, p.damage, p.owner === "player");
				else {
					this.effect({
						x: p.x + (next.x - p.x) * first,
						y: p.y + (next.y - p.y) * first
					}, "impact");
					this.events.push("impact");
				}
				return false;
			}
			p.x = next.x;
			p.y = next.y;
			p.age += dt;
			return p.age < this.config.weapon.lifetime && this.free(p, 0);
		});
		this.enemies = this.enemies.filter((e) => e.alive);
		this.effects = this.effects.filter((e) => {
			e.age += dt;
			return e.age < e.duration;
		});
		if (this.config.sessionSeconds - this.elapsed <= 10 && !this.warnedTime) {
			this.warnedTime = true;
			this.events.push("time-warning");
		}
		if (!this.player.alive || this.elapsed >= this.config.sessionSeconds - 1e-8) {
			this.reason = this.player.alive ? "time" : "death";
			this.status = "ended";
		}
	}
	drainEvents() {
		const events = this.events;
		this.events = [];
		return events;
	}
	snapshot() {
		return {
			status: this.status,
			elapsed: this.elapsed,
			remaining: Math.max(0, this.config.sessionSeconds - this.elapsed),
			score: this.score,
			health: this.player.health,
			maxHealth: this.player.maxHealth,
			enemies: this.enemies.length,
			reason: this.reason
		};
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxpQkFBaUIsU0FBUyxZQUFZLFVBQVUsWUFBWSxlQUFlLG1CQUFtQjtBQVl2RyxPQUFPLE1BQU0sV0FBVztDQVFEO0NBQTZCO0NBUGxELEFBQVM7Q0FDVCxVQUFrQixDQUFDO0NBQUcsY0FBNEIsQ0FBQztDQUFHLFVBQW9CLENBQUM7Q0FDM0UsU0FBNkI7Q0FBVyxVQUFVO0NBQUcsUUFBUTtDQUFHLFNBQTJCO0NBQzNGLEFBQVEsU0FBUztDQUFHLEFBQVE7Q0FBcUIsQUFBUTtDQUFpQixBQUFRLGFBQWE7Q0FDL0YsQUFBUSxXQUFXO0VBQUUsT0FBTztFQUFHLE1BQU07RUFBRyxXQUFXO0NBQUU7Q0FBRyxBQUFRLFNBQXNCLENBQUM7Q0FDdkYsQUFBUTtDQUF3QixBQUFRLGFBQWE7Q0FBTyxBQUFRLGVBQWU7Q0FDbkYsQUFBUztDQUFlLEFBQVM7Q0FDakMsWUFBWSxBQUFTLFFBQW9CLEFBQVMsS0FBZ0I7RUFBN0M7RUFBNkI7RUFDaEQsS0FBSyxRQUFRLElBQUksUUFBUSxJQUFJO0VBQVcsS0FBSyxTQUFTLElBQUksU0FBUyxJQUFJO0VBQ3ZFLEtBQUssY0FBYyxPQUFPO0VBQU0sS0FBSyxVQUFVLE9BQU87RUFDdEQsS0FBSyxTQUFTO0dBQUUsR0FBRyxPQUFPO0dBQVEsV0FBVyxPQUFPLE9BQU87R0FBUSxPQUFPO0dBQUcsSUFBSTtHQUMvRSxNQUFNO0dBQVUsT0FBTztHQUFNLFFBQVE7R0FBRyxTQUFTO0dBQUcsT0FBTyxDQUFDO0VBQUU7RUFDaEUsSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLFFBQVEsS0FBSyxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksTUFBTSxzQ0FBc0M7RUFDdkcsS0FBSyxNQUFNLFNBQVMsT0FBTyxhQUFhLElBQUksQ0FBQyxLQUFLLEtBQUssT0FBTyxPQUFPLE1BQU0sTUFBTSxHQUMvRSxNQUFNLElBQUksTUFBTSxxQ0FBcUM7RUFDdkQsS0FBSyxhQUFhLElBQUksV0FBVyxJQUFJLE9BQU8sSUFBSSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU0sUUFBUSxJQUFJLFNBQVM7Q0FDM0c7Q0FDQSxBQUFRLFNBQVM7RUFBRSxLQUFLLGNBQWUsVUFBVSxLQUFLLGNBQWMsZUFBZ0I7RUFBRyxPQUFPLEtBQUssY0FBYztDQUFZO0NBQzdILEFBQVEsS0FBSyxHQUFVLEdBQVc7RUFBRSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxLQUFLLFFBQVEsS0FDbEYsRUFBRSxLQUFLLEtBQUssU0FBUyxLQUFLLENBQUMsS0FBSyxJQUFJLFVBQVUsTUFBTSxTQUFTLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHO0NBQzNGLEFBQVEsUUFBUSxHQUFVLEdBQVUsU0FBaUI7RUFDbkQsT0FBTyxDQUFDLEtBQUssSUFBSSxVQUFVLE1BQU0sTUFBTSxZQUFZLEdBQUcsR0FBRyxHQUFHLE9BQU8sTUFBTSxJQUFJO0NBQy9FO0NBQ0EsQUFBUSxLQUFLLE1BQVksT0FBZSxJQUFZO0VBQ2xELE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksUUFBUTtFQUFJLE1BQU0sS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxRQUFRO0VBQ3pGLE1BQU0sT0FBTztHQUFFLEdBQUcsS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLElBQUksRUFBRSxDQUFDO0dBQ3JGLEdBQUcsS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLElBQUksRUFBRSxDQUFDO0VBQUU7RUFDN0UsSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sR0FBRztHQUFFLEtBQUssSUFBSSxLQUFLO0dBQUcsS0FBSyxJQUFJLEtBQUs7RUFBRyxPQUNqRTs7R0FFSCxJQUFJLEtBQUssS0FBSztJQUFFLEdBQUcsS0FBSztJQUFHLEdBQUcsS0FBSztHQUFFLEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUs7R0FDcEUsSUFBSSxLQUFLLEtBQUs7SUFBRSxHQUFHLEtBQUs7SUFBRyxHQUFHLEtBQUs7R0FBRSxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssSUFBSSxLQUFLO0VBQ3RFO0NBQ0Y7Q0FDQSxBQUFRLE9BQU8sR0FBVSxNQUFzQixRQUFRLEdBQUc7RUFDeEQsS0FBSyxRQUFRLEtBQUs7R0FBRSxHQUFHO0dBQUcsSUFBSSxLQUFLO0dBQVU7R0FBTTtHQUFPLEtBQUs7R0FBRyxVQUFVLEtBQUssT0FBTyxRQUFRO0VBQU0sQ0FBQztDQUN6RztDQUNBLEFBQVEsTUFBTSxNQUFZLE1BQWtCO0VBQzFDLE1BQU0sSUFBSSxLQUFLLE9BQU87RUFBUSxNQUFNLFFBQVEsS0FBSyxRQUFRLE9BQU8sS0FBSyxLQUFLO0VBQzFFLE1BQU0sU0FBUztHQUFFLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFLGFBQWEsRUFBRTtHQUN0RSxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRSxhQUFhLEVBQUU7RUFBYTtFQUN0RSxNQUFNLFFBQVEsS0FBSyxTQUFTO0VBQzVCLEtBQUssTUFBTSxTQUFTLE9BQU87R0FBQyxDQUFDLEVBQUU7R0FBaUI7R0FBRyxFQUFFO0VBQWUsSUFBSSxDQUFDLENBQUMsR0FBRztHQUMzRSxLQUFLLFlBQVksS0FBSztJQUFFLElBQUksS0FBSztJQUFVLEdBQUcsT0FBTyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSTtJQUM5RSxHQUFHLE9BQU8sSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUk7SUFBTyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssUUFBUSxFQUFFLGFBQWEsRUFBRTtJQUM1RixJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSyxRQUFRLEVBQUUsYUFBYSxFQUFFO0lBQVEsUUFBUSxRQUFRLEVBQUUsY0FBYyxPQUFPLEVBQUUsYUFBYSxFQUFFO0lBQ2pILE9BQU8sUUFBUSxVQUFVO0lBQVUsS0FBSztHQUFFLENBQUM7RUFDL0M7RUFDQSxLQUFLLE9BQU8sUUFBUSxVQUFVLEtBQUs7RUFBRyxLQUFLLE9BQU8sS0FBSyxRQUFRLGVBQWUsT0FBTyxjQUFjLFlBQVk7Q0FDakg7Q0FDQSxBQUFRLE9BQU8sTUFBWSxRQUFnQixVQUFtQjtFQUM1RCxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2pCLEtBQUssU0FBUyxLQUFLLElBQUksR0FBRyxLQUFLLFNBQVMsTUFBTTtFQUFHLEtBQUssT0FBTyxLQUFLLFFBQVE7RUFBRyxLQUFLLE9BQU8sTUFBTSxRQUFRO0VBQ3ZHLElBQUksQ0FBQyxLQUFLLFFBQVE7R0FDaEIsS0FBSyxRQUFRO0dBQU8sS0FBSyxPQUFPLE1BQU0sV0FBVztHQUFHLEtBQUssT0FBTyxLQUFLLFdBQVc7R0FDaEYsSUFBSSxLQUFLLFNBQVMsWUFBWSxVQUFVO0lBQUUsS0FBSztJQUFTLEtBQUssT0FBTyxLQUFLLE9BQU87R0FBRztFQUNyRjtFQUNBLElBQUksS0FBSyxTQUFTLFlBQVksS0FBSyxVQUFVLEtBQUssWUFBWSxNQUFPLENBQUMsS0FBSyxjQUFjO0dBQ3ZGLEtBQUssZUFBZTtHQUFNLEtBQUssT0FBTyxLQUFLLFlBQVk7RUFDekQ7Q0FDRjtDQUNBLEFBQVEsUUFBUTtFQUNkLElBQUksS0FBSyxRQUFRLFVBQVUsS0FBSyxPQUFPLE1BQU0sVUFBVTtFQUN2RCxNQUFNLFFBQVEsS0FBSyxPQUFPLFlBQVksUUFBUSxNQUFNLFNBQVMsR0FBRyxLQUFLLE1BQU0sS0FBSyxLQUFLLE9BQU8sTUFBTSxxQkFDN0YsQ0FBQyxLQUFLLFFBQVEsTUFBTSxNQUFNLFNBQVMsR0FBRyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztFQUM3RCxJQUFJLENBQUMsTUFBTSxRQUFRO0VBQ25CLE1BQU0sUUFBUSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFNLE1BQU07RUFDM0QsTUFBTSxPQUFPLEtBQUssZUFBZSxJQUFJLFdBQVcsS0FBSyxlQUFlLElBQUksWUFDcEUsS0FBSyxPQUFPLElBQUksS0FBSyxPQUFPLE1BQU0sZ0JBQWdCLFlBQVk7RUFDbEUsTUFBTSxTQUFTLFNBQVMsV0FBVyxLQUFLLE9BQU8sTUFBTSxlQUFlLEtBQUssT0FBTyxNQUFNO0VBQ3RGLEtBQUssUUFBUSxLQUFLO0dBQUUsR0FBRztHQUFPLElBQUksS0FBSztHQUFVO0dBQU0sUUFBUSxLQUFLLE9BQU8sTUFBTTtHQUMvRTtHQUFRLFdBQVc7R0FBUSxPQUFPLFFBQVEsT0FBTyxLQUFLLE1BQU07R0FBRyxPQUFPO0dBQU0sUUFBUTtHQUFHLFNBQVM7R0FBRyxPQUFPLENBQUM7RUFBRSxDQUFDO0VBQ2hILEtBQUs7Q0FDUDtDQUNBLFFBQVE7RUFBRSxJQUFJLEtBQUssV0FBVyxXQUFXLEtBQUssU0FBUztDQUFVO0NBQ2pFLFNBQVM7RUFBRSxJQUFJLEtBQUssV0FBVyxVQUFVLEtBQUssU0FBUztDQUFXO0NBQ2xFLEtBQUssSUFBWSxPQUE0QjtFQUMzQyxJQUFJLEtBQUssV0FBVyxXQUFXO0VBQy9CLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxPQUFPLGlCQUFpQixLQUFLLE9BQU87RUFDM0QsS0FBSyxXQUFXO0VBQ2hCLEtBQUssT0FBTyxXQUFXLE1BQU0sSUFBSSxPQUFPLElBQUksSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksSUFBSSxNQUFNLEtBQUssT0FBTyxPQUFPLFlBQVk7RUFDbkgsSUFBSSxNQUFNLElBQUksU0FBUyxHQUFHLEtBQUssS0FBSyxLQUFLLFFBQVEsS0FBSyxPQUFPLE9BQU8sT0FBTyxFQUFFO0VBQzdFLEtBQUssTUFBTSxVQUFVO0dBQUM7R0FBUztHQUFRO0VBQVcsR0FBWTtHQUM1RCxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSyxVQUFVLFFBQVEsS0FBSyxTQUFTLFNBQVM7SUFDckUsS0FBSyxNQUFNLEtBQUssUUFBUSxXQUFXLFVBQVUsSUFBSSxXQUFXLFNBQVMsQ0FBQyxJQUFJLENBQUM7SUFDM0UsS0FBSyxTQUFTLFVBQVUsS0FBSyxXQUFXLFdBQVcsVUFBVSxLQUFLLE9BQU8sT0FBTyxnQkFBZ0IsS0FBSyxPQUFPLE9BQU87R0FDckg7RUFDRjtFQUNBLE9BQU8sS0FBSyxVQUFVLFFBQVEsS0FBSyxTQUFTO0dBQUUsS0FBSyxNQUFNO0dBQUcsS0FBSyxXQUFXLEtBQUssT0FBTztFQUFjO0VBQ3RHLEtBQUssTUFBTSxTQUFTLEtBQUssU0FBUztHQUNoQyxJQUFJLENBQUMsTUFBTSxTQUFTLENBQUMsS0FBSyxPQUFPLE9BQU87R0FDeEMsTUFBTSxRQUFRLEtBQUssUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNLE1BQU07R0FDM0QsSUFBSSxTQUFnQixLQUFLO0dBQ3pCLElBQUksQ0FBQyxPQUFPO0lBQ1YsSUFBSSxLQUFLLFdBQVcsTUFBTSxTQUFTO0tBQUUsTUFBTSxRQUFRLEtBQUssV0FBVyxNQUFNLE9BQU8sS0FBSyxNQUFNO0tBQ3pGLE1BQU0sVUFBVSxLQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU07SUFBZTtJQUNsRSxPQUFPLE1BQU0sTUFBTSxVQUFVLFNBQVMsT0FBTyxNQUFNLE1BQU0sRUFBRyxJQUFJLElBQUksTUFBTSxNQUFNLE1BQU07SUFDdEYsU0FBUyxNQUFNLE1BQU0sTUFBTTtHQUM3QjtHQUNBLE1BQU0sT0FBTyxnQkFBZ0IsUUFBUSxPQUFPLE1BQU0sR0FBRyxNQUFNLEtBQUs7R0FDaEUsTUFBTSxTQUFTLEtBQUssSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksSUFBSSxLQUFLLElBQUksS0FBSyxPQUFPLE1BQU0sWUFBWSxJQUFJLElBQUksQ0FBQztHQUMzRyxNQUFNLFVBQVUsU0FBUyxPQUFPLEtBQUssTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLFNBQVM7R0FDM0UsSUFBSSxFQUFFLE1BQU0sU0FBUyxhQUFhLFlBQVksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLO0lBQ2xFLEtBQUssS0FBSyxPQUFPLE1BQU0sU0FBUyxZQUFZLEtBQUssT0FBTyxNQUFNLGVBQWUsS0FBSyxPQUFPLE1BQU0sYUFBYSxFQUFFO0dBQ2hIO0dBQ0EsSUFBSSxNQUFNLFNBQVMsYUFBYSxXQUFXLEtBQUssSUFBSSxJQUFJLElBQUksT0FBUSxLQUFLLFdBQVcsTUFBTSxRQUFRO0lBQ2hHLEtBQUssTUFBTSxPQUFPLENBQUM7SUFBRyxNQUFNLFNBQVMsS0FBSyxVQUFVLEtBQUssT0FBTyxNQUFNO0dBQ3hFO0dBQ0EsSUFBSSxNQUFNLFNBQVMsWUFBWSxTQUFTLE9BQU8sS0FBSyxNQUFNLElBQUksTUFBTSxTQUFTLEtBQUssT0FBTyxRQUFRO0lBQy9GLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLE1BQU0sV0FBVyxLQUFLO0lBQUcsS0FBSyxPQUFPLE9BQU8sTUFBTSxRQUFRLEtBQUs7R0FDdEc7RUFDRjtFQUNBLElBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTztHQUFFLEtBQUssU0FBUztHQUFTLEtBQUssU0FBUztHQUFTO0VBQVE7RUFDaEYsS0FBSyxjQUFjLEtBQUssWUFBWSxRQUFRLE1BQU07R0FDaEQsSUFBSSxDQUFDLEtBQUssT0FBTyxPQUFPLE9BQU87R0FDL0IsTUFBTSxPQUFPO0lBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxLQUFLO0lBQUksR0FBRyxFQUFFLElBQUksRUFBRSxLQUFLO0dBQUc7R0FDdEQsSUFBSSxRQUFRO0dBQVUsSUFBSSxTQUFzQjtHQUNoRCxLQUFLLE1BQU0sUUFBUSxLQUFLLElBQUksV0FBVztJQUNyQyxNQUFNLElBQUksWUFBWSxHQUFHLE1BQU0sTUFBTSxLQUFLLE9BQU8sT0FBTyxNQUFNO0lBQUcsSUFBSSxNQUFNLFFBQVEsSUFBSSxPQUFPLFFBQVE7R0FDeEc7R0FDQSxLQUFLLE1BQU0sUUFBUSxFQUFFLFVBQVUsV0FBVyxLQUFLLFVBQVUsQ0FBQyxLQUFLLE1BQU0sR0FBRztJQUN0RSxJQUFJLENBQUMsS0FBSyxPQUFPO0lBQ2pCLE1BQU0sSUFBSSxjQUFjLEdBQUcsTUFBTSxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU8sT0FBTyxNQUFNO0lBQzlFLElBQUksTUFBTSxRQUFRLElBQUksT0FBTztLQUFFLFFBQVE7S0FBRyxTQUFTO0lBQU07R0FDM0Q7R0FDQSxJQUFJLFVBQVUsVUFBVTtJQUN0QixJQUFJLFFBQVEsS0FBSyxPQUFPLFFBQVEsRUFBRSxRQUFRLEVBQUUsVUFBVSxRQUFRO1NBQ3pEO0tBQUUsS0FBSyxPQUFPO01BQUUsR0FBRyxFQUFFLEtBQUssS0FBSyxJQUFJLEVBQUUsS0FBSztNQUFPLEdBQUcsRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLEtBQUs7S0FBTSxHQUFHLFFBQVE7S0FBRyxLQUFLLE9BQU8sS0FBSyxRQUFRO0lBQUc7SUFDaEksT0FBTztHQUNUO0dBQ0EsRUFBRSxJQUFJLEtBQUs7R0FBRyxFQUFFLElBQUksS0FBSztHQUFHLEVBQUUsT0FBTztHQUNyQyxPQUFPLEVBQUUsTUFBTSxLQUFLLE9BQU8sT0FBTyxZQUFZLEtBQUssS0FBSyxHQUFHLENBQUM7RUFDOUQsQ0FBQztFQUNELEtBQUssVUFBVSxLQUFLLFFBQVEsUUFBUSxNQUFNLEVBQUUsS0FBSztFQUNqRCxLQUFLLFVBQVUsS0FBSyxRQUFRLFFBQVEsTUFBTTtHQUFFLEVBQUUsT0FBTztHQUFJLE9BQU8sRUFBRSxNQUFNLEVBQUU7RUFBVSxDQUFDO0VBQ3JGLElBQUksS0FBSyxPQUFPLGlCQUFpQixLQUFLLFdBQVcsTUFBTSxDQUFDLEtBQUssWUFBWTtHQUFFLEtBQUssYUFBYTtHQUFNLEtBQUssT0FBTyxLQUFLLGNBQWM7RUFBRztFQUNySSxJQUFJLENBQUMsS0FBSyxPQUFPLFNBQVMsS0FBSyxXQUFXLEtBQUssT0FBTyxpQkFBaUIsTUFBTTtHQUMzRSxLQUFLLFNBQVMsS0FBSyxPQUFPLFFBQVEsU0FBUztHQUFTLEtBQUssU0FBUztFQUNwRTtDQUNGO0NBQ0EsY0FBYztFQUFFLE1BQU0sU0FBUyxLQUFLO0VBQVEsS0FBSyxTQUFTLENBQUM7RUFBRyxPQUFPO0NBQVE7Q0FDN0UsV0FBcUI7RUFBRSxPQUFPO0dBQUUsUUFBUSxLQUFLO0dBQVEsU0FBUyxLQUFLO0dBQ2pFLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLGlCQUFpQixLQUFLLE9BQU87R0FBRyxPQUFPLEtBQUs7R0FDL0UsUUFBUSxLQUFLLE9BQU87R0FBUSxXQUFXLEtBQUssT0FBTztHQUFXLFNBQVMsS0FBSyxRQUFRO0dBQVEsUUFBUSxLQUFLO0VBQU87Q0FBRztBQUN2SCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzaW11bGF0aW9uLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgR2FtZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcbmltcG9ydCB0eXBlIHsgTG9hZGVkTWFwIH0gZnJvbSAnLi90aWxlZE1hcCc7XG5pbXBvcnQgeyBhbmdsZURpZmZlcmVuY2UsIGFuZ2xlVG8sIGNpcmNsZVJlY3QsIGRpc3RhbmNlLCBOYXZpZ2F0aW9uLCBzZWdtZW50Q2lyY2xlLCBzZWdtZW50UmVjdCB9IGZyb20gJy4vZ2VvbWV0cnknO1xuaW1wb3J0IHR5cGUgeyBQb2ludCB9IGZyb20gJy4vZ2VvbWV0cnknO1xuZXhwb3J0IHR5cGUgQWN0aW9uID0gJ2ZvcndhcmQnIHwgJ2xlZnQnIHwgJ3JpZ2h0JyB8ICdmcm9udCcgfCAncG9ydCcgfCAnc3RhcmJvYXJkJztcbmV4cG9ydCB0eXBlIEVuZFJlYXNvbiA9ICd0aW1lJyB8ICdkZWF0aCc7XG5leHBvcnQgdHlwZSBHYW1lRXZlbnQgPSAnZnJvbnQtc2hvdCcgfCAnc2lkZS1zaG90JyB8ICdlbmVteS1zaG90JyB8ICdpbXBhY3QnIHwgJ2V4cGxvc2lvbicgfCAnc2NvcmUnIHwgJ2xvdy1oZWFsdGgnIHwgJ3RpbWUtd2FybmluZyc7XG5leHBvcnQgaW50ZXJmYWNlIFNoaXAgZXh0ZW5kcyBQb2ludCB7IGlkOiBudW1iZXI7IGtpbmQ6ICdwbGF5ZXInIHwgJ2NoYXNlcicgfCAnc2hvb3Rlcic7IGFuZ2xlOiBudW1iZXI7XG4gIGhlYWx0aDogbnVtYmVyOyBtYXhIZWFsdGg6IG51bWJlcjsgcmFkaXVzOiBudW1iZXI7IGFsaXZlOiBib29sZWFuOyBmaXJlQXQ6IG51bWJlcjsgcm91dGVBdDogbnVtYmVyOyByb3V0ZTogUG9pbnRbXSB9XG5leHBvcnQgaW50ZXJmYWNlIFByb2plY3RpbGUgZXh0ZW5kcyBQb2ludCB7IGlkOiBudW1iZXI7IHZ4OiBudW1iZXI7IHZ5OiBudW1iZXI7IGRhbWFnZTogbnVtYmVyO1xuICBvd25lcjogJ3BsYXllcicgfCAnZW5lbXknOyBhZ2U6IG51bWJlciB9XG5leHBvcnQgaW50ZXJmYWNlIEVmZmVjdCBleHRlbmRzIFBvaW50IHsgaWQ6IG51bWJlcjsga2luZDogJ211enpsZScgfCAnaW1wYWN0JyB8ICdleHBsb3Npb24nOyBhbmdsZTogbnVtYmVyOyBhZ2U6IG51bWJlcjsgZHVyYXRpb246IG51bWJlciB9XG5leHBvcnQgaW50ZXJmYWNlIFNuYXBzaG90IHsgc3RhdHVzOiAncGxheWluZycgfCAncGF1c2VkJyB8ICdlbmRlZCc7IGVsYXBzZWQ6IG51bWJlcjsgcmVtYWluaW5nOiBudW1iZXI7XG4gIHNjb3JlOiBudW1iZXI7IGhlYWx0aDogbnVtYmVyOyBtYXhIZWFsdGg6IG51bWJlcjsgZW5lbWllczogbnVtYmVyOyByZWFzb246IEVuZFJlYXNvbiB8IG51bGwgfVxuZXhwb3J0IGNsYXNzIFNpbXVsYXRpb24ge1xuICByZWFkb25seSBwbGF5ZXI6IFNoaXA7XG4gIGVuZW1pZXM6IFNoaXBbXSA9IFtdOyBwcm9qZWN0aWxlczogUHJvamVjdGlsZVtdID0gW107IGVmZmVjdHM6IEVmZmVjdFtdID0gW107XG4gIHN0YXR1czogU25hcHNob3RbJ3N0YXR1cyddID0gJ3BsYXlpbmcnOyBlbGFwc2VkID0gMDsgc2NvcmUgPSAwOyByZWFzb246IEVuZFJlYXNvbiB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIG5leHRJZCA9IDE7IHByaXZhdGUgcmFuZG9tU3RhdGU6IG51bWJlcjsgcHJpdmF0ZSBzcGF3bkF0OiBudW1iZXI7IHByaXZhdGUgc3Bhd25Db3VudCA9IDA7XG4gIHByaXZhdGUgY29vbGRvd24gPSB7IGZyb250OiAwLCBwb3J0OiAwLCBzdGFyYm9hcmQ6IDAgfTsgcHJpdmF0ZSBldmVudHM6IEdhbWVFdmVudFtdID0gW107XG4gIHByaXZhdGUgbmF2aWdhdGlvbjogTmF2aWdhdGlvbjsgcHJpdmF0ZSB3YXJuZWRUaW1lID0gZmFsc2U7IHByaXZhdGUgd2FybmVkSGVhbHRoID0gZmFsc2U7XG4gIHJlYWRvbmx5IHdpZHRoOiBudW1iZXI7IHJlYWRvbmx5IGhlaWdodDogbnVtYmVyO1xuICBjb25zdHJ1Y3RvcihyZWFkb25seSBjb25maWc6IEdhbWVDb25maWcsIHJlYWRvbmx5IG1hcDogTG9hZGVkTWFwKSB7XG4gICAgdGhpcy53aWR0aCA9IG1hcC53aWR0aCAqIG1hcC50aWxlV2lkdGg7IHRoaXMuaGVpZ2h0ID0gbWFwLmhlaWdodCAqIG1hcC50aWxlSGVpZ2h0O1xuICAgIHRoaXMucmFuZG9tU3RhdGUgPSBjb25maWcuc2VlZDsgdGhpcy5zcGF3bkF0ID0gY29uZmlnLnNwYXduU2Vjb25kcztcbiAgICB0aGlzLnBsYXllciA9IHsgLi4uY29uZmlnLnBsYXllciwgbWF4SGVhbHRoOiBjb25maWcucGxheWVyLmhlYWx0aCwgYW5nbGU6IDAsIGlkOiAwLFxuICAgICAga2luZDogJ3BsYXllcicsIGFsaXZlOiB0cnVlLCBmaXJlQXQ6IDAsIHJvdXRlQXQ6IDAsIHJvdXRlOiBbXSB9O1xuICAgIGlmICghdGhpcy5mcmVlKHRoaXMucGxheWVyLCB0aGlzLnBsYXllci5yYWRpdXMpKSB0aHJvdyBuZXcgRXJyb3IoJ0F1dGhvcmVkIHBsYXllciBzcGF3biBpcyBvYnN0cnVjdGVkLicpO1xuICAgIGZvciAoY29uc3QgcG9pbnQgb2YgY29uZmlnLnNwYXduUG9pbnRzKSBpZiAoIXRoaXMuZnJlZShwb2ludCwgY29uZmlnLmVuZW15LnJhZGl1cykpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0F1dGhvcmVkIGVuZW15IHNwYXduIGlzIG9ic3RydWN0ZWQuJyk7XG4gICAgdGhpcy5uYXZpZ2F0aW9uID0gbmV3IE5hdmlnYXRpb24obWFwLndpZHRoLCBtYXAuaGVpZ2h0LCBtYXAudGlsZVdpZHRoLCBjb25maWcuZW5lbXkucmFkaXVzLCBtYXAuY29sbGlkZXJzKTtcbiAgfVxuICBwcml2YXRlIHJhbmRvbSgpIHsgdGhpcy5yYW5kb21TdGF0ZSA9ICgxNjY0NTI1ICogdGhpcy5yYW5kb21TdGF0ZSArIDEwMTM5MDQyMjMpID4+PiAwOyByZXR1cm4gdGhpcy5yYW5kb21TdGF0ZSAvIDQyOTQ5NjcyOTY7IH1cbiAgcHJpdmF0ZSBmcmVlKHA6IFBvaW50LCByOiBudW1iZXIpIHsgcmV0dXJuIHAueCA+PSByICYmIHAueSA+PSByICYmIHAueCA8PSB0aGlzLndpZHRoIC0gclxuICAgICYmIHAueSA8PSB0aGlzLmhlaWdodCAtIHIgJiYgIXRoaXMubWFwLmNvbGxpZGVycy5zb21lKChyZWN0KSA9PiBjaXJjbGVSZWN0KHAsIHIsIHJlY3QpKTsgfVxuICBwcml2YXRlIHZpc2libGUoYTogUG9pbnQsIGI6IFBvaW50LCBwYWRkaW5nOiBudW1iZXIpIHtcbiAgICByZXR1cm4gIXRoaXMubWFwLmNvbGxpZGVycy5zb21lKChyKSA9PiBzZWdtZW50UmVjdChhLCBiLCByLCBwYWRkaW5nKSAhPT0gbnVsbCk7XG4gIH1cbiAgcHJpdmF0ZSBtb3ZlKHNoaXA6IFNoaXAsIHNwZWVkOiBudW1iZXIsIGR0OiBudW1iZXIpIHtcbiAgICBjb25zdCBkeCA9IE1hdGguc2luKHNoaXAuYW5nbGUpICogc3BlZWQgKiBkdDsgY29uc3QgZHkgPSAtTWF0aC5jb3Moc2hpcC5hbmdsZSkgKiBzcGVlZCAqIGR0O1xuICAgIGNvbnN0IG5leHQgPSB7IHg6IE1hdGgubWF4KHNoaXAucmFkaXVzLCBNYXRoLm1pbih0aGlzLndpZHRoIC0gc2hpcC5yYWRpdXMsIHNoaXAueCArIGR4KSksXG4gICAgICB5OiBNYXRoLm1heChzaGlwLnJhZGl1cywgTWF0aC5taW4odGhpcy5oZWlnaHQgLSBzaGlwLnJhZGl1cywgc2hpcC55ICsgZHkpKSB9O1xuICAgIGlmICh0aGlzLmZyZWUobmV4dCwgc2hpcC5yYWRpdXMpKSB7IHNoaXAueCA9IG5leHQueDsgc2hpcC55ID0gbmV4dC55OyB9XG4gICAgZWxzZSB7XG4gICAgICAvLyBBeGlzIHNsaWRpbmcgYXZvaWRzIHN0aWNraW5nIHdoaWxlIHByZXNlcnZpbmcgY2lyY2xlL3JlY3RhbmdsZSBjb250YWN0cy5cbiAgICAgIGlmICh0aGlzLmZyZWUoeyB4OiBuZXh0LngsIHk6IHNoaXAueSB9LCBzaGlwLnJhZGl1cykpIHNoaXAueCA9IG5leHQueDtcbiAgICAgIGlmICh0aGlzLmZyZWUoeyB4OiBzaGlwLngsIHk6IG5leHQueSB9LCBzaGlwLnJhZGl1cykpIHNoaXAueSA9IG5leHQueTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBlZmZlY3QocDogUG9pbnQsIGtpbmQ6IEVmZmVjdFsna2luZCddLCBhbmdsZSA9IDApIHtcbiAgICB0aGlzLmVmZmVjdHMucHVzaCh7IC4uLnAsIGlkOiB0aGlzLm5leHRJZCsrLCBraW5kLCBhbmdsZSwgYWdlOiAwLCBkdXJhdGlvbjogdGhpcy5jb25maWcuZWZmZWN0c1traW5kXSB9KTtcbiAgfVxuICBwcml2YXRlIHNob290KHNoaXA6IFNoaXAsIHNpZGU6IC0xIHwgMCB8IDEpIHtcbiAgICBjb25zdCB3ID0gdGhpcy5jb25maWcud2VhcG9uOyBjb25zdCBhbmdsZSA9IHNoaXAuYW5nbGUgKyBzaWRlICogTWF0aC5QSSAvIDI7XG4gICAgY29uc3Qgb3JpZ2luID0geyB4OiBzaGlwLnggKyBNYXRoLnNpbihhbmdsZSkgKiAoc2lkZSA/IHcuc2lkZU9mZnNldCA6IHcuZnJvbnRPZmZzZXQpLFxuICAgICAgeTogc2hpcC55IC0gTWF0aC5jb3MoYW5nbGUpICogKHNpZGUgPyB3LnNpZGVPZmZzZXQgOiB3LmZyb250T2Zmc2V0KSB9O1xuICAgIGNvbnN0IGVuZW15ID0gc2hpcC5raW5kICE9PSAncGxheWVyJztcbiAgICBmb3IgKGNvbnN0IHNoaWZ0IG9mIHNpZGUgPyBbLXcucGFyYWxsZWxTcGFjaW5nLCAwLCB3LnBhcmFsbGVsU3BhY2luZ10gOiBbMF0pIHtcbiAgICAgIHRoaXMucHJvamVjdGlsZXMucHVzaCh7IGlkOiB0aGlzLm5leHRJZCsrLCB4OiBvcmlnaW4ueCArIE1hdGguc2luKHNoaXAuYW5nbGUpICogc2hpZnQsXG4gICAgICAgIHk6IG9yaWdpbi55IC0gTWF0aC5jb3Moc2hpcC5hbmdsZSkgKiBzaGlmdCwgdng6IE1hdGguc2luKGFuZ2xlKSAqIChlbmVteSA/IHcuZW5lbXlTcGVlZCA6IHcuc3BlZWQpLFxuICAgICAgICB2eTogLU1hdGguY29zKGFuZ2xlKSAqIChlbmVteSA/IHcuZW5lbXlTcGVlZCA6IHcuc3BlZWQpLCBkYW1hZ2U6IGVuZW15ID8gdy5lbmVteURhbWFnZSA6IHNpZGUgPyB3LnNpZGVEYW1hZ2UgOiB3LmZyb250RGFtYWdlLFxuICAgICAgICBvd25lcjogZW5lbXkgPyAnZW5lbXknIDogJ3BsYXllcicsIGFnZTogMCB9KTtcbiAgICB9XG4gICAgdGhpcy5lZmZlY3Qob3JpZ2luLCAnbXV6emxlJywgYW5nbGUpOyB0aGlzLmV2ZW50cy5wdXNoKGVuZW15ID8gJ2VuZW15LXNob3QnIDogc2lkZSA/ICdzaWRlLXNob3QnIDogJ2Zyb250LXNob3QnKTtcbiAgfVxuICBwcml2YXRlIGRhbWFnZShzaGlwOiBTaGlwLCBhbW91bnQ6IG51bWJlciwgY3JlZGl0ZWQ6IGJvb2xlYW4pIHtcbiAgICBpZiAoIXNoaXAuYWxpdmUpIHJldHVybjtcbiAgICBzaGlwLmhlYWx0aCA9IE1hdGgubWF4KDAsIHNoaXAuaGVhbHRoIC0gYW1vdW50KTsgdGhpcy5ldmVudHMucHVzaCgnaW1wYWN0Jyk7IHRoaXMuZWZmZWN0KHNoaXAsICdpbXBhY3QnKTtcbiAgICBpZiAoIXNoaXAuaGVhbHRoKSB7XG4gICAgICBzaGlwLmFsaXZlID0gZmFsc2U7IHRoaXMuZWZmZWN0KHNoaXAsICdleHBsb3Npb24nKTsgdGhpcy5ldmVudHMucHVzaCgnZXhwbG9zaW9uJyk7XG4gICAgICBpZiAoc2hpcC5raW5kICE9PSAncGxheWVyJyAmJiBjcmVkaXRlZCkgeyB0aGlzLnNjb3JlKys7IHRoaXMuZXZlbnRzLnB1c2goJ3Njb3JlJyk7IH1cbiAgICB9XG4gICAgaWYgKHNoaXAua2luZCA9PT0gJ3BsYXllcicgJiYgc2hpcC5oZWFsdGggPD0gc2hpcC5tYXhIZWFsdGggKiAwLjMgJiYgIXRoaXMud2FybmVkSGVhbHRoKSB7XG4gICAgICB0aGlzLndhcm5lZEhlYWx0aCA9IHRydWU7IHRoaXMuZXZlbnRzLnB1c2goJ2xvdy1oZWFsdGgnKTtcbiAgICB9XG4gIH1cbiAgcHJpdmF0ZSBzcGF3bigpIHtcbiAgICBpZiAodGhpcy5lbmVtaWVzLmxlbmd0aCA+PSB0aGlzLmNvbmZpZy5lbmVteS5tYXhDb3VudCkgcmV0dXJuO1xuICAgIGNvbnN0IHZhbGlkID0gdGhpcy5jb25maWcuc3Bhd25Qb2ludHMuZmlsdGVyKChwKSA9PiBkaXN0YW5jZShwLCB0aGlzLnBsYXllcikgPj0gdGhpcy5jb25maWcuZW5lbXkuc2FmZVNwYXduRGlzdGFuY2VcbiAgICAgICYmICF0aGlzLmVuZW1pZXMuc29tZSgoZSkgPT4gZGlzdGFuY2UoZSwgcCkgPCBlLnJhZGl1cyAqIDMpKTtcbiAgICBpZiAoIXZhbGlkLmxlbmd0aCkgcmV0dXJuO1xuICAgIGNvbnN0IHBvaW50ID0gdmFsaWRbTWF0aC5mbG9vcih0aGlzLnJhbmRvbSgpICogdmFsaWQubGVuZ3RoKV0hO1xuICAgIGNvbnN0IGtpbmQgPSB0aGlzLnNwYXduQ291bnQgPT09IDAgPyAnY2hhc2VyJyA6IHRoaXMuc3Bhd25Db3VudCA9PT0gMSA/ICdzaG9vdGVyJ1xuICAgICAgOiB0aGlzLnJhbmRvbSgpIDwgdGhpcy5jb25maWcuZW5lbXkuc2hvb3RlcldlaWdodCA/ICdzaG9vdGVyJyA6ICdjaGFzZXInO1xuICAgIGNvbnN0IGhlYWx0aCA9IGtpbmQgPT09ICdjaGFzZXInID8gdGhpcy5jb25maWcuZW5lbXkuY2hhc2VySGVhbHRoIDogdGhpcy5jb25maWcuZW5lbXkuc2hvb3RlckhlYWx0aDtcbiAgICB0aGlzLmVuZW1pZXMucHVzaCh7IC4uLnBvaW50LCBpZDogdGhpcy5uZXh0SWQrKywga2luZCwgcmFkaXVzOiB0aGlzLmNvbmZpZy5lbmVteS5yYWRpdXMsXG4gICAgICBoZWFsdGgsIG1heEhlYWx0aDogaGVhbHRoLCBhbmdsZTogYW5nbGVUbyhwb2ludCwgdGhpcy5wbGF5ZXIpLCBhbGl2ZTogdHJ1ZSwgZmlyZUF0OiAwLCByb3V0ZUF0OiAwLCByb3V0ZTogW10gfSk7XG4gICAgdGhpcy5zcGF3bkNvdW50Kys7XG4gIH1cbiAgcGF1c2UoKSB7IGlmICh0aGlzLnN0YXR1cyA9PT0gJ3BsYXlpbmcnKSB0aGlzLnN0YXR1cyA9ICdwYXVzZWQnOyB9XG4gIHJlc3VtZSgpIHsgaWYgKHRoaXMuc3RhdHVzID09PSAncGF1c2VkJykgdGhpcy5zdGF0dXMgPSAncGxheWluZyc7IH1cbiAgc3RlcChkdDogbnVtYmVyLCBpbnB1dDogUmVhZG9ubHlTZXQ8QWN0aW9uPikge1xuICAgIGlmICh0aGlzLnN0YXR1cyAhPT0gJ3BsYXlpbmcnKSByZXR1cm47XG4gICAgZHQgPSBNYXRoLm1pbihkdCwgdGhpcy5jb25maWcuc2Vzc2lvblNlY29uZHMgLSB0aGlzLmVsYXBzZWQpO1xuICAgIHRoaXMuZWxhcHNlZCArPSBkdDtcbiAgICB0aGlzLnBsYXllci5hbmdsZSArPSAoKGlucHV0LmhhcygncmlnaHQnKSA/IDEgOiAwKSAtIChpbnB1dC5oYXMoJ2xlZnQnKSA/IDEgOiAwKSkgKiB0aGlzLmNvbmZpZy5wbGF5ZXIudHVyblNwZWVkICogZHQ7XG4gICAgaWYgKGlucHV0LmhhcygnZm9yd2FyZCcpKSB0aGlzLm1vdmUodGhpcy5wbGF5ZXIsIHRoaXMuY29uZmlnLnBsYXllci5zcGVlZCwgZHQpO1xuICAgIGZvciAoY29uc3QgYWN0aW9uIG9mIFsnZnJvbnQnLCAncG9ydCcsICdzdGFyYm9hcmQnXSBhcyBjb25zdCkge1xuICAgICAgaWYgKGlucHV0LmhhcyhhY3Rpb24pICYmIHRoaXMuZWxhcHNlZCArIDFlLTggPj0gdGhpcy5jb29sZG93blthY3Rpb25dKSB7XG4gICAgICAgIHRoaXMuc2hvb3QodGhpcy5wbGF5ZXIsIGFjdGlvbiA9PT0gJ2Zyb250JyA/IDAgOiBhY3Rpb24gPT09ICdwb3J0JyA/IC0xIDogMSk7XG4gICAgICAgIHRoaXMuY29vbGRvd25bYWN0aW9uXSA9IHRoaXMuZWxhcHNlZCArIChhY3Rpb24gPT09ICdmcm9udCcgPyB0aGlzLmNvbmZpZy53ZWFwb24uZnJvbnRDb29sZG93biA6IHRoaXMuY29uZmlnLndlYXBvbi5zaWRlQ29vbGRvd24pO1xuICAgICAgfVxuICAgIH1cbiAgICB3aGlsZSAodGhpcy5lbGFwc2VkICsgMWUtOCA+PSB0aGlzLnNwYXduQXQpIHsgdGhpcy5zcGF3bigpOyB0aGlzLnNwYXduQXQgKz0gdGhpcy5jb25maWcuc3Bhd25TZWNvbmRzOyB9XG4gICAgZm9yIChjb25zdCBlbmVteSBvZiB0aGlzLmVuZW1pZXMpIHtcbiAgICAgIGlmICghZW5lbXkuYWxpdmUgfHwgIXRoaXMucGxheWVyLmFsaXZlKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IHNpZ2h0ID0gdGhpcy52aXNpYmxlKGVuZW15LCB0aGlzLnBsYXllciwgZW5lbXkucmFkaXVzKTtcbiAgICAgIGxldCB0YXJnZXQ6IFBvaW50ID0gdGhpcy5wbGF5ZXI7XG4gICAgICBpZiAoIXNpZ2h0KSB7XG4gICAgICAgIGlmICh0aGlzLmVsYXBzZWQgPj0gZW5lbXkucm91dGVBdCkgeyBlbmVteS5yb3V0ZSA9IHRoaXMubmF2aWdhdGlvbi5yb3V0ZShlbmVteSwgdGhpcy5wbGF5ZXIpO1xuICAgICAgICAgIGVuZW15LnJvdXRlQXQgPSB0aGlzLmVsYXBzZWQgKyB0aGlzLmNvbmZpZy5lbmVteS5yb3V0ZUludGVydmFsOyB9XG4gICAgICAgIHdoaWxlIChlbmVteS5yb3V0ZS5sZW5ndGggJiYgZGlzdGFuY2UoZW5lbXksIGVuZW15LnJvdXRlWzBdISkgPCAyMikgZW5lbXkucm91dGUuc2hpZnQoKTtcbiAgICAgICAgdGFyZ2V0ID0gZW5lbXkucm91dGVbMF0gPz8gZW5lbXk7XG4gICAgICB9XG4gICAgICBjb25zdCB0dXJuID0gYW5nbGVEaWZmZXJlbmNlKGFuZ2xlVG8oZW5lbXksIHRhcmdldCksIGVuZW15LmFuZ2xlKTtcbiAgICAgIGVuZW15LmFuZ2xlICs9IE1hdGgubWF4KC10aGlzLmNvbmZpZy5lbmVteS50dXJuU3BlZWQgKiBkdCwgTWF0aC5taW4odGhpcy5jb25maWcuZW5lbXkudHVyblNwZWVkICogZHQsIHR1cm4pKTtcbiAgICAgIGNvbnN0IGluUmFuZ2UgPSBkaXN0YW5jZShlbmVteSwgdGhpcy5wbGF5ZXIpIDw9IHRoaXMuY29uZmlnLmVuZW15LnJhbmdlICYmIHNpZ2h0O1xuICAgICAgaWYgKCEoZW5lbXkua2luZCA9PT0gJ3Nob290ZXInICYmIGluUmFuZ2UpICYmIE1hdGguYWJzKHR1cm4pIDwgMS4yKSB7XG4gICAgICAgIHRoaXMubW92ZShlbmVteSwgZW5lbXkua2luZCA9PT0gJ3Nob290ZXInID8gdGhpcy5jb25maWcuZW5lbXkuc2hvb3RlclNwZWVkIDogdGhpcy5jb25maWcuZW5lbXkuY2hhc2VyU3BlZWQsIGR0KTtcbiAgICAgIH1cbiAgICAgIGlmIChlbmVteS5raW5kID09PSAnc2hvb3RlcicgJiYgaW5SYW5nZSAmJiBNYXRoLmFicyh0dXJuKSA8IDAuMTggJiYgdGhpcy5lbGFwc2VkID49IGVuZW15LmZpcmVBdCkge1xuICAgICAgICB0aGlzLnNob290KGVuZW15LCAwKTsgZW5lbXkuZmlyZUF0ID0gdGhpcy5lbGFwc2VkICsgdGhpcy5jb25maWcuZW5lbXkuY29vbGRvd247XG4gICAgICB9XG4gICAgICBpZiAoZW5lbXkua2luZCA9PT0gJ2NoYXNlcicgJiYgZGlzdGFuY2UoZW5lbXksIHRoaXMucGxheWVyKSA8IGVuZW15LnJhZGl1cyArIHRoaXMucGxheWVyLnJhZGl1cykge1xuICAgICAgICB0aGlzLmRhbWFnZSh0aGlzLnBsYXllciwgdGhpcy5jb25maWcuZW5lbXkucmFtRGFtYWdlLCBmYWxzZSk7IHRoaXMuZGFtYWdlKGVuZW15LCBlbmVteS5oZWFsdGgsIGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCF0aGlzLnBsYXllci5hbGl2ZSkgeyB0aGlzLnJlYXNvbiA9ICdkZWF0aCc7IHRoaXMuc3RhdHVzID0gJ2VuZGVkJzsgcmV0dXJuOyB9XG4gICAgdGhpcy5wcm9qZWN0aWxlcyA9IHRoaXMucHJvamVjdGlsZXMuZmlsdGVyKChwKSA9PiB7XG4gICAgICBpZiAoIXRoaXMucGxheWVyLmFsaXZlKSByZXR1cm4gZmFsc2U7XG4gICAgICBjb25zdCBuZXh0ID0geyB4OiBwLnggKyBwLnZ4ICogZHQsIHk6IHAueSArIHAudnkgKiBkdCB9O1xuICAgICAgbGV0IGZpcnN0ID0gSW5maW5pdHk7IGxldCB2aWN0aW06IFNoaXAgfCBudWxsID0gbnVsbDtcbiAgICAgIGZvciAoY29uc3QgcmVjdCBvZiB0aGlzLm1hcC5jb2xsaWRlcnMpIHtcbiAgICAgICAgY29uc3QgdCA9IHNlZ21lbnRSZWN0KHAsIG5leHQsIHJlY3QsIHRoaXMuY29uZmlnLndlYXBvbi5yYWRpdXMpOyBpZiAodCAhPT0gbnVsbCAmJiB0IDwgZmlyc3QpIGZpcnN0ID0gdDtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3Qgc2hpcCBvZiBwLm93bmVyID09PSAncGxheWVyJyA/IHRoaXMuZW5lbWllcyA6IFt0aGlzLnBsYXllcl0pIHtcbiAgICAgICAgaWYgKCFzaGlwLmFsaXZlKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgdCA9IHNlZ21lbnRDaXJjbGUocCwgbmV4dCwgc2hpcCwgc2hpcC5yYWRpdXMgKyB0aGlzLmNvbmZpZy53ZWFwb24ucmFkaXVzKTtcbiAgICAgICAgaWYgKHQgIT09IG51bGwgJiYgdCA8IGZpcnN0KSB7IGZpcnN0ID0gdDsgdmljdGltID0gc2hpcDsgfVxuICAgICAgfVxuICAgICAgaWYgKGZpcnN0ICE9PSBJbmZpbml0eSkge1xuICAgICAgICBpZiAodmljdGltKSB0aGlzLmRhbWFnZSh2aWN0aW0sIHAuZGFtYWdlLCBwLm93bmVyID09PSAncGxheWVyJyk7XG4gICAgICAgIGVsc2UgeyB0aGlzLmVmZmVjdCh7IHg6IHAueCArIChuZXh0LnggLSBwLngpICogZmlyc3QsIHk6IHAueSArIChuZXh0LnkgLSBwLnkpICogZmlyc3QgfSwgJ2ltcGFjdCcpOyB0aGlzLmV2ZW50cy5wdXNoKCdpbXBhY3QnKTsgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBwLnggPSBuZXh0Lng7IHAueSA9IG5leHQueTsgcC5hZ2UgKz0gZHQ7XG4gICAgICByZXR1cm4gcC5hZ2UgPCB0aGlzLmNvbmZpZy53ZWFwb24ubGlmZXRpbWUgJiYgdGhpcy5mcmVlKHAsIDApO1xuICAgIH0pO1xuICAgIHRoaXMuZW5lbWllcyA9IHRoaXMuZW5lbWllcy5maWx0ZXIoKGUpID0+IGUuYWxpdmUpO1xuICAgIHRoaXMuZWZmZWN0cyA9IHRoaXMuZWZmZWN0cy5maWx0ZXIoKGUpID0+IHsgZS5hZ2UgKz0gZHQ7IHJldHVybiBlLmFnZSA8IGUuZHVyYXRpb247IH0pO1xuICAgIGlmICh0aGlzLmNvbmZpZy5zZXNzaW9uU2Vjb25kcyAtIHRoaXMuZWxhcHNlZCA8PSAxMCAmJiAhdGhpcy53YXJuZWRUaW1lKSB7IHRoaXMud2FybmVkVGltZSA9IHRydWU7IHRoaXMuZXZlbnRzLnB1c2goJ3RpbWUtd2FybmluZycpOyB9XG4gICAgaWYgKCF0aGlzLnBsYXllci5hbGl2ZSB8fCB0aGlzLmVsYXBzZWQgPj0gdGhpcy5jb25maWcuc2Vzc2lvblNlY29uZHMgLSAxZS04KSB7XG4gICAgICB0aGlzLnJlYXNvbiA9IHRoaXMucGxheWVyLmFsaXZlID8gJ3RpbWUnIDogJ2RlYXRoJzsgdGhpcy5zdGF0dXMgPSAnZW5kZWQnO1xuICAgIH1cbiAgfVxuICBkcmFpbkV2ZW50cygpIHsgY29uc3QgZXZlbnRzID0gdGhpcy5ldmVudHM7IHRoaXMuZXZlbnRzID0gW107IHJldHVybiBldmVudHM7IH1cbiAgc25hcHNob3QoKTogU25hcHNob3QgeyByZXR1cm4geyBzdGF0dXM6IHRoaXMuc3RhdHVzLCBlbGFwc2VkOiB0aGlzLmVsYXBzZWQsXG4gICAgcmVtYWluaW5nOiBNYXRoLm1heCgwLCB0aGlzLmNvbmZpZy5zZXNzaW9uU2Vjb25kcyAtIHRoaXMuZWxhcHNlZCksIHNjb3JlOiB0aGlzLnNjb3JlLFxuICAgIGhlYWx0aDogdGhpcy5wbGF5ZXIuaGVhbHRoLCBtYXhIZWFsdGg6IHRoaXMucGxheWVyLm1heEhlYWx0aCwgZW5lbWllczogdGhpcy5lbmVtaWVzLmxlbmd0aCwgcmVhc29uOiB0aGlzLnJlYXNvbiB9OyB9XG59XG4iXX0=