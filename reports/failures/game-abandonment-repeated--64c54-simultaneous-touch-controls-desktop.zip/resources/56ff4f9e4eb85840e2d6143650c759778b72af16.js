import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/GameCanvas.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport11_react_jsxDevRuntime["Fragment"];import { Application } from "/node_modules/.vite/deps/pixi__js.js?v=4e6cb03b";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=4e6cb03b";
import { loadTiledMap } from "/src/game/tiledMap.ts?t=1791840048673";
import { MapRenderer } from "/src/game/mapRenderer.ts";
import { loadGameTextures } from "/src/game/assets.ts";
import { ArenaRenderer } from "/src/game/renderer.ts?t=1791841466585";
import { Simulation } from "/src/game/simulation.ts?t=1791841426883";
import { InputController } from "/src/game/input.ts";
import { audio } from "/src/game/audio.ts";
import { Button, ControlsHelp, Dialog, uiAsset } from "/src/ui/components.tsx";
import "/src/ui/GameCanvas.css?t=1791841426865";
var _jsxFileName = "C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4e6cb03b";
var _s = $RefreshSig$();
const commands = [
	{
		action: "left",
		label: "Turn left",
		icon: "turn_left"
	},
	{
		action: "forward",
		label: "Forward",
		icon: "forward"
	},
	{
		action: "right",
		label: "Turn right",
		icon: "turn_right"
	},
	{
		action: "port",
		label: "Left broadside",
		icon: "fire_left"
	},
	{
		action: "front",
		label: "Front cannon",
		icon: "fire_front"
	},
	{
		action: "starboard",
		label: "Right broadside",
		icon: "fire_right"
	}
];
export function GameCanvas({ config, onComplete, onAbandon }) {
	_s();
	const rootRef = useRef(null);
	const viewportRef = useRef(null);
	const canvasRef = useRef(null);
	const queue = useRef(Promise.resolve());
	const simRef = useRef(null);
	const inputRef = useRef(null);
	const callbacks = useRef({
		onComplete,
		onAbandon
	});
	callbacks.current = {
		onComplete,
		onAbandon
	};
	const [status, setStatus] = useState("loading");
	const [error, setError] = useState("");
	const [progress, setProgress] = useState(0);
	const [attempt, setAttempt] = useState(0);
	const [snapshot, setSnapshot] = useState(null);
	const [abandon, setAbandon] = useState(false);
	function pause() {
		const sim = simRef.current;
		if (!sim || sim.status !== "playing") return;
		sim.pause();
		inputRef.current?.setActive(false);
		audio.ambience(false, false);
		audio.play("game_pause");
		setSnapshot(sim.snapshot());
	}
	function resume() {
		const sim = simRef.current;
		if (!sim || sim.status !== "paused" || document.hidden) return;
		if (matchMedia("(orientation: portrait)").matches) return;
		sim.resume();
		inputRef.current?.setActive(true);
		audio.play("game_resume");
		setSnapshot(sim.snapshot());
		requestAnimationFrame(() => rootRef.current?.focus());
	}
	useEffect(() => {
		const root = rootRef.current;
		const canvas = canvasRef.current;
		const host = viewportRef.current;
		if (!root || !canvas || !host) throw new Error("The arena requires its authored viewport and canvas.");
		let disposed = false;
		let initialized = false;
		let app = null;
		let mapView = null;
		let arena = null;
		let resize = null;
		let frame = 0;
		let last = 0;
		let accumulator = 0;
		let publishAt = 0;
		let finished = false;
		const abort = new AbortController();
		const manual = new URLSearchParams(location.search).get("test") === "1";
		const instrument = manual || new URLSearchParams(location.search).get("profile") === "1";
		const samples = [];
		let entityPeak = 0;
		const focusLost = () => {
			const sim = simRef.current;
			if (sim?.status === "playing") {
				sim.pause();
				inputRef.current?.setActive(false);
				audio.ambience(false, false);
				audio.play("game_pause");
				setSnapshot(sim.snapshot());
			}
			accumulator = 0;
			last = 0;
		};
		const visibility = () => {
			if (document.hidden) focusLost();
		};
		const orientation = () => {
			if (matchMedia("(orientation: portrait)").matches) focusLost();
		};
		function destroy() {
			cancelAnimationFrame(frame);
			resize?.disconnect();
			resize = null;
			inputRef.current?.destroy();
			inputRef.current = null;
			simRef.current = null;
			audio.stop();
			delete window.pirateTest;
			window.removeEventListener("blur", focusLost);
			document.removeEventListener("visibilitychange", visibility);
			window.removeEventListener("resize", orientation);
			arena?.destroy();
			arena = null;
			mapView?.destroy();
			mapView = null;
			if (app) {
				if (app.renderer) app.destroy({ removeView: false }, { children: true });
				else app.stage.destroy({ children: true });
				app = null;
			}
		}
		async function initialize() {
			if (disposed) return;
			setStatus("loading");
			setProgress(0);
			setSnapshot(null);
			const application = new Application();
			app = application;
			try {
				await application.init({
					canvas,
					width: Math.max(1, host.clientWidth),
					height: Math.max(1, host.clientHeight),
					resolution: Math.min(devicePixelRatio, 2),
					autoDensity: true,
					preference: "webgl",
					background: "#123744",
					autoStart: false,
					sharedTicker: false
				});
				initialized = true;
				if (disposed) {
					destroy();
					return;
				}
				const map = await loadTiledMap(abort.signal, (p) => {
					if (!disposed) setProgress(Math.round(p * .6));
				});
				const textures = await loadGameTextures((p) => {
					if (!disposed) setProgress(60 + Math.round(p * 40));
				});
				if (disposed) {
					destroy();
					return;
				}
				const simulation = new Simulation(config, map);
				simRef.current = simulation;
				mapView = new MapRenderer(map);
				application.stage.addChild(mapView.world);
				arena = new ArenaRenderer(mapView.world, simulation, textures);
				const resizeCanvas = () => {
					if (disposed) return;
					application.renderer.resize(Math.max(1, host.clientWidth), Math.max(1, host.clientHeight));
					mapView?.resize(application.screen.width, application.screen.height);
					application.render();
				};
				resize = new ResizeObserver(resizeCanvas);
				resize.observe(host);
				resizeCanvas();
				const requestPause = () => focusLost();
				inputRef.current = new InputController(root, requestPause);
				window.addEventListener("blur", focusLost);
				document.addEventListener("visibilitychange", visibility);
				window.addEventListener("resize", orientation);
				const update = (seconds) => {
					if (simulation.status !== "playing") {
						accumulator = 0;
						return;
					}
					accumulator += seconds;
					while (accumulator + 1e-9 >= config.fixedStep && simulation.status === "playing") {
						simulation.step(config.fixedStep, inputRef.current.read());
						accumulator -= config.fixedStep;
					}
					audio.events(simulation.drainEvents());
					if (simulation.snapshot().status === "ended" && !finished) {
						finished = true;
						inputRef.current?.setActive(false);
						audio.stop();
						audio.play(simulation.reason === "time" ? "game_complete" : "game_over");
						callbacks.current.onComplete(simulation.snapshot());
					}
				};
				if (instrument) window.pirateTest = {
					observe: () => structuredClone({
						snapshot: simulation.snapshot(),
						player: simulation.player,
						enemies: simulation.enemies,
						projectiles: simulation.projectiles,
						effects: simulation.effects.length,
						config,
						colliders: map.colliders,
						frames: samples,
						entityPeak
					}),
					...manual ? { advance: (seconds) => {
						if (!Number.isFinite(seconds) || seconds < 0 || seconds > 180) throw new Error("Invalid test clock advance.");
						update(seconds);
						arena?.draw();
						application.render();
						setSnapshot(simulation.snapshot());
					} } : {}
				};
				function tick(now) {
					if (disposed) return;
					const delta = last ? (now - last) / 1e3 : 0;
					last = now;
					if (simulation.status === "playing") {
						if (!manual) update(Math.min(delta, .25));
						if (instrument && delta > 0 && simulation.elapsed > 5) {
							samples.push(delta * 1e3);
							if (samples.length > 2e4) samples.shift();
						}
						entityPeak = Math.max(entityPeak, simulation.enemies.length + simulation.projectiles.length + simulation.effects.length + 1);
					} else accumulator = 0;
					audio.ambience(simulation.status === "playing", inputRef.current?.read().has("forward") ?? false);
					arena?.draw();
					application.render();
					if (now >= publishAt) {
						setSnapshot(simulation.snapshot());
						publishAt = now + 250;
					}
					frame = requestAnimationFrame(tick);
				}
				setStatus("ready");
				setSnapshot(simulation.snapshot());
				root.focus();
				audio.play("game_start");
				if (document.hidden || matchMedia("(orientation: portrait)").matches) focusLost();
				frame = requestAnimationFrame(tick);
			} catch (cause) {
				destroy();
				if (!disposed) {
					setError(cause instanceof Error ? cause.message : "Unknown asset loading error.");
					setStatus("error");
				}
			}
		}
		queue.current = queue.current.then(initialize);
		return () => {
			disposed = true;
			abort.abort();
			if (initialized) destroy();
		};
	}, [attempt, config]);
	const paused = snapshot?.status === "paused";
	return /* @__PURE__ */ _jsxDEV("section", {
		ref: rootRef,
		className: "game",
		tabIndex: 0,
		"aria-label": "Gameplay controls",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "hud",
				"aria-label": "Match status",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_heart"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Health ", /* @__PURE__ */ _jsxDEV("strong", { children: snapshot?.health ?? config.player.health }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 92
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 79
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_score"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Score ", /* @__PURE__ */ _jsxDEV("strong", { children: snapshot?.score ?? 0 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 91
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 79
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "counter",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: uiAsset("hud/icon_time"),
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 32
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: ["Time ", /* @__PURE__ */ _jsxDEV("strong", { children: [Math.ceil(snapshot?.remaining ?? config.sessionSeconds), "s"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 89
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 78
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "round-button",
						"aria-label": "Pause game",
						disabled: status !== "ready" || paused,
						onClick: pause,
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: uiAsset("controls/icon_pause"),
							alt: ""
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 120
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: viewportRef,
				className: "arena",
				"aria-busy": status === "loading",
				children: [
					/* @__PURE__ */ _jsxDEV("canvas", {
						ref: canvasRef,
						"aria-label": "Naval battle arena"
					}, attempt, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 7
					}, this),
					status === "loading" && /* @__PURE__ */ _jsxDEV("div", {
						className: "arena-message",
						role: "status",
						children: [
							"Loading arena… ",
							progress,
							"%"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 32
					}, this),
					status === "error" && /* @__PURE__ */ _jsxDEV("div", {
						className: "arena-message",
						role: "alert",
						children: [
							/* @__PURE__ */ _jsxDEV("p", { children: "Unable to load the arena." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 74
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 106
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => setAttempt((v) => v + 1),
								children: "Try again"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: onAbandon,
								children: "Main Menu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 76
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 30
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "combat-footer",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "touch-controls",
					children: commands.map(({ action, label, icon }) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: `round-button command command-${action}`,
						"aria-label": label,
						disabled: status !== "ready" || paused,
						onPointerDown: (e) => {
							e.preventDefault();
							e.currentTarget.setPointerCapture(e.pointerId);
							rootRef.current?.focus();
							inputRef.current?.press(`touch-${e.pointerId}`, action);
							e.currentTarget.dataset.held = "true";
						},
						onPointerUp: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onPointerCancel: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onLostPointerCapture: (e) => {
							inputRef.current?.release(`touch-${e.pointerId}`);
							delete e.currentTarget.dataset.held;
						},
						onKeyDown: (e) => {
							if (e.code === "Space" || e.code === "Enter") {
								e.preventDefault();
								inputRef.current?.press(`button-${action}`, action);
							}
						},
						onKeyUp: () => inputRef.current?.release(`button-${action}`),
						onBlur: () => inputRef.current?.release(`button-${action}`),
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: uiAsset(`controls/icon_${icon}`),
							alt: ""
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 9
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 62
						}, this)]
					}, action, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 82
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV(ControlsHelp, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "sr-only",
				role: "status",
				children: status === "loading" ? "Loading arena" : paused ? "Game paused" : "Game active"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 5
			}, this),
			paused && /* @__PURE__ */ _jsxDEV(Dialog, {
				title: abandon ? "Leave this battle?" : "Battle paused",
				onClose: () => {
					if (abandon) setAbandon(false);
					else resume();
				},
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: abandon ? "This unfinished battle will not be saved." : "Time, movement and weapons are suspended. Resume when you are ready." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "portrait-hint",
						children: "Rotate your device to landscape before resuming."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 7
					}, this),
					abandon ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setAbandon(false),
						children: "Stay here"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 20
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: onAbandon,
						children: "Leave battle"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 80
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 18
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
						onClick: resume,
						children: "Resume"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setAbandon(true),
						children: "Main Menu"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 53
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 16
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 119,
		columnNumber: 10
	}, this);
}
_s(GameCanvas, "d/tNm/6pP1UQuIo+6lDqU6Cfgpk=");
_c = GameCanvas;
var _c;
$RefreshReg$(_c, "GameCanvas");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/GameCanvas.tsx?t=1791841466585";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/_Projects/Project_JungleGaming/PirateBattle/game-developer-challenge/src/ui/GameCanvas.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBRTVDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsYUFBYTtBQUN0QixTQUFTLFFBQVEsY0FBYyxRQUFRLGVBQWU7QUFDdEQsT0FBTzs7OztBQUtQLE1BQU0sV0FBOEQ7Q0FDbEU7RUFBRSxRQUFRO0VBQVEsT0FBTztFQUFhLE1BQU07Q0FBWTtDQUFHO0VBQUUsUUFBUTtFQUFXLE9BQU87RUFBVyxNQUFNO0NBQVU7Q0FDbEg7RUFBRSxRQUFRO0VBQVMsT0FBTztFQUFjLE1BQU07Q0FBYTtDQUFHO0VBQUUsUUFBUTtFQUFRLE9BQU87RUFBa0IsTUFBTTtDQUFZO0NBQzNIO0VBQUUsUUFBUTtFQUFTLE9BQU87RUFBZ0IsTUFBTTtDQUFhO0NBQUc7RUFBRSxRQUFRO0VBQWEsT0FBTztFQUFtQixNQUFNO0NBQWE7QUFDdEk7QUFDQSxPQUFPLFNBQVMsV0FBVyxFQUFFLFFBQVEsWUFBWSxhQUU5Qzs7Q0FDRCxNQUFNLFVBQVUsT0FBb0IsSUFBSTtDQUFHLE1BQU0sY0FBYyxPQUF1QixJQUFJO0NBQzFGLE1BQU0sWUFBWSxPQUEwQixJQUFJO0NBQUcsTUFBTSxRQUFRLE9BQXNCLFFBQVEsUUFBUSxDQUFDO0NBQ3hHLE1BQU0sU0FBUyxPQUEwQixJQUFJO0NBQUcsTUFBTSxXQUFXLE9BQStCLElBQUk7Q0FDcEcsTUFBTSxZQUFZLE9BQU87RUFBRTtFQUFZO0NBQVUsQ0FBQztDQUFHLFVBQVUsVUFBVTtFQUFFO0VBQVk7Q0FBVTtDQUNqRyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXdDLFNBQVM7Q0FDN0UsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FBRyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQztDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDO0NBQzdILE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBMEIsSUFBSTtDQUFHLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzdHLFNBQVMsUUFBUTtFQUFFLE1BQU0sTUFBTSxPQUFPO0VBQVMsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLFdBQVc7RUFDbkYsSUFBSSxNQUFNO0VBQUcsU0FBUyxTQUFTLFVBQVUsS0FBSztFQUFHLE1BQU0sU0FBUyxPQUFPLEtBQUs7RUFBRyxNQUFNLEtBQUssWUFBWTtFQUFHLFlBQVksSUFBSSxTQUFTLENBQUM7Q0FBRztDQUN4SSxTQUFTLFNBQVM7RUFBRSxNQUFNLE1BQU0sT0FBTztFQUFTLElBQUksQ0FBQyxPQUFPLElBQUksV0FBVyxZQUFZLFNBQVMsUUFBUTtFQUN0RyxJQUFJLFdBQVcseUJBQXlCLENBQUMsQ0FBQyxTQUFTO0VBQ25ELElBQUksT0FBTztFQUFHLFNBQVMsU0FBUyxVQUFVLElBQUk7RUFBRyxNQUFNLEtBQUssYUFBYTtFQUFHLFlBQVksSUFBSSxTQUFTLENBQUM7RUFDdEcsNEJBQTRCLFFBQVEsU0FBUyxNQUFNLENBQUM7Q0FBRztDQUN6RCxnQkFBZ0I7RUFDZCxNQUFNLE9BQU8sUUFBUTtFQUFTLE1BQU0sU0FBUyxVQUFVO0VBQVMsTUFBTSxPQUFPLFlBQVk7RUFDekYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxNQUFNLElBQUksTUFBTSxzREFBc0Q7RUFDckcsSUFBSSxXQUFXO0VBQU8sSUFBSSxjQUFjO0VBQU8sSUFBSSxNQUEwQjtFQUM3RSxJQUFJLFVBQThCO0VBQU0sSUFBSSxRQUE4QjtFQUMxRSxJQUFJLFNBQWdDO0VBQU0sSUFBSSxRQUFRO0VBQUcsSUFBSSxPQUFPO0VBQUcsSUFBSSxjQUFjO0VBQUcsSUFBSSxZQUFZO0VBQUcsSUFBSSxXQUFXO0VBQzlILE1BQU0sUUFBUSxJQUFJLGdCQUFnQjtFQUFHLE1BQU0sU0FBUyxJQUFJLGdCQUFnQixTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksTUFBTSxNQUFNO0VBQ3pHLE1BQU0sYUFBYSxVQUFVLElBQUksZ0JBQWdCLFNBQVMsTUFBTSxDQUFDLENBQUMsSUFBSSxTQUFTLE1BQU07RUFDckYsTUFBTSxVQUFvQixDQUFDO0VBQUcsSUFBSSxhQUFhO0VBQy9DLE1BQU0sa0JBQWtCO0dBQUUsTUFBTSxNQUFNLE9BQU87R0FBUyxJQUFJLEtBQUssV0FBVyxXQUFXO0lBQ25GLElBQUksTUFBTTtJQUFHLFNBQVMsU0FBUyxVQUFVLEtBQUs7SUFBRyxNQUFNLFNBQVMsT0FBTyxLQUFLO0lBQUcsTUFBTSxLQUFLLFlBQVk7SUFBRyxZQUFZLElBQUksU0FBUyxDQUFDO0dBQUc7R0FDdEksY0FBYztHQUFHLE9BQU87RUFDMUI7RUFDQSxNQUFNLG1CQUFtQjtHQUFFLElBQUksU0FBUyxRQUFRLFVBQVU7RUFBRztFQUM3RCxNQUFNLG9CQUFvQjtHQUFFLElBQUksV0FBVyx5QkFBeUIsQ0FBQyxDQUFDLFNBQVMsVUFBVTtFQUFHO0VBQzVGLFNBQVMsVUFBVTtHQUNqQixxQkFBcUIsS0FBSztHQUFHLFFBQVEsV0FBVztHQUFHLFNBQVM7R0FBTSxTQUFTLFNBQVMsUUFBUTtHQUFHLFNBQVMsVUFBVTtHQUNsSCxPQUFPLFVBQVU7R0FBTSxNQUFNLEtBQUs7R0FBRyxPQUFPLE9BQU87R0FDbkQsT0FBTyxvQkFBb0IsUUFBUSxTQUFTO0dBQUcsU0FBUyxvQkFBb0Isb0JBQW9CLFVBQVU7R0FDMUcsT0FBTyxvQkFBb0IsVUFBVSxXQUFXO0dBQ2hELE9BQU8sUUFBUTtHQUFHLFFBQVE7R0FBTSxTQUFTLFFBQVE7R0FBRyxVQUFVO0dBQzlELElBQUksS0FBSztJQUFFLElBQUksSUFBSSxVQUFVLElBQUksUUFBUSxFQUFFLFlBQVksTUFBTSxHQUFHLEVBQUUsVUFBVSxLQUFLLENBQUM7U0FBUSxJQUFJLE1BQU0sUUFBUSxFQUFFLFVBQVUsS0FBSyxDQUFDO0lBQUcsTUFBTTtHQUFNO0VBQy9JO0VBQ0EsZUFBZSxhQUFhO0dBQzFCLElBQUksVUFBVTtHQUFRLFVBQVUsU0FBUztHQUFHLFlBQVksQ0FBQztHQUFHLFlBQVksSUFBSTtHQUM1RSxNQUFNLGNBQWMsSUFBSSxZQUFZO0dBQUcsTUFBTTtHQUM3QyxJQUFJO0lBQ0YsTUFBTSxZQUFZLEtBQUs7S0FBVTtLQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBTSxXQUFXO0tBQUcsUUFBUSxLQUFLLElBQUksR0FBRyxLQUFNLFlBQVk7S0FDckgsWUFBWSxLQUFLLElBQUksa0JBQWtCLENBQUM7S0FBRyxhQUFhO0tBQU0sWUFBWTtLQUFTLFlBQVk7S0FBVyxXQUFXO0tBQU8sY0FBYztJQUFNLENBQUM7SUFDbkosY0FBYztJQUFNLElBQUksVUFBVTtLQUFFLFFBQVE7S0FBRztJQUFRO0lBQ3ZELE1BQU0sTUFBTSxNQUFNLGFBQWEsTUFBTSxTQUFTLE1BQU07S0FBRSxJQUFJLENBQUMsVUFBVSxZQUFZLEtBQUssTUFBTSxJQUFJLEVBQUcsQ0FBQztJQUFHLENBQUM7SUFDeEcsTUFBTSxXQUFXLE1BQU0sa0JBQWtCLE1BQU07S0FBRSxJQUFJLENBQUMsVUFBVSxZQUFZLEtBQUssS0FBSyxNQUFNLElBQUksRUFBRSxDQUFDO0lBQUcsQ0FBQztJQUN2RyxJQUFJLFVBQVU7S0FBRSxRQUFRO0tBQUc7SUFBUTtJQUNuQyxNQUFNLGFBQWEsSUFBSSxXQUFXLFFBQVEsR0FBRztJQUFHLE9BQU8sVUFBVTtJQUNqRSxVQUFVLElBQUksWUFBWSxHQUFHO0lBQUcsWUFBWSxNQUFNLFNBQVMsUUFBUSxLQUFLO0lBQ3hFLFFBQVEsSUFBSSxjQUFjLFFBQVEsT0FBTyxZQUFZLFFBQVE7SUFDN0QsTUFBTSxxQkFBcUI7S0FBRSxJQUFJLFVBQVU7S0FDekMsWUFBWSxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBTSxZQUFZLENBQUM7S0FDM0YsU0FBUyxPQUFPLFlBQVksT0FBTyxPQUFPLFlBQVksT0FBTyxNQUFNO0tBQUcsWUFBWSxPQUFPO0lBQUc7SUFDOUYsU0FBUyxJQUFJLGVBQWUsWUFBWTtJQUFHLE9BQU8sUUFBUSxJQUFLO0lBQUcsYUFBYTtJQUMvRSxNQUFNLHFCQUFxQixVQUFVO0lBQUcsU0FBUyxVQUFVLElBQUksZ0JBQWdCLE1BQU8sWUFBWTtJQUNsRyxPQUFPLGlCQUFpQixRQUFRLFNBQVM7SUFBRyxTQUFTLGlCQUFpQixvQkFBb0IsVUFBVTtJQUNwRyxPQUFPLGlCQUFpQixVQUFVLFdBQVc7SUFDN0MsTUFBTSxVQUFVLFlBQW9CO0tBQ2xDLElBQUksV0FBVyxXQUFXLFdBQVc7TUFBRSxjQUFjO01BQUc7S0FBUTtLQUNoRSxlQUFlO0tBQ2YsT0FBTyxjQUFjLFFBQVEsT0FBTyxhQUFhLFdBQVcsV0FBVyxXQUFXO01BQ2hGLFdBQVcsS0FBSyxPQUFPLFdBQVcsU0FBUyxRQUFTLEtBQUssQ0FBQztNQUFHLGVBQWUsT0FBTztLQUNyRjtLQUNBLE1BQU0sT0FBTyxXQUFXLFlBQVksQ0FBQztLQUNyQyxJQUFJLFdBQVcsU0FBUyxDQUFDLENBQUMsV0FBVyxXQUFXLENBQUMsVUFBVTtNQUFFLFdBQVc7TUFBTSxTQUFTLFNBQVMsVUFBVSxLQUFLO01BQzdHLE1BQU0sS0FBSztNQUFHLE1BQU0sS0FBSyxXQUFXLFdBQVcsU0FBUyxrQkFBa0IsV0FBVztNQUFHLFVBQVUsUUFBUSxXQUFXLFdBQVcsU0FBUyxDQUFDO0tBQUc7SUFDako7SUFDQSxJQUFJLFlBQVksT0FBTyxhQUFhO0tBQUUsZUFBZSxnQkFBZ0I7TUFBRSxVQUFVLFdBQVcsU0FBUztNQUFHLFFBQVEsV0FBVztNQUN6SCxTQUFTLFdBQVc7TUFBUyxhQUFhLFdBQVc7TUFBYSxTQUFTLFdBQVcsUUFBUTtNQUM5RjtNQUFRLFdBQVcsSUFBSTtNQUFXLFFBQVE7TUFBUztLQUFXLENBQUM7S0FDL0QsR0FBSSxTQUFTLEVBQUUsVUFBVSxZQUFvQjtNQUFFLElBQUksQ0FBQyxPQUFPLFNBQVMsT0FBTyxLQUFLLFVBQVUsS0FBSyxVQUFVLEtBQUssTUFBTSxJQUFJLE1BQU0sNkJBQTZCO01BQ3pKLE9BQU8sT0FBTztNQUFHLE9BQU8sS0FBSztNQUFHLFlBQVksT0FBTztNQUFHLFlBQVksV0FBVyxTQUFTLENBQUM7S0FBRyxFQUFFLElBQUksQ0FBQztJQUFHO0lBQ3hHLFNBQVMsS0FBSyxLQUFhO0tBQ3pCLElBQUksVUFBVTtLQUNkLE1BQU0sUUFBUSxRQUFRLE1BQU0sUUFBUSxNQUFPO0tBQUcsT0FBTztLQUNyRCxJQUFJLFdBQVcsV0FBVyxXQUFXO01BQ25DLElBQUksQ0FBQyxRQUFRLE9BQU8sS0FBSyxJQUFJLE9BQU8sR0FBSSxDQUFDO01BQ3pDLElBQUksY0FBYyxRQUFRLEtBQUssV0FBVyxVQUFVLEdBQUc7T0FBRSxRQUFRLEtBQUssUUFBUSxHQUFJO09BQUcsSUFBSSxRQUFRLFNBQVMsS0FBTyxRQUFRLE1BQU07TUFBRztNQUNsSSxhQUFhLEtBQUssSUFBSSxZQUFZLFdBQVcsUUFBUSxTQUFTLFdBQVcsWUFBWSxTQUFTLFdBQVcsUUFBUSxTQUFTLENBQUM7S0FDN0gsT0FBTyxjQUFjO0tBQ3JCLE1BQU0sU0FBUyxXQUFXLFdBQVcsV0FBVyxTQUFTLFNBQVMsS0FBSyxDQUFDLENBQUMsSUFBSSxTQUFTLEtBQUssS0FBSztLQUNoRyxPQUFPLEtBQUs7S0FBRyxZQUFZLE9BQU87S0FDbEMsSUFBSSxPQUFPLFdBQVc7TUFBRSxZQUFZLFdBQVcsU0FBUyxDQUFDO01BQUcsWUFBWSxNQUFNO0tBQUs7S0FDbkYsUUFBUSxzQkFBc0IsSUFBSTtJQUNwQztJQUNBLFVBQVUsT0FBTztJQUFHLFlBQVksV0FBVyxTQUFTLENBQUM7SUFBRyxLQUFNLE1BQU07SUFBRyxNQUFNLEtBQUssWUFBWTtJQUM5RixJQUFJLFNBQVMsVUFBVSxXQUFXLHlCQUF5QixDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hGLFFBQVEsc0JBQXNCLElBQUk7R0FDcEMsU0FBUyxPQUFPO0lBQUUsUUFBUTtJQUFHLElBQUksQ0FBQyxVQUFVO0tBQUUsU0FBUyxpQkFBaUIsUUFBUSxNQUFNLFVBQVUsOEJBQThCO0tBQUcsVUFBVSxPQUFPO0lBQUc7R0FBRTtFQUN6SjtFQUNBLE1BQU0sVUFBVSxNQUFNLFFBQVEsS0FBSyxVQUFVO0VBQzdDLGFBQWE7R0FBRSxXQUFXO0dBQU0sTUFBTSxNQUFNO0dBQUcsSUFBSSxhQUFhLFFBQVE7RUFBRztDQUM3RSxHQUFHLENBQUMsU0FBUyxNQUFNLENBQUM7Q0FDcEIsTUFBTSxTQUFTLFVBQVUsV0FBVztDQUNwQyxPQUFPLHdCQUFDLFdBQUQ7RUFBUyxLQUFLO0VBQVMsV0FBVTtFQUFPLFVBQVU7RUFBRyxjQUFXO1lBQWhFO0dBQ0wsd0JBQUMsVUFBRDtJQUFRLFdBQVU7SUFBTSxjQUFXO2NBQW5DO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBeUIsd0JBQUMsT0FBRDtRQUFLLEtBQUssUUFBUSxnQkFBZ0I7UUFBRyxLQUFJO09BQUk7Ozs7O09BQUM7T0FBQyx3QkFBQyxRQUFELGFBQU0sV0FBTyx3QkFBQyxVQUFELFlBQVMsVUFBVSxVQUFVLE9BQU8sT0FBTyxPQUFlOzs7O2VBQU87Ozs7O01BQU07Ozs7OztLQUM1Six3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF5Qix3QkFBQyxPQUFEO1FBQUssS0FBSyxRQUFRLGdCQUFnQjtRQUFHLEtBQUk7T0FBSTs7Ozs7T0FBQztPQUFDLHdCQUFDLFFBQUQsYUFBTSxVQUFNLHdCQUFDLFVBQUQsWUFBUyxVQUFVLFNBQVMsRUFBVTs7OztlQUFPOzs7OztNQUFNOzs7Ozs7S0FDdkksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBeUIsd0JBQUMsT0FBRDtRQUFLLEtBQUssUUFBUSxlQUFlO1FBQUcsS0FBSTtPQUFJOzs7OztPQUFDO09BQUMsd0JBQUMsUUFBRCxhQUFNLFNBQUssd0JBQUMsVUFBRCxhQUFTLEtBQUssS0FBSyxVQUFVLGFBQWEsT0FBTyxjQUFjLEdBQUUsR0FBUzs7OztlQUFPOzs7OztNQUFNOzs7Ozs7S0FDekssd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBZSxjQUFXO01BQWEsVUFBVSxXQUFXLFdBQVc7TUFBUSxTQUFTO2dCQUFPLHdCQUFDLE9BQUQ7T0FBSyxLQUFLLFFBQVEscUJBQXFCO09BQUcsS0FBSTtNQUFJOzs7OztLQUFTOzs7OztJQUN0Szs7Ozs7O0dBQ1Isd0JBQUMsT0FBRDtJQUFLLEtBQUs7SUFBYSxXQUFVO0lBQVEsYUFBVyxXQUFXO2NBQS9EO0tBQ0Usd0JBQUMsVUFBRDtNQUFzQixLQUFLO01BQVcsY0FBVztLQUFzQixHQUExRDs7OztZQUEwRDtLQUN0RSxXQUFXLGFBQWEsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBZ0IsTUFBSztnQkFBcEM7T0FBNkM7T0FBZ0I7T0FBUztNQUFNOzs7Ozs7S0FDcEcsV0FBVyxXQUFXLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQWdCLE1BQUs7Z0JBQXBDO09BQTRDLHdCQUFDLEtBQUQsWUFBRyw0QkFBNEI7Ozs7O09BQUMsd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7O09BQzlHLHdCQUFDLFFBQUQ7UUFBUSxlQUFlLFlBQVksTUFBTSxJQUFJLENBQUM7a0JBQUc7T0FBaUI7Ozs7O09BQUMsd0JBQUMsUUFBRDtRQUFRLFNBQVM7a0JBQVc7T0FBaUI7Ozs7O01BQU07Ozs7OztJQUNySDs7Ozs7O0dBQ0wsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFrQixTQUFTLEtBQUssRUFBRSxRQUFRLE9BQU8sV0FBVyx3QkFBQyxVQUFEO01BQXFCLE1BQUs7TUFDbkcsV0FBVyxnQ0FBZ0M7TUFBVSxjQUFZO01BQU8sVUFBVSxXQUFXLFdBQVc7TUFDeEcsZ0JBQWdCLE1BQU07T0FBRSxFQUFFLGVBQWU7T0FBRyxFQUFFLGNBQWMsa0JBQWtCLEVBQUUsU0FBUztPQUFHLFFBQVEsU0FBUyxNQUFNO09BQ2pILFNBQVMsU0FBUyxNQUFNLFNBQVMsRUFBRSxhQUFhLE1BQU07T0FBRyxFQUFFLGNBQWMsUUFBUSxPQUFPO01BQVE7TUFDbEcsY0FBYyxNQUFNO09BQUUsU0FBUyxTQUFTLFFBQVEsU0FBUyxFQUFFLFdBQVc7T0FBRyxPQUFPLEVBQUUsY0FBYyxRQUFRO01BQU07TUFDOUcsa0JBQWtCLE1BQU07T0FBRSxTQUFTLFNBQVMsUUFBUSxTQUFTLEVBQUUsV0FBVztPQUFHLE9BQU8sRUFBRSxjQUFjLFFBQVE7TUFBTTtNQUNsSCx1QkFBdUIsTUFBTTtPQUFFLFNBQVMsU0FBUyxRQUFRLFNBQVMsRUFBRSxXQUFXO09BQUcsT0FBTyxFQUFFLGNBQWMsUUFBUTtNQUFNO01BQ3ZILFlBQVksTUFBTTtPQUFFLElBQUksRUFBRSxTQUFTLFdBQVcsRUFBRSxTQUFTLFNBQVM7UUFBRSxFQUFFLGVBQWU7UUFBRyxTQUFTLFNBQVMsTUFBTSxVQUFVLFVBQVUsTUFBTTtPQUFHO01BQUU7TUFDL0ksZUFBZSxTQUFTLFNBQVMsUUFBUSxVQUFVLFFBQVE7TUFBRyxjQUFjLFNBQVMsU0FBUyxRQUFRLFVBQVUsUUFBUTtnQkFSL0MsQ0FTekUsd0JBQUMsT0FBRDtPQUFLLEtBQUssUUFBUSxpQkFBaUIsTUFBTTtPQUFHLEtBQUk7TUFBSTs7OztnQkFBQyx3QkFBQyxRQUFELFlBQU8sTUFBWTs7OztjQUFTO1FBVEs7Ozs7WUFTTCxDQUFDO0lBQU87Ozs7Y0FDM0Ysd0JBQUMsY0FBRCxDQUFlOzs7O1lBQ1Q7Ozs7OztHQUNSLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQVUsTUFBSztjQUFVLFdBQVcsWUFBWSxrQkFBa0IsU0FBUyxnQkFBZ0I7R0FBaUI7Ozs7O0dBQ3hILFVBQVUsd0JBQUMsUUFBRDtJQUFRLE9BQU8sVUFBVSx1QkFBdUI7SUFBaUIsZUFBZTtLQUFFLElBQUksU0FBUyxXQUFXLEtBQUs7VUFBUSxPQUFPO0lBQUc7Y0FBakk7S0FDVCx3QkFBQyxLQUFELFlBQUksVUFBVSw4Q0FBOEMsdUVBQTBFOzs7OztLQUN0SSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZ0I7S0FBbUQ7Ozs7O0tBQy9FLFVBQVUsZ0RBQUUsd0JBQUMsUUFBRDtNQUFRLGVBQWUsV0FBVyxLQUFLO2dCQUFHO0tBQWlCOzs7O2VBQUMsd0JBQUMsUUFBRDtNQUFRLFNBQVM7Z0JBQVc7S0FBb0I7Ozs7YUFBRzs7OztnQkFDeEgsZ0RBQUUsd0JBQUMsUUFBRDtNQUFRLFNBQVM7Z0JBQVE7S0FBYzs7OztlQUFDLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLFdBQVcsSUFBSTtnQkFBRztLQUFpQjs7OzthQUFHOzs7OztJQUNyRzs7Ozs7O0VBQ0Q7Ozs7OztBQUNYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVDYW52YXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcGxpY2F0aW9uIH0gZnJvbSAncGl4aS5qcyc7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdHlwZSB7IEdhbWVDb25maWcgfSBmcm9tICcuLi9nYW1lL2NvbmZpZyc7XG5pbXBvcnQgeyBsb2FkVGlsZWRNYXAgfSBmcm9tICcuLi9nYW1lL3RpbGVkTWFwJztcbmltcG9ydCB7IE1hcFJlbmRlcmVyIH0gZnJvbSAnLi4vZ2FtZS9tYXBSZW5kZXJlcic7XG5pbXBvcnQgeyBsb2FkR2FtZVRleHR1cmVzIH0gZnJvbSAnLi4vZ2FtZS9hc3NldHMnO1xuaW1wb3J0IHsgQXJlbmFSZW5kZXJlciB9IGZyb20gJy4uL2dhbWUvcmVuZGVyZXInO1xuaW1wb3J0IHsgU2ltdWxhdGlvbiB9IGZyb20gJy4uL2dhbWUvc2ltdWxhdGlvbic7XG5pbXBvcnQgdHlwZSB7IEFjdGlvbiwgU25hcHNob3QgfSBmcm9tICcuLi9nYW1lL3NpbXVsYXRpb24nO1xuaW1wb3J0IHsgSW5wdXRDb250cm9sbGVyIH0gZnJvbSAnLi4vZ2FtZS9pbnB1dCc7XG5pbXBvcnQgeyBhdWRpbyB9IGZyb20gJy4uL2dhbWUvYXVkaW8nO1xuaW1wb3J0IHsgQnV0dG9uLCBDb250cm9sc0hlbHAsIERpYWxvZywgdWlBc3NldCB9IGZyb20gJy4vY29tcG9uZW50cyc7XG5pbXBvcnQgJy4vR2FtZUNhbnZhcy5jc3MnO1xuZXhwb3J0IGludGVyZmFjZSBHYW1lT2JzZXJ2YXRpb24geyBzbmFwc2hvdDogU25hcHNob3Q7IHBsYXllcjogU2ltdWxhdGlvblsncGxheWVyJ107IGVuZW1pZXM6IFNpbXVsYXRpb25bJ2VuZW1pZXMnXTtcbiAgcHJvamVjdGlsZXM6IFNpbXVsYXRpb25bJ3Byb2plY3RpbGVzJ107IGVmZmVjdHM6IG51bWJlcjsgY29uZmlnOiBHYW1lQ29uZmlnO1xuICBjb2xsaWRlcnM6IFNpbXVsYXRpb25bJ21hcCddWydjb2xsaWRlcnMnXTsgZnJhbWVzOiBudW1iZXJbXTsgZW50aXR5UGVhazogbnVtYmVyIH1cbmRlY2xhcmUgZ2xvYmFsIHsgaW50ZXJmYWNlIFdpbmRvdyB7IHBpcmF0ZVRlc3Q/OiB7IG9ic2VydmU6ICgpID0+IEdhbWVPYnNlcnZhdGlvbjsgYWR2YW5jZT86IChzZWNvbmRzOiBudW1iZXIpID0+IHZvaWQgfSB9IH1cbmNvbnN0IGNvbW1hbmRzOiB7IGFjdGlvbjogQWN0aW9uOyBsYWJlbDogc3RyaW5nOyBpY29uOiBzdHJpbmcgfVtdID0gW1xuICB7IGFjdGlvbjogJ2xlZnQnLCBsYWJlbDogJ1R1cm4gbGVmdCcsIGljb246ICd0dXJuX2xlZnQnIH0sIHsgYWN0aW9uOiAnZm9yd2FyZCcsIGxhYmVsOiAnRm9yd2FyZCcsIGljb246ICdmb3J3YXJkJyB9LFxuICB7IGFjdGlvbjogJ3JpZ2h0JywgbGFiZWw6ICdUdXJuIHJpZ2h0JywgaWNvbjogJ3R1cm5fcmlnaHQnIH0sIHsgYWN0aW9uOiAncG9ydCcsIGxhYmVsOiAnTGVmdCBicm9hZHNpZGUnLCBpY29uOiAnZmlyZV9sZWZ0JyB9LFxuICB7IGFjdGlvbjogJ2Zyb250JywgbGFiZWw6ICdGcm9udCBjYW5ub24nLCBpY29uOiAnZmlyZV9mcm9udCcgfSwgeyBhY3Rpb246ICdzdGFyYm9hcmQnLCBsYWJlbDogJ1JpZ2h0IGJyb2Fkc2lkZScsIGljb246ICdmaXJlX3JpZ2h0JyB9LFxuXTtcbmV4cG9ydCBmdW5jdGlvbiBHYW1lQ2FudmFzKHsgY29uZmlnLCBvbkNvbXBsZXRlLCBvbkFiYW5kb24gfToge1xuICBjb25maWc6IEdhbWVDb25maWc7IG9uQ29tcGxldGU6IChzbmFwc2hvdDogU25hcHNob3QpID0+IHZvaWQ7IG9uQWJhbmRvbjogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3Qgcm9vdFJlZiA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7IGNvbnN0IHZpZXdwb3J0UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50PihudWxsKTsgY29uc3QgcXVldWUgPSB1c2VSZWY8UHJvbWlzZTx2b2lkPj4oUHJvbWlzZS5yZXNvbHZlKCkpO1xuICBjb25zdCBzaW1SZWYgPSB1c2VSZWY8U2ltdWxhdGlvbiB8IG51bGw+KG51bGwpOyBjb25zdCBpbnB1dFJlZiA9IHVzZVJlZjxJbnB1dENvbnRyb2xsZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgY2FsbGJhY2tzID0gdXNlUmVmKHsgb25Db21wbGV0ZSwgb25BYmFuZG9uIH0pOyBjYWxsYmFja3MuY3VycmVudCA9IHsgb25Db21wbGV0ZSwgb25BYmFuZG9uIH07XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTwnbG9hZGluZycgfCAncmVhZHknIHwgJ2Vycm9yJz4oJ2xvYWRpbmcnKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7IGNvbnN0IFtwcm9ncmVzcywgc2V0UHJvZ3Jlc3NdID0gdXNlU3RhdGUoMCk7IGNvbnN0IFthdHRlbXB0LCBzZXRBdHRlbXB0XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbc25hcHNob3QsIHNldFNuYXBzaG90XSA9IHVzZVN0YXRlPFNuYXBzaG90IHwgbnVsbD4obnVsbCk7IGNvbnN0IFthYmFuZG9uLCBzZXRBYmFuZG9uXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgZnVuY3Rpb24gcGF1c2UoKSB7IGNvbnN0IHNpbSA9IHNpbVJlZi5jdXJyZW50OyBpZiAoIXNpbSB8fCBzaW0uc3RhdHVzICE9PSAncGxheWluZycpIHJldHVybjtcbiAgICBzaW0ucGF1c2UoKTsgaW5wdXRSZWYuY3VycmVudD8uc2V0QWN0aXZlKGZhbHNlKTsgYXVkaW8uYW1iaWVuY2UoZmFsc2UsIGZhbHNlKTsgYXVkaW8ucGxheSgnZ2FtZV9wYXVzZScpOyBzZXRTbmFwc2hvdChzaW0uc25hcHNob3QoKSk7IH1cbiAgZnVuY3Rpb24gcmVzdW1lKCkgeyBjb25zdCBzaW0gPSBzaW1SZWYuY3VycmVudDsgaWYgKCFzaW0gfHwgc2ltLnN0YXR1cyAhPT0gJ3BhdXNlZCcgfHwgZG9jdW1lbnQuaGlkZGVuKSByZXR1cm47XG4gICAgaWYgKG1hdGNoTWVkaWEoJyhvcmllbnRhdGlvbjogcG9ydHJhaXQpJykubWF0Y2hlcykgcmV0dXJuO1xuICAgIHNpbS5yZXN1bWUoKTsgaW5wdXRSZWYuY3VycmVudD8uc2V0QWN0aXZlKHRydWUpOyBhdWRpby5wbGF5KCdnYW1lX3Jlc3VtZScpOyBzZXRTbmFwc2hvdChzaW0uc25hcHNob3QoKSk7XG4gICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHJvb3RSZWYuY3VycmVudD8uZm9jdXMoKSk7IH1cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCByb290ID0gcm9vdFJlZi5jdXJyZW50OyBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDsgY29uc3QgaG9zdCA9IHZpZXdwb3J0UmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFyb290IHx8ICFjYW52YXMgfHwgIWhvc3QpIHRocm93IG5ldyBFcnJvcignVGhlIGFyZW5hIHJlcXVpcmVzIGl0cyBhdXRob3JlZCB2aWV3cG9ydCBhbmQgY2FudmFzLicpO1xuICAgIGxldCBkaXNwb3NlZCA9IGZhbHNlOyBsZXQgaW5pdGlhbGl6ZWQgPSBmYWxzZTsgbGV0IGFwcDogQXBwbGljYXRpb24gfCBudWxsID0gbnVsbDtcbiAgICBsZXQgbWFwVmlldzogTWFwUmVuZGVyZXIgfCBudWxsID0gbnVsbDsgbGV0IGFyZW5hOiBBcmVuYVJlbmRlcmVyIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IHJlc2l6ZTogUmVzaXplT2JzZXJ2ZXIgfCBudWxsID0gbnVsbDsgbGV0IGZyYW1lID0gMDsgbGV0IGxhc3QgPSAwOyBsZXQgYWNjdW11bGF0b3IgPSAwOyBsZXQgcHVibGlzaEF0ID0gMDsgbGV0IGZpbmlzaGVkID0gZmFsc2U7XG4gICAgY29uc3QgYWJvcnQgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7IGNvbnN0IG1hbnVhbCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKS5nZXQoJ3Rlc3QnKSA9PT0gJzEnO1xuICAgIGNvbnN0IGluc3RydW1lbnQgPSBtYW51YWwgfHwgbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldCgncHJvZmlsZScpID09PSAnMSc7XG4gICAgY29uc3Qgc2FtcGxlczogbnVtYmVyW10gPSBbXTsgbGV0IGVudGl0eVBlYWsgPSAwO1xuICAgIGNvbnN0IGZvY3VzTG9zdCA9ICgpID0+IHsgY29uc3Qgc2ltID0gc2ltUmVmLmN1cnJlbnQ7IGlmIChzaW0/LnN0YXR1cyA9PT0gJ3BsYXlpbmcnKSB7XG4gICAgICBzaW0ucGF1c2UoKTsgaW5wdXRSZWYuY3VycmVudD8uc2V0QWN0aXZlKGZhbHNlKTsgYXVkaW8uYW1iaWVuY2UoZmFsc2UsIGZhbHNlKTsgYXVkaW8ucGxheSgnZ2FtZV9wYXVzZScpOyBzZXRTbmFwc2hvdChzaW0uc25hcHNob3QoKSk7IH1cbiAgICAgIGFjY3VtdWxhdG9yID0gMDsgbGFzdCA9IDA7XG4gICAgfTtcbiAgICBjb25zdCB2aXNpYmlsaXR5ID0gKCkgPT4geyBpZiAoZG9jdW1lbnQuaGlkZGVuKSBmb2N1c0xvc3QoKTsgfTtcbiAgICBjb25zdCBvcmllbnRhdGlvbiA9ICgpID0+IHsgaWYgKG1hdGNoTWVkaWEoJyhvcmllbnRhdGlvbjogcG9ydHJhaXQpJykubWF0Y2hlcykgZm9jdXNMb3N0KCk7IH07XG4gICAgZnVuY3Rpb24gZGVzdHJveSgpIHtcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGZyYW1lKTsgcmVzaXplPy5kaXNjb25uZWN0KCk7IHJlc2l6ZSA9IG51bGw7IGlucHV0UmVmLmN1cnJlbnQ/LmRlc3Ryb3koKTsgaW5wdXRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBzaW1SZWYuY3VycmVudCA9IG51bGw7IGF1ZGlvLnN0b3AoKTsgZGVsZXRlIHdpbmRvdy5waXJhdGVUZXN0O1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2JsdXInLCBmb2N1c0xvc3QpOyBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywgdmlzaWJpbGl0eSk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgb3JpZW50YXRpb24pO1xuICAgICAgYXJlbmE/LmRlc3Ryb3koKTsgYXJlbmEgPSBudWxsOyBtYXBWaWV3Py5kZXN0cm95KCk7IG1hcFZpZXcgPSBudWxsO1xuICAgICAgaWYgKGFwcCkgeyBpZiAoYXBwLnJlbmRlcmVyKSBhcHAuZGVzdHJveSh7IHJlbW92ZVZpZXc6IGZhbHNlIH0sIHsgY2hpbGRyZW46IHRydWUgfSk7IGVsc2UgYXBwLnN0YWdlLmRlc3Ryb3koeyBjaGlsZHJlbjogdHJ1ZSB9KTsgYXBwID0gbnVsbDsgfVxuICAgIH1cbiAgICBhc3luYyBmdW5jdGlvbiBpbml0aWFsaXplKCkge1xuICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47IHNldFN0YXR1cygnbG9hZGluZycpOyBzZXRQcm9ncmVzcygwKTsgc2V0U25hcHNob3QobnVsbCk7XG4gICAgICBjb25zdCBhcHBsaWNhdGlvbiA9IG5ldyBBcHBsaWNhdGlvbigpOyBhcHAgPSBhcHBsaWNhdGlvbjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGFwcGxpY2F0aW9uLmluaXQoeyBjYW52YXM6IGNhbnZhcyEsIHdpZHRoOiBNYXRoLm1heCgxLCBob3N0IS5jbGllbnRXaWR0aCksIGhlaWdodDogTWF0aC5tYXgoMSwgaG9zdCEuY2xpZW50SGVpZ2h0KSxcbiAgICAgICAgICByZXNvbHV0aW9uOiBNYXRoLm1pbihkZXZpY2VQaXhlbFJhdGlvLCAyKSwgYXV0b0RlbnNpdHk6IHRydWUsIHByZWZlcmVuY2U6ICd3ZWJnbCcsIGJhY2tncm91bmQ6ICcjMTIzNzQ0JywgYXV0b1N0YXJ0OiBmYWxzZSwgc2hhcmVkVGlja2VyOiBmYWxzZSB9KTtcbiAgICAgICAgaW5pdGlhbGl6ZWQgPSB0cnVlOyBpZiAoZGlzcG9zZWQpIHsgZGVzdHJveSgpOyByZXR1cm47IH1cbiAgICAgICAgY29uc3QgbWFwID0gYXdhaXQgbG9hZFRpbGVkTWFwKGFib3J0LnNpZ25hbCwgKHApID0+IHsgaWYgKCFkaXNwb3NlZCkgc2V0UHJvZ3Jlc3MoTWF0aC5yb3VuZChwICogMC42KSk7IH0pO1xuICAgICAgICBjb25zdCB0ZXh0dXJlcyA9IGF3YWl0IGxvYWRHYW1lVGV4dHVyZXMoKHApID0+IHsgaWYgKCFkaXNwb3NlZCkgc2V0UHJvZ3Jlc3MoNjAgKyBNYXRoLnJvdW5kKHAgKiA0MCkpOyB9KTtcbiAgICAgICAgaWYgKGRpc3Bvc2VkKSB7IGRlc3Ryb3koKTsgcmV0dXJuOyB9XG4gICAgICAgIGNvbnN0IHNpbXVsYXRpb24gPSBuZXcgU2ltdWxhdGlvbihjb25maWcsIG1hcCk7IHNpbVJlZi5jdXJyZW50ID0gc2ltdWxhdGlvbjtcbiAgICAgICAgbWFwVmlldyA9IG5ldyBNYXBSZW5kZXJlcihtYXApOyBhcHBsaWNhdGlvbi5zdGFnZS5hZGRDaGlsZChtYXBWaWV3LndvcmxkKTtcbiAgICAgICAgYXJlbmEgPSBuZXcgQXJlbmFSZW5kZXJlcihtYXBWaWV3LndvcmxkLCBzaW11bGF0aW9uLCB0ZXh0dXJlcyk7XG4gICAgICAgIGNvbnN0IHJlc2l6ZUNhbnZhcyA9ICgpID0+IHsgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICAgICAgYXBwbGljYXRpb24ucmVuZGVyZXIucmVzaXplKE1hdGgubWF4KDEsIGhvc3QhLmNsaWVudFdpZHRoKSwgTWF0aC5tYXgoMSwgaG9zdCEuY2xpZW50SGVpZ2h0KSk7XG4gICAgICAgICAgbWFwVmlldz8ucmVzaXplKGFwcGxpY2F0aW9uLnNjcmVlbi53aWR0aCwgYXBwbGljYXRpb24uc2NyZWVuLmhlaWdodCk7IGFwcGxpY2F0aW9uLnJlbmRlcigpOyB9O1xuICAgICAgICByZXNpemUgPSBuZXcgUmVzaXplT2JzZXJ2ZXIocmVzaXplQ2FudmFzKTsgcmVzaXplLm9ic2VydmUoaG9zdCEpOyByZXNpemVDYW52YXMoKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdFBhdXNlID0gKCkgPT4gZm9jdXNMb3N0KCk7IGlucHV0UmVmLmN1cnJlbnQgPSBuZXcgSW5wdXRDb250cm9sbGVyKHJvb3QhLCByZXF1ZXN0UGF1c2UpO1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmx1cicsIGZvY3VzTG9zdCk7IGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCB2aXNpYmlsaXR5KTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIG9yaWVudGF0aW9uKTtcbiAgICAgICAgY29uc3QgdXBkYXRlID0gKHNlY29uZHM6IG51bWJlcikgPT4ge1xuICAgICAgICAgIGlmIChzaW11bGF0aW9uLnN0YXR1cyAhPT0gJ3BsYXlpbmcnKSB7IGFjY3VtdWxhdG9yID0gMDsgcmV0dXJuOyB9XG4gICAgICAgICAgYWNjdW11bGF0b3IgKz0gc2Vjb25kcztcbiAgICAgICAgICB3aGlsZSAoYWNjdW11bGF0b3IgKyAxZS05ID49IGNvbmZpZy5maXhlZFN0ZXAgJiYgc2ltdWxhdGlvbi5zdGF0dXMgPT09ICdwbGF5aW5nJykge1xuICAgICAgICAgICAgc2ltdWxhdGlvbi5zdGVwKGNvbmZpZy5maXhlZFN0ZXAsIGlucHV0UmVmLmN1cnJlbnQhLnJlYWQoKSk7IGFjY3VtdWxhdG9yIC09IGNvbmZpZy5maXhlZFN0ZXA7XG4gICAgICAgICAgfVxuICAgICAgICAgIGF1ZGlvLmV2ZW50cyhzaW11bGF0aW9uLmRyYWluRXZlbnRzKCkpO1xuICAgICAgICAgIGlmIChzaW11bGF0aW9uLnNuYXBzaG90KCkuc3RhdHVzID09PSAnZW5kZWQnICYmICFmaW5pc2hlZCkgeyBmaW5pc2hlZCA9IHRydWU7IGlucHV0UmVmLmN1cnJlbnQ/LnNldEFjdGl2ZShmYWxzZSk7XG4gICAgICAgICAgICBhdWRpby5zdG9wKCk7IGF1ZGlvLnBsYXkoc2ltdWxhdGlvbi5yZWFzb24gPT09ICd0aW1lJyA/ICdnYW1lX2NvbXBsZXRlJyA6ICdnYW1lX292ZXInKTsgY2FsbGJhY2tzLmN1cnJlbnQub25Db21wbGV0ZShzaW11bGF0aW9uLnNuYXBzaG90KCkpOyB9XG4gICAgICAgIH07XG4gICAgICAgIGlmIChpbnN0cnVtZW50KSB3aW5kb3cucGlyYXRlVGVzdCA9IHsgb2JzZXJ2ZTogKCkgPT4gc3RydWN0dXJlZENsb25lKHsgc25hcHNob3Q6IHNpbXVsYXRpb24uc25hcHNob3QoKSwgcGxheWVyOiBzaW11bGF0aW9uLnBsYXllcixcbiAgICAgICAgICBlbmVtaWVzOiBzaW11bGF0aW9uLmVuZW1pZXMsIHByb2plY3RpbGVzOiBzaW11bGF0aW9uLnByb2plY3RpbGVzLCBlZmZlY3RzOiBzaW11bGF0aW9uLmVmZmVjdHMubGVuZ3RoLFxuICAgICAgICAgIGNvbmZpZywgY29sbGlkZXJzOiBtYXAuY29sbGlkZXJzLCBmcmFtZXM6IHNhbXBsZXMsIGVudGl0eVBlYWsgfSksXG4gICAgICAgICAgLi4uKG1hbnVhbCA/IHsgYWR2YW5jZTogKHNlY29uZHM6IG51bWJlcikgPT4geyBpZiAoIU51bWJlci5pc0Zpbml0ZShzZWNvbmRzKSB8fCBzZWNvbmRzIDwgMCB8fCBzZWNvbmRzID4gMTgwKSB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgdGVzdCBjbG9jayBhZHZhbmNlLicpO1xuICAgICAgICAgICAgdXBkYXRlKHNlY29uZHMpOyBhcmVuYT8uZHJhdygpOyBhcHBsaWNhdGlvbi5yZW5kZXIoKTsgc2V0U25hcHNob3Qoc2ltdWxhdGlvbi5zbmFwc2hvdCgpKTsgfSB9IDoge30pIH07XG4gICAgICAgIGZ1bmN0aW9uIHRpY2sobm93OiBudW1iZXIpIHtcbiAgICAgICAgICBpZiAoZGlzcG9zZWQpIHJldHVybjtcbiAgICAgICAgICBjb25zdCBkZWx0YSA9IGxhc3QgPyAobm93IC0gbGFzdCkgLyAxMDAwIDogMDsgbGFzdCA9IG5vdztcbiAgICAgICAgICBpZiAoc2ltdWxhdGlvbi5zdGF0dXMgPT09ICdwbGF5aW5nJykge1xuICAgICAgICAgICAgaWYgKCFtYW51YWwpIHVwZGF0ZShNYXRoLm1pbihkZWx0YSwgMC4yNSkpO1xuICAgICAgICAgICAgaWYgKGluc3RydW1lbnQgJiYgZGVsdGEgPiAwICYmIHNpbXVsYXRpb24uZWxhcHNlZCA+IDUpIHsgc2FtcGxlcy5wdXNoKGRlbHRhICogMTAwMCk7IGlmIChzYW1wbGVzLmxlbmd0aCA+IDIwMDAwKSBzYW1wbGVzLnNoaWZ0KCk7IH1cbiAgICAgICAgICAgIGVudGl0eVBlYWsgPSBNYXRoLm1heChlbnRpdHlQZWFrLCBzaW11bGF0aW9uLmVuZW1pZXMubGVuZ3RoICsgc2ltdWxhdGlvbi5wcm9qZWN0aWxlcy5sZW5ndGggKyBzaW11bGF0aW9uLmVmZmVjdHMubGVuZ3RoICsgMSk7XG4gICAgICAgICAgfSBlbHNlIGFjY3VtdWxhdG9yID0gMDtcbiAgICAgICAgICBhdWRpby5hbWJpZW5jZShzaW11bGF0aW9uLnN0YXR1cyA9PT0gJ3BsYXlpbmcnLCBpbnB1dFJlZi5jdXJyZW50Py5yZWFkKCkuaGFzKCdmb3J3YXJkJykgPz8gZmFsc2UpO1xuICAgICAgICAgIGFyZW5hPy5kcmF3KCk7IGFwcGxpY2F0aW9uLnJlbmRlcigpO1xuICAgICAgICAgIGlmIChub3cgPj0gcHVibGlzaEF0KSB7IHNldFNuYXBzaG90KHNpbXVsYXRpb24uc25hcHNob3QoKSk7IHB1Ymxpc2hBdCA9IG5vdyArIDI1MDsgfVxuICAgICAgICAgIGZyYW1lID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spO1xuICAgICAgICB9XG4gICAgICAgIHNldFN0YXR1cygncmVhZHknKTsgc2V0U25hcHNob3Qoc2ltdWxhdGlvbi5zbmFwc2hvdCgpKTsgcm9vdCEuZm9jdXMoKTsgYXVkaW8ucGxheSgnZ2FtZV9zdGFydCcpO1xuICAgICAgICBpZiAoZG9jdW1lbnQuaGlkZGVuIHx8IG1hdGNoTWVkaWEoJyhvcmllbnRhdGlvbjogcG9ydHJhaXQpJykubWF0Y2hlcykgZm9jdXNMb3N0KCk7XG4gICAgICAgIGZyYW1lID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spO1xuICAgICAgfSBjYXRjaCAoY2F1c2UpIHsgZGVzdHJveSgpOyBpZiAoIWRpc3Bvc2VkKSB7IHNldEVycm9yKGNhdXNlIGluc3RhbmNlb2YgRXJyb3IgPyBjYXVzZS5tZXNzYWdlIDogJ1Vua25vd24gYXNzZXQgbG9hZGluZyBlcnJvci4nKTsgc2V0U3RhdHVzKCdlcnJvcicpOyB9IH1cbiAgICB9XG4gICAgcXVldWUuY3VycmVudCA9IHF1ZXVlLmN1cnJlbnQudGhlbihpbml0aWFsaXplKTtcbiAgICByZXR1cm4gKCkgPT4geyBkaXNwb3NlZCA9IHRydWU7IGFib3J0LmFib3J0KCk7IGlmIChpbml0aWFsaXplZCkgZGVzdHJveSgpOyB9O1xuICB9LCBbYXR0ZW1wdCwgY29uZmlnXSk7XG4gIGNvbnN0IHBhdXNlZCA9IHNuYXBzaG90Py5zdGF0dXMgPT09ICdwYXVzZWQnO1xuICByZXR1cm4gPHNlY3Rpb24gcmVmPXtyb290UmVmfSBjbGFzc05hbWU9XCJnYW1lXCIgdGFiSW5kZXg9ezB9IGFyaWEtbGFiZWw9XCJHYW1lcGxheSBjb250cm9sc1wiPlxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaHVkXCIgYXJpYS1sYWJlbD1cIk1hdGNoIHN0YXR1c1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3VudGVyXCI+PGltZyBzcmM9e3VpQXNzZXQoJ2h1ZC9pY29uX2hlYXJ0Jyl9IGFsdD1cIlwiIC8+IDxzcGFuPkhlYWx0aCA8c3Ryb25nPntzbmFwc2hvdD8uaGVhbHRoID8/IGNvbmZpZy5wbGF5ZXIuaGVhbHRofTwvc3Ryb25nPjwvc3Bhbj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291bnRlclwiPjxpbWcgc3JjPXt1aUFzc2V0KCdodWQvaWNvbl9zY29yZScpfSBhbHQ9XCJcIiAvPiA8c3Bhbj5TY29yZSA8c3Ryb25nPntzbmFwc2hvdD8uc2NvcmUgPz8gMH08L3N0cm9uZz48L3NwYW4+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvdW50ZXJcIj48aW1nIHNyYz17dWlBc3NldCgnaHVkL2ljb25fdGltZScpfSBhbHQ9XCJcIiAvPiA8c3Bhbj5UaW1lIDxzdHJvbmc+e01hdGguY2VpbChzbmFwc2hvdD8ucmVtYWluaW5nID8/IGNvbmZpZy5zZXNzaW9uU2Vjb25kcyl9czwvc3Ryb25nPjwvc3Bhbj48L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicm91bmQtYnV0dG9uXCIgYXJpYS1sYWJlbD1cIlBhdXNlIGdhbWVcIiBkaXNhYmxlZD17c3RhdHVzICE9PSAncmVhZHknIHx8IHBhdXNlZH0gb25DbGljaz17cGF1c2V9PjxpbWcgc3JjPXt1aUFzc2V0KCdjb250cm9scy9pY29uX3BhdXNlJyl9IGFsdD1cIlwiIC8+PC9idXR0b24+XG4gICAgPC9oZWFkZXI+XG4gICAgPGRpdiByZWY9e3ZpZXdwb3J0UmVmfSBjbGFzc05hbWU9XCJhcmVuYVwiIGFyaWEtYnVzeT17c3RhdHVzID09PSAnbG9hZGluZyd9PlxuICAgICAgPGNhbnZhcyBrZXk9e2F0dGVtcHR9IHJlZj17Y2FudmFzUmVmfSBhcmlhLWxhYmVsPVwiTmF2YWwgYmF0dGxlIGFyZW5hXCIgLz5cbiAgICAgIHtzdGF0dXMgPT09ICdsb2FkaW5nJyAmJiA8ZGl2IGNsYXNzTmFtZT1cImFyZW5hLW1lc3NhZ2VcIiByb2xlPVwic3RhdHVzXCI+TG9hZGluZyBhcmVuYeKApiB7cHJvZ3Jlc3N9JTwvZGl2Pn1cbiAgICAgIHtzdGF0dXMgPT09ICdlcnJvcicgJiYgPGRpdiBjbGFzc05hbWU9XCJhcmVuYS1tZXNzYWdlXCIgcm9sZT1cImFsZXJ0XCI+PHA+VW5hYmxlIHRvIGxvYWQgdGhlIGFyZW5hLjwvcD48cD57ZXJyb3J9PC9wPlxuICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEF0dGVtcHQoKHYpID0+IHYgKyAxKX0+VHJ5IGFnYWluPC9CdXR0b24+PEJ1dHRvbiBvbkNsaWNrPXtvbkFiYW5kb259Pk1haW4gTWVudTwvQnV0dG9uPjwvZGl2Pn1cbiAgICA8L2Rpdj5cbiAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cImNvbWJhdC1mb290ZXJcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG91Y2gtY29udHJvbHNcIj57Y29tbWFuZHMubWFwKCh7IGFjdGlvbiwgbGFiZWwsIGljb24gfSkgPT4gPGJ1dHRvbiBrZXk9e2FjdGlvbn0gdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT17YHJvdW5kLWJ1dHRvbiBjb21tYW5kIGNvbW1hbmQtJHthY3Rpb259YH0gYXJpYS1sYWJlbD17bGFiZWx9IGRpc2FibGVkPXtzdGF0dXMgIT09ICdyZWFkeScgfHwgcGF1c2VkfVxuICAgICAgICBvblBvaW50ZXJEb3duPXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IGUuY3VycmVudFRhcmdldC5zZXRQb2ludGVyQ2FwdHVyZShlLnBvaW50ZXJJZCk7IHJvb3RSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgICBpbnB1dFJlZi5jdXJyZW50Py5wcmVzcyhgdG91Y2gtJHtlLnBvaW50ZXJJZH1gLCBhY3Rpb24pOyBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5oZWxkID0gJ3RydWUnOyB9fVxuICAgICAgICBvblBvaW50ZXJVcD17KGUpID0+IHsgaW5wdXRSZWYuY3VycmVudD8ucmVsZWFzZShgdG91Y2gtJHtlLnBvaW50ZXJJZH1gKTsgZGVsZXRlIGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmhlbGQ7IH19XG4gICAgICAgIG9uUG9pbnRlckNhbmNlbD17KGUpID0+IHsgaW5wdXRSZWYuY3VycmVudD8ucmVsZWFzZShgdG91Y2gtJHtlLnBvaW50ZXJJZH1gKTsgZGVsZXRlIGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmhlbGQ7IH19XG4gICAgICAgIG9uTG9zdFBvaW50ZXJDYXB0dXJlPXsoZSkgPT4geyBpbnB1dFJlZi5jdXJyZW50Py5yZWxlYXNlKGB0b3VjaC0ke2UucG9pbnRlcklkfWApOyBkZWxldGUgZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaGVsZDsgfX1cbiAgICAgICAgb25LZXlEb3duPXsoZSkgPT4geyBpZiAoZS5jb2RlID09PSAnU3BhY2UnIHx8IGUuY29kZSA9PT0gJ0VudGVyJykgeyBlLnByZXZlbnREZWZhdWx0KCk7IGlucHV0UmVmLmN1cnJlbnQ/LnByZXNzKGBidXR0b24tJHthY3Rpb259YCwgYWN0aW9uKTsgfSB9fVxuICAgICAgICBvbktleVVwPXsoKSA9PiBpbnB1dFJlZi5jdXJyZW50Py5yZWxlYXNlKGBidXR0b24tJHthY3Rpb259YCl9IG9uQmx1cj17KCkgPT4gaW5wdXRSZWYuY3VycmVudD8ucmVsZWFzZShgYnV0dG9uLSR7YWN0aW9ufWApfT5cbiAgICAgICAgPGltZyBzcmM9e3VpQXNzZXQoYGNvbnRyb2xzL2ljb25fJHtpY29ufWApfSBhbHQ9XCJcIiAvPjxzcGFuPntsYWJlbH08L3NwYW4+PC9idXR0b24+KX08L2Rpdj5cbiAgICAgIDxDb250cm9sc0hlbHAgLz5cbiAgICA8L2Zvb3Rlcj5cbiAgICA8cCBjbGFzc05hbWU9XCJzci1vbmx5XCIgcm9sZT1cInN0YXR1c1wiPntzdGF0dXMgPT09ICdsb2FkaW5nJyA/ICdMb2FkaW5nIGFyZW5hJyA6IHBhdXNlZCA/ICdHYW1lIHBhdXNlZCcgOiAnR2FtZSBhY3RpdmUnfTwvcD5cbiAgICB7cGF1c2VkICYmIDxEaWFsb2cgdGl0bGU9e2FiYW5kb24gPyAnTGVhdmUgdGhpcyBiYXR0bGU/JyA6ICdCYXR0bGUgcGF1c2VkJ30gb25DbG9zZT17KCkgPT4geyBpZiAoYWJhbmRvbikgc2V0QWJhbmRvbihmYWxzZSk7IGVsc2UgcmVzdW1lKCk7IH19PlxuICAgICAgPHA+e2FiYW5kb24gPyAnVGhpcyB1bmZpbmlzaGVkIGJhdHRsZSB3aWxsIG5vdCBiZSBzYXZlZC4nIDogJ1RpbWUsIG1vdmVtZW50IGFuZCB3ZWFwb25zIGFyZSBzdXNwZW5kZWQuIFJlc3VtZSB3aGVuIHlvdSBhcmUgcmVhZHkuJ308L3A+XG4gICAgICA8cCBjbGFzc05hbWU9XCJwb3J0cmFpdC1oaW50XCI+Um90YXRlIHlvdXIgZGV2aWNlIHRvIGxhbmRzY2FwZSBiZWZvcmUgcmVzdW1pbmcuPC9wPlxuICAgICAge2FiYW5kb24gPyA8PjxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0QWJhbmRvbihmYWxzZSl9PlN0YXkgaGVyZTwvQnV0dG9uPjxCdXR0b24gb25DbGljaz17b25BYmFuZG9ufT5MZWF2ZSBiYXR0bGU8L0J1dHRvbj48Lz5cbiAgICAgICAgOiA8PjxCdXR0b24gb25DbGljaz17cmVzdW1lfT5SZXN1bWU8L0J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFiYW5kb24odHJ1ZSl9Pk1haW4gTWVudTwvQnV0dG9uPjwvPn1cbiAgICA8L0RpYWxvZz59XG4gIDwvc2VjdGlvbj47XG59XG4iXX0=