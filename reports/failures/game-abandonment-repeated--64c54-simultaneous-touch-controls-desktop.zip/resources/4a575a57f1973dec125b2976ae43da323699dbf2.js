import { angleDifference, angleTo, circleRect, distance, Navigation, segmentCircle, segmentRect } from "/src/game/geometry.ts";
export class Simulation {
	config;
	map;
	player;
	enemies = [];
	projectiles = [];
	effects = [];
	status = "playing";
	elapsed = 0;
	score = 0;
	reason = null;
	nextId = 1;
	randomState;
	spawnAt;
	spawnCount = 0;
	cooldown = {
		front: 0,
		port: 0,
		starboard: 0
	};
	events = [];
	navigation;
	warnedTime = false;
	warnedHealth = false;
	width;
	height;
	constructor(config, map) {
		this.config = config;
		this.map = map;
		this.width = map.width * map.tileWidth;
		this.height = map.height * map.tileHeight;
		this.randomState = config.seed;
		this.spawnAt = config.spawnSeconds;
		this.player = {
			...config.player,
			maxHealth: config.player.health,
			angle: 0,
			id: 0,
			kind: "player",
			alive: true,
			fireAt: 0,
			routeAt: 0,
			route: []
		};
		if (!this.free(this.player, this.player.radius)) throw new Error("Authored player spawn is obstructed.");
		for (const point of config.spawnPoints) if (!this.free(point, config.enemy.radius)) throw new Error("Authored enemy spawn is obstructed.");
		this.navigation = new Navigation(map.width, map.height, map.tileWidth, config.enemy.radius, map.colliders);
	}
	random() {
		this.randomState = 1664525 * this.randomState + 1013904223 >>> 0;
		return this.randomState / 4294967296;
	}
	free(p, r) {
		return p.x >= r && p.y >= r && p.x <= this.width - r && p.y <= this.height - r && !this.map.colliders.some((rect) => circleRect(p, r, rect));
	}
	visible(a, b, padding) {
		return !this.map.colliders.some((r) => segmentRect(a, b, r, padding) !== null);
	}
	move(ship, speed, dt) {
		const dx = Math.sin(ship.angle) * speed * dt;
		const dy = -Math.cos(ship.angle) * speed * dt;
		const next = {
			x: ship.x + dx,
			y: ship.y + dy
		};
		if (this.free(next, ship.radius)) {
			ship.x = next.x;
			ship.y = next.y;
		} else {
			// Axis sliding avoids sticking while preserving circle/rectangle contacts.
			if (this.free({
				x: next.x,
				y: ship.y
			}, ship.radius)) ship.x = next.x;
			if (this.free({
				x: ship.x,
				y: next.y
			}, ship.radius)) ship.y = next.y;
		}
	}
	effect(p, kind, angle = 0) {
		this.effects.push({
			...p,
			id: this.nextId++,
			kind,
			angle,
			age: 0,
			duration: this.config.effects[kind]
		});
	}
	shoot(ship, side) {
		const w = this.config.weapon;
		const angle = ship.angle + side * Math.PI / 2;
		const origin = {
			x: ship.x + Math.sin(angle) * (side ? w.sideOffset : w.frontOffset),
			y: ship.y - Math.cos(angle) * (side ? w.sideOffset : w.frontOffset)
		};
		const enemy = ship.kind !== "player";
		for (const shift of side ? [
			-w.parallelSpacing,
			0,
			w.parallelSpacing
		] : [0]) {
			this.projectiles.push({
				id: this.nextId++,
				x: origin.x + Math.sin(ship.angle) * shift,
				y: origin.y - Math.cos(ship.angle) * shift,
				vx: Math.sin(angle) * (enemy ? w.enemySpeed : w.speed),
				vy: -Math.cos(angle) * (enemy ? w.enemySpeed : w.speed),
				damage: enemy ? w.enemyDamage : side ? w.sideDamage : w.frontDamage,
				owner: enemy ? "enemy" : "player",
				age: 0
			});
		}
		this.effect(origin, "muzzle", angle);
		this.events.push(enemy ? "enemy-shot" : side ? "side-shot" : "front-shot");
	}
	damage(ship, amount, credited) {
		if (!ship.alive) return;
		ship.health = Math.max(0, ship.health - amount);
		this.events.push("impact");
		this.effect(ship, "impact");
		if (!ship.health) {
			ship.alive = false;
			this.effect(ship, "explosion");
			this.events.push("explosion");
			if (ship.kind !== "player" && credited) {
				this.score++;
				this.events.push("score");
			}
		}
		if (ship.kind === "player" && ship.health <= ship.maxHealth * .3 && !this.warnedHealth) {
			this.warnedHealth = true;
			this.events.push("low-health");
		}
	}
	spawn() {
		if (this.enemies.length >= this.config.enemy.maxCount) return;
		const valid = this.config.spawnPoints.filter((p) => distance(p, this.player) >= this.config.enemy.safeSpawnDistance && !this.enemies.some((e) => distance(e, p) < e.radius * 3));
		if (!valid.length) return;
		const point = valid[Math.floor(this.random() * valid.length)];
		const kind = this.spawnCount === 0 ? "chaser" : this.spawnCount === 1 ? "shooter" : this.random() < this.config.enemy.shooterWeight ? "shooter" : "chaser";
		const health = kind === "chaser" ? this.config.enemy.chaserHealth : this.config.enemy.shooterHealth;
		this.enemies.push({
			...point,
			id: this.nextId++,
			kind,
			radius: this.config.enemy.radius,
			health,
			maxHealth: health,
			angle: angleTo(point, this.player),
			alive: true,
			fireAt: 0,
			routeAt: 0,
			route: []
		});
		this.spawnCount++;
	}
	pause() {
		if (this.status === "playing") this.status = "paused";
	}
	resume() {
		if (this.status === "paused") this.status = "playing";
	}
	step(dt, input) {
		if (this.status !== "playing") return;
		dt = Math.min(dt, this.config.sessionSeconds - this.elapsed);
		this.elapsed += dt;
		this.player.angle += ((input.has("right") ? 1 : 0) - (input.has("left") ? 1 : 0)) * this.config.player.turnSpeed * dt;
		if (input.has("forward")) this.move(this.player, this.config.player.speed, dt);
		for (const action of [
			"front",
			"port",
			"starboard"
		]) {
			if (input.has(action) && this.elapsed + 1e-8 >= this.cooldown[action]) {
				this.shoot(this.player, action === "front" ? 0 : action === "port" ? -1 : 1);
				this.cooldown[action] = this.elapsed + (action === "front" ? this.config.weapon.frontCooldown : this.config.weapon.sideCooldown);
			}
		}
		while (this.elapsed + 1e-8 >= this.spawnAt) {
			this.spawn();
			this.spawnAt += this.config.spawnSeconds;
		}
		for (const enemy of this.enemies) {
			if (!enemy.alive || !this.player.alive) continue;
			const sight = this.visible(enemy, this.player, enemy.radius);
			let target = this.player;
			if (!sight) {
				if (this.elapsed >= enemy.routeAt) {
					enemy.route = this.navigation.route(enemy, this.player);
					enemy.routeAt = this.elapsed + this.config.enemy.routeInterval;
				}
				while (enemy.route.length && distance(enemy, enemy.route[0]) < 22) enemy.route.shift();
				target = enemy.route[0] ?? enemy;
			}
			const turn = angleDifference(angleTo(enemy, target), enemy.angle);
			enemy.angle += Math.max(-this.config.enemy.turnSpeed * dt, Math.min(this.config.enemy.turnSpeed * dt, turn));
			const inRange = distance(enemy, this.player) <= this.config.enemy.range && sight;
			if (!(enemy.kind === "shooter" && inRange) && Math.abs(turn) < 1.2) {
				this.move(enemy, enemy.kind === "shooter" ? this.config.enemy.shooterSpeed : this.config.enemy.chaserSpeed, dt);
			}
			if (enemy.kind === "shooter" && inRange && Math.abs(turn) < .18 && this.elapsed >= enemy.fireAt) {
				this.shoot(enemy, 0);
				enemy.fireAt = this.elapsed + this.config.enemy.cooldown;
			}
			if (enemy.kind === "chaser" && distance(enemy, this.player) < enemy.radius + this.player.radius) {
				this.damage(this.player, this.config.enemy.ramDamage, false);
				this.damage(enemy, enemy.health, false);
			}
		}
		if (!this.player.alive) {
			this.reason = "death";
			this.status = "ended";
			return;
		}
		this.projectiles = this.projectiles.filter((p) => {
			if (!this.player.alive) return false;
			const next = {
				x: p.x + p.vx * dt,
				y: p.y + p.vy * dt
			};
			let first = Infinity;
			let victim = null;
			for (const rect of this.map.colliders) {
				const t = segmentRect(p, next, rect, this.config.weapon.radius);
				if (t !== null && t < first) first = t;
			}
			for (const ship of p.owner === "player" ? this.enemies : [this.player]) {
				if (!ship.alive) continue;
				const t = segmentCircle(p, next, ship, ship.radius + this.config.weapon.radius);
				if (t !== null && t < first) {
					first = t;
					victim = ship;
				}
			}
			if (first !== Infinity) {
				if (victim) this.damage(victim, p.damage, p.owner === "player");
				else {
					this.effect({
						x: p.x + (next.x - p.x) * first,
						y: p.y + (next.y - p.y) * first
					}, "impact");
					this.events.push("impact");
				}
				return false;
			}
			p.x = next.x;
			p.y = next.y;
			p.age += dt;
			return p.age < this.config.weapon.lifetime && this.free(p, 0);
		});
		this.enemies = this.enemies.filter((e) => e.alive);
		this.effects = this.effects.filter((e) => {
			e.age += dt;
			return e.age < e.duration;
		});
		if (this.config.sessionSeconds - this.elapsed <= 10 && !this.warnedTime) {
			this.warnedTime = true;
			this.events.push("time-warning");
		}
		if (!this.player.alive || this.elapsed >= this.config.sessionSeconds - 1e-8) {
			this.reason = this.player.alive ? "time" : "death";
			this.status = "ended";
		}
	}
	drainEvents() {
		const events = this.events;
		this.events = [];
		return events;
	}
	snapshot() {
		return {
			status: this.status,
			elapsed: this.elapsed,
			remaining: Math.max(0, this.config.sessionSeconds - this.elapsed),
			score: this.score,
			health: this.player.health,
			maxHealth: this.player.maxHealth,
			enemies: this.enemies.length,
			reason: this.reason
		};
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsU0FBUyxpQkFBaUIsU0FBUyxZQUFZLFVBQVUsWUFBWSxlQUFlLG1CQUFtQjtBQVl2RyxPQUFPLE1BQU0sV0FBVztDQVFEO0NBQTZCO0NBUGxELEFBQVM7Q0FDVCxVQUFrQixDQUFDO0NBQUcsY0FBNEIsQ0FBQztDQUFHLFVBQW9CLENBQUM7Q0FDM0UsU0FBNkI7Q0FBVyxVQUFVO0NBQUcsUUFBUTtDQUFHLFNBQTJCO0NBQzNGLEFBQVEsU0FBUztDQUFHLEFBQVE7Q0FBcUIsQUFBUTtDQUFpQixBQUFRLGFBQWE7Q0FDL0YsQUFBUSxXQUFXO0VBQUUsT0FBTztFQUFHLE1BQU07RUFBRyxXQUFXO0NBQUU7Q0FBRyxBQUFRLFNBQXNCLENBQUM7Q0FDdkYsQUFBUTtDQUF3QixBQUFRLGFBQWE7Q0FBTyxBQUFRLGVBQWU7Q0FDbkYsQUFBUztDQUFlLEFBQVM7Q0FDakMsWUFBWSxBQUFTLFFBQW9CLEFBQVMsS0FBZ0I7RUFBN0M7RUFBNkI7RUFDaEQsS0FBSyxRQUFRLElBQUksUUFBUSxJQUFJO0VBQVcsS0FBSyxTQUFTLElBQUksU0FBUyxJQUFJO0VBQ3ZFLEtBQUssY0FBYyxPQUFPO0VBQU0sS0FBSyxVQUFVLE9BQU87RUFDdEQsS0FBSyxTQUFTO0dBQUUsR0FBRyxPQUFPO0dBQVEsV0FBVyxPQUFPLE9BQU87R0FBUSxPQUFPO0dBQUcsSUFBSTtHQUMvRSxNQUFNO0dBQVUsT0FBTztHQUFNLFFBQVE7R0FBRyxTQUFTO0dBQUcsT0FBTyxDQUFDO0VBQUU7RUFDaEUsSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLFFBQVEsS0FBSyxPQUFPLE1BQU0sR0FBRyxNQUFNLElBQUksTUFBTSxzQ0FBc0M7RUFDdkcsS0FBSyxNQUFNLFNBQVMsT0FBTyxhQUFhLElBQUksQ0FBQyxLQUFLLEtBQUssT0FBTyxPQUFPLE1BQU0sTUFBTSxHQUMvRSxNQUFNLElBQUksTUFBTSxxQ0FBcUM7RUFDdkQsS0FBSyxhQUFhLElBQUksV0FBVyxJQUFJLE9BQU8sSUFBSSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU0sUUFBUSxJQUFJLFNBQVM7Q0FDM0c7Q0FDQSxBQUFRLFNBQVM7RUFBRSxLQUFLLGNBQWUsVUFBVSxLQUFLLGNBQWMsZUFBZ0I7RUFBRyxPQUFPLEtBQUssY0FBYztDQUFZO0NBQzdILEFBQVEsS0FBSyxHQUFVLEdBQVc7RUFBRSxPQUFPLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxLQUFLLFFBQVEsS0FDbEYsRUFBRSxLQUFLLEtBQUssU0FBUyxLQUFLLENBQUMsS0FBSyxJQUFJLFVBQVUsTUFBTSxTQUFTLFdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQztDQUFHO0NBQzNGLEFBQVEsUUFBUSxHQUFVLEdBQVUsU0FBaUI7RUFDbkQsT0FBTyxDQUFDLEtBQUssSUFBSSxVQUFVLE1BQU0sTUFBTSxZQUFZLEdBQUcsR0FBRyxHQUFHLE9BQU8sTUFBTSxJQUFJO0NBQy9FO0NBQ0EsQUFBUSxLQUFLLE1BQVksT0FBZSxJQUFZO0VBQ2xELE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksUUFBUTtFQUFJLE1BQU0sS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxRQUFRO0VBQ3pGLE1BQU0sT0FBTztHQUFFLEdBQUcsS0FBSyxJQUFJO0dBQUksR0FBRyxLQUFLLElBQUk7RUFBRztFQUM5QyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxHQUFHO0dBQUUsS0FBSyxJQUFJLEtBQUs7R0FBRyxLQUFLLElBQUksS0FBSztFQUFHLE9BQ2pFOztHQUVILElBQUksS0FBSyxLQUFLO0lBQUUsR0FBRyxLQUFLO0lBQUcsR0FBRyxLQUFLO0dBQUUsR0FBRyxLQUFLLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSztHQUNwRSxJQUFJLEtBQUssS0FBSztJQUFFLEdBQUcsS0FBSztJQUFHLEdBQUcsS0FBSztHQUFFLEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUs7RUFDdEU7Q0FDRjtDQUNBLEFBQVEsT0FBTyxHQUFVLE1BQXNCLFFBQVEsR0FBRztFQUN4RCxLQUFLLFFBQVEsS0FBSztHQUFFLEdBQUc7R0FBRyxJQUFJLEtBQUs7R0FBVTtHQUFNO0dBQU8sS0FBSztHQUFHLFVBQVUsS0FBSyxPQUFPLFFBQVE7RUFBTSxDQUFDO0NBQ3pHO0NBQ0EsQUFBUSxNQUFNLE1BQVksTUFBa0I7RUFDMUMsTUFBTSxJQUFJLEtBQUssT0FBTztFQUFRLE1BQU0sUUFBUSxLQUFLLFFBQVEsT0FBTyxLQUFLLEtBQUs7RUFDMUUsTUFBTSxTQUFTO0dBQUUsR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUUsYUFBYSxFQUFFO0dBQ3RFLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFLGFBQWEsRUFBRTtFQUFhO0VBQ3RFLE1BQU0sUUFBUSxLQUFLLFNBQVM7RUFDNUIsS0FBSyxNQUFNLFNBQVMsT0FBTztHQUFDLENBQUMsRUFBRTtHQUFpQjtHQUFHLEVBQUU7RUFBZSxJQUFJLENBQUMsQ0FBQyxHQUFHO0dBQzNFLEtBQUssWUFBWSxLQUFLO0lBQUUsSUFBSSxLQUFLO0lBQVUsR0FBRyxPQUFPLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJO0lBQzlFLEdBQUcsT0FBTyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSTtJQUFPLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxRQUFRLEVBQUUsYUFBYSxFQUFFO0lBQzVGLElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxLQUFLLFFBQVEsRUFBRSxhQUFhLEVBQUU7SUFBUSxRQUFRLFFBQVEsRUFBRSxjQUFjLE9BQU8sRUFBRSxhQUFhLEVBQUU7SUFDakgsT0FBTyxRQUFRLFVBQVU7SUFBVSxLQUFLO0dBQUUsQ0FBQztFQUMvQztFQUNBLEtBQUssT0FBTyxRQUFRLFVBQVUsS0FBSztFQUFHLEtBQUssT0FBTyxLQUFLLFFBQVEsZUFBZSxPQUFPLGNBQWMsWUFBWTtDQUNqSDtDQUNBLEFBQVEsT0FBTyxNQUFZLFFBQWdCLFVBQW1CO0VBQzVELElBQUksQ0FBQyxLQUFLLE9BQU87RUFDakIsS0FBSyxTQUFTLEtBQUssSUFBSSxHQUFHLEtBQUssU0FBUyxNQUFNO0VBQUcsS0FBSyxPQUFPLEtBQUssUUFBUTtFQUFHLEtBQUssT0FBTyxNQUFNLFFBQVE7RUFDdkcsSUFBSSxDQUFDLEtBQUssUUFBUTtHQUNoQixLQUFLLFFBQVE7R0FBTyxLQUFLLE9BQU8sTUFBTSxXQUFXO0dBQUcsS0FBSyxPQUFPLEtBQUssV0FBVztHQUNoRixJQUFJLEtBQUssU0FBUyxZQUFZLFVBQVU7SUFBRSxLQUFLO0lBQVMsS0FBSyxPQUFPLEtBQUssT0FBTztHQUFHO0VBQ3JGO0VBQ0EsSUFBSSxLQUFLLFNBQVMsWUFBWSxLQUFLLFVBQVUsS0FBSyxZQUFZLE1BQU8sQ0FBQyxLQUFLLGNBQWM7R0FDdkYsS0FBSyxlQUFlO0dBQU0sS0FBSyxPQUFPLEtBQUssWUFBWTtFQUN6RDtDQUNGO0NBQ0EsQUFBUSxRQUFRO0VBQ2QsSUFBSSxLQUFLLFFBQVEsVUFBVSxLQUFLLE9BQU8sTUFBTSxVQUFVO0VBQ3ZELE1BQU0sUUFBUSxLQUFLLE9BQU8sWUFBWSxRQUFRLE1BQU0sU0FBUyxHQUFHLEtBQUssTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLHFCQUM3RixDQUFDLEtBQUssUUFBUSxNQUFNLE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQzdELElBQUksQ0FBQyxNQUFNLFFBQVE7RUFDbkIsTUFBTSxRQUFRLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU0sTUFBTTtFQUMzRCxNQUFNLE9BQU8sS0FBSyxlQUFlLElBQUksV0FBVyxLQUFLLGVBQWUsSUFBSSxZQUNwRSxLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sTUFBTSxnQkFBZ0IsWUFBWTtFQUNsRSxNQUFNLFNBQVMsU0FBUyxXQUFXLEtBQUssT0FBTyxNQUFNLGVBQWUsS0FBSyxPQUFPLE1BQU07RUFDdEYsS0FBSyxRQUFRLEtBQUs7R0FBRSxHQUFHO0dBQU8sSUFBSSxLQUFLO0dBQVU7R0FBTSxRQUFRLEtBQUssT0FBTyxNQUFNO0dBQy9FO0dBQVEsV0FBVztHQUFRLE9BQU8sUUFBUSxPQUFPLEtBQUssTUFBTTtHQUFHLE9BQU87R0FBTSxRQUFRO0dBQUcsU0FBUztHQUFHLE9BQU8sQ0FBQztFQUFFLENBQUM7RUFDaEgsS0FBSztDQUNQO0NBQ0EsUUFBUTtFQUFFLElBQUksS0FBSyxXQUFXLFdBQVcsS0FBSyxTQUFTO0NBQVU7Q0FDakUsU0FBUztFQUFFLElBQUksS0FBSyxXQUFXLFVBQVUsS0FBSyxTQUFTO0NBQVc7Q0FDbEUsS0FBSyxJQUFZLE9BQTRCO0VBQzNDLElBQUksS0FBSyxXQUFXLFdBQVc7RUFDL0IsS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLE9BQU8saUJBQWlCLEtBQUssT0FBTztFQUMzRCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxPQUFPLFdBQVcsTUFBTSxJQUFJLE9BQU8sSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxPQUFPLE9BQU8sWUFBWTtFQUNuSCxJQUFJLE1BQU0sSUFBSSxTQUFTLEdBQUcsS0FBSyxLQUFLLEtBQUssUUFBUSxLQUFLLE9BQU8sT0FBTyxPQUFPLEVBQUU7RUFDN0UsS0FBSyxNQUFNLFVBQVU7R0FBQztHQUFTO0dBQVE7RUFBVyxHQUFZO0dBQzVELElBQUksTUFBTSxJQUFJLE1BQU0sS0FBSyxLQUFLLFVBQVUsUUFBUSxLQUFLLFNBQVMsU0FBUztJQUNyRSxLQUFLLE1BQU0sS0FBSyxRQUFRLFdBQVcsVUFBVSxJQUFJLFdBQVcsU0FBUyxDQUFDLElBQUksQ0FBQztJQUMzRSxLQUFLLFNBQVMsVUFBVSxLQUFLLFdBQVcsV0FBVyxVQUFVLEtBQUssT0FBTyxPQUFPLGdCQUFnQixLQUFLLE9BQU8sT0FBTztHQUNySDtFQUNGO0VBQ0EsT0FBTyxLQUFLLFVBQVUsUUFBUSxLQUFLLFNBQVM7R0FBRSxLQUFLLE1BQU07R0FBRyxLQUFLLFdBQVcsS0FBSyxPQUFPO0VBQWM7RUFDdEcsS0FBSyxNQUFNLFNBQVMsS0FBSyxTQUFTO0dBQ2hDLElBQUksQ0FBQyxNQUFNLFNBQVMsQ0FBQyxLQUFLLE9BQU8sT0FBTztHQUN4QyxNQUFNLFFBQVEsS0FBSyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU0sTUFBTTtHQUMzRCxJQUFJLFNBQWdCLEtBQUs7R0FDekIsSUFBSSxDQUFDLE9BQU87SUFDVixJQUFJLEtBQUssV0FBVyxNQUFNLFNBQVM7S0FBRSxNQUFNLFFBQVEsS0FBSyxXQUFXLE1BQU0sT0FBTyxLQUFLLE1BQU07S0FDekYsTUFBTSxVQUFVLEtBQUssVUFBVSxLQUFLLE9BQU8sTUFBTTtJQUFlO0lBQ2xFLE9BQU8sTUFBTSxNQUFNLFVBQVUsU0FBUyxPQUFPLE1BQU0sTUFBTSxFQUFHLElBQUksSUFBSSxNQUFNLE1BQU0sTUFBTTtJQUN0RixTQUFTLE1BQU0sTUFBTSxNQUFNO0dBQzdCO0dBQ0EsTUFBTSxPQUFPLGdCQUFnQixRQUFRLE9BQU8sTUFBTSxHQUFHLE1BQU0sS0FBSztHQUNoRSxNQUFNLFNBQVMsS0FBSyxJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sTUFBTSxZQUFZLElBQUksSUFBSSxDQUFDO0dBQzNHLE1BQU0sVUFBVSxTQUFTLE9BQU8sS0FBSyxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sU0FBUztHQUMzRSxJQUFJLEVBQUUsTUFBTSxTQUFTLGFBQWEsWUFBWSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUs7SUFDbEUsS0FBSyxLQUFLLE9BQU8sTUFBTSxTQUFTLFlBQVksS0FBSyxPQUFPLE1BQU0sZUFBZSxLQUFLLE9BQU8sTUFBTSxhQUFhLEVBQUU7R0FDaEg7R0FDQSxJQUFJLE1BQU0sU0FBUyxhQUFhLFdBQVcsS0FBSyxJQUFJLElBQUksSUFBSSxPQUFRLEtBQUssV0FBVyxNQUFNLFFBQVE7SUFDaEcsS0FBSyxNQUFNLE9BQU8sQ0FBQztJQUFHLE1BQU0sU0FBUyxLQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU07R0FDeEU7R0FDQSxJQUFJLE1BQU0sU0FBUyxZQUFZLFNBQVMsT0FBTyxLQUFLLE1BQU0sSUFBSSxNQUFNLFNBQVMsS0FBSyxPQUFPLFFBQVE7SUFDL0YsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLE9BQU8sTUFBTSxXQUFXLEtBQUs7SUFBRyxLQUFLLE9BQU8sT0FBTyxNQUFNLFFBQVEsS0FBSztHQUN0RztFQUNGO0VBQ0EsSUFBSSxDQUFDLEtBQUssT0FBTyxPQUFPO0dBQUUsS0FBSyxTQUFTO0dBQVMsS0FBSyxTQUFTO0dBQVM7RUFBUTtFQUNoRixLQUFLLGNBQWMsS0FBSyxZQUFZLFFBQVEsTUFBTTtHQUNoRCxJQUFJLENBQUMsS0FBSyxPQUFPLE9BQU8sT0FBTztHQUMvQixNQUFNLE9BQU87SUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUs7SUFBSSxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUs7R0FBRztHQUN0RCxJQUFJLFFBQVE7R0FBVSxJQUFJLFNBQXNCO0dBQ2hELEtBQUssTUFBTSxRQUFRLEtBQUssSUFBSSxXQUFXO0lBQ3JDLE1BQU0sSUFBSSxZQUFZLEdBQUcsTUFBTSxNQUFNLEtBQUssT0FBTyxPQUFPLE1BQU07SUFBRyxJQUFJLE1BQU0sUUFBUSxJQUFJLE9BQU8sUUFBUTtHQUN4RztHQUNBLEtBQUssTUFBTSxRQUFRLEVBQUUsVUFBVSxXQUFXLEtBQUssVUFBVSxDQUFDLEtBQUssTUFBTSxHQUFHO0lBQ3RFLElBQUksQ0FBQyxLQUFLLE9BQU87SUFDakIsTUFBTSxJQUFJLGNBQWMsR0FBRyxNQUFNLE1BQU0sS0FBSyxTQUFTLEtBQUssT0FBTyxPQUFPLE1BQU07SUFDOUUsSUFBSSxNQUFNLFFBQVEsSUFBSSxPQUFPO0tBQUUsUUFBUTtLQUFHLFNBQVM7SUFBTTtHQUMzRDtHQUNBLElBQUksVUFBVSxVQUFVO0lBQ3RCLElBQUksUUFBUSxLQUFLLE9BQU8sUUFBUSxFQUFFLFFBQVEsRUFBRSxVQUFVLFFBQVE7U0FDekQ7S0FBRSxLQUFLLE9BQU87TUFBRSxHQUFHLEVBQUUsS0FBSyxLQUFLLElBQUksRUFBRSxLQUFLO01BQU8sR0FBRyxFQUFFLEtBQUssS0FBSyxJQUFJLEVBQUUsS0FBSztLQUFNLEdBQUcsUUFBUTtLQUFHLEtBQUssT0FBTyxLQUFLLFFBQVE7SUFBRztJQUNoSSxPQUFPO0dBQ1Q7R0FDQSxFQUFFLElBQUksS0FBSztHQUFHLEVBQUUsSUFBSSxLQUFLO0dBQUcsRUFBRSxPQUFPO0dBQ3JDLE9BQU8sRUFBRSxNQUFNLEtBQUssT0FBTyxPQUFPLFlBQVksS0FBSyxLQUFLLEdBQUcsQ0FBQztFQUM5RCxDQUFDO0VBQ0QsS0FBSyxVQUFVLEtBQUssUUFBUSxRQUFRLE1BQU0sRUFBRSxLQUFLO0VBQ2pELEtBQUssVUFBVSxLQUFLLFFBQVEsUUFBUSxNQUFNO0dBQUUsRUFBRSxPQUFPO0dBQUksT0FBTyxFQUFFLE1BQU0sRUFBRTtFQUFVLENBQUM7RUFDckYsSUFBSSxLQUFLLE9BQU8saUJBQWlCLEtBQUssV0FBVyxNQUFNLENBQUMsS0FBSyxZQUFZO0dBQUUsS0FBSyxhQUFhO0dBQU0sS0FBSyxPQUFPLEtBQUssY0FBYztFQUFHO0VBQ3JJLElBQUksQ0FBQyxLQUFLLE9BQU8sU0FBUyxLQUFLLFdBQVcsS0FBSyxPQUFPLGlCQUFpQixNQUFNO0dBQzNFLEtBQUssU0FBUyxLQUFLLE9BQU8sUUFBUSxTQUFTO0dBQVMsS0FBSyxTQUFTO0VBQ3BFO0NBQ0Y7Q0FDQSxjQUFjO0VBQUUsTUFBTSxTQUFTLEtBQUs7RUFBUSxLQUFLLFNBQVMsQ0FBQztFQUFHLE9BQU87Q0FBUTtDQUM3RSxXQUFxQjtFQUFFLE9BQU87R0FBRSxRQUFRLEtBQUs7R0FBUSxTQUFTLEtBQUs7R0FDakUsV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8saUJBQWlCLEtBQUssT0FBTztHQUFHLE9BQU8sS0FBSztHQUMvRSxRQUFRLEtBQUssT0FBTztHQUFRLFdBQVcsS0FBSyxPQUFPO0dBQVcsU0FBUyxLQUFLLFFBQVE7R0FBUSxRQUFRLEtBQUs7RUFBTztDQUFHO0FBQ3ZIIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNpbXVsYXRpb24udHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBHYW1lQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xuaW1wb3J0IHR5cGUgeyBMb2FkZWRNYXAgfSBmcm9tICcuL3RpbGVkTWFwJztcbmltcG9ydCB7IGFuZ2xlRGlmZmVyZW5jZSwgYW5nbGVUbywgY2lyY2xlUmVjdCwgZGlzdGFuY2UsIE5hdmlnYXRpb24sIHNlZ21lbnRDaXJjbGUsIHNlZ21lbnRSZWN0IH0gZnJvbSAnLi9nZW9tZXRyeSc7XG5pbXBvcnQgdHlwZSB7IFBvaW50IH0gZnJvbSAnLi9nZW9tZXRyeSc7XG5leHBvcnQgdHlwZSBBY3Rpb24gPSAnZm9yd2FyZCcgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2Zyb250JyB8ICdwb3J0JyB8ICdzdGFyYm9hcmQnO1xuZXhwb3J0IHR5cGUgRW5kUmVhc29uID0gJ3RpbWUnIHwgJ2RlYXRoJztcbmV4cG9ydCB0eXBlIEdhbWVFdmVudCA9ICdmcm9udC1zaG90JyB8ICdzaWRlLXNob3QnIHwgJ2VuZW15LXNob3QnIHwgJ2ltcGFjdCcgfCAnZXhwbG9zaW9uJyB8ICdzY29yZScgfCAnbG93LWhlYWx0aCcgfCAndGltZS13YXJuaW5nJztcbmV4cG9ydCBpbnRlcmZhY2UgU2hpcCBleHRlbmRzIFBvaW50IHsgaWQ6IG51bWJlcjsga2luZDogJ3BsYXllcicgfCAnY2hhc2VyJyB8ICdzaG9vdGVyJzsgYW5nbGU6IG51bWJlcjtcbiAgaGVhbHRoOiBudW1iZXI7IG1heEhlYWx0aDogbnVtYmVyOyByYWRpdXM6IG51bWJlcjsgYWxpdmU6IGJvb2xlYW47IGZpcmVBdDogbnVtYmVyOyByb3V0ZUF0OiBudW1iZXI7IHJvdXRlOiBQb2ludFtdIH1cbmV4cG9ydCBpbnRlcmZhY2UgUHJvamVjdGlsZSBleHRlbmRzIFBvaW50IHsgaWQ6IG51bWJlcjsgdng6IG51bWJlcjsgdnk6IG51bWJlcjsgZGFtYWdlOiBudW1iZXI7XG4gIG93bmVyOiAncGxheWVyJyB8ICdlbmVteSc7IGFnZTogbnVtYmVyIH1cbmV4cG9ydCBpbnRlcmZhY2UgRWZmZWN0IGV4dGVuZHMgUG9pbnQgeyBpZDogbnVtYmVyOyBraW5kOiAnbXV6emxlJyB8ICdpbXBhY3QnIHwgJ2V4cGxvc2lvbic7IGFuZ2xlOiBudW1iZXI7IGFnZTogbnVtYmVyOyBkdXJhdGlvbjogbnVtYmVyIH1cbmV4cG9ydCBpbnRlcmZhY2UgU25hcHNob3QgeyBzdGF0dXM6ICdwbGF5aW5nJyB8ICdwYXVzZWQnIHwgJ2VuZGVkJzsgZWxhcHNlZDogbnVtYmVyOyByZW1haW5pbmc6IG51bWJlcjtcbiAgc2NvcmU6IG51bWJlcjsgaGVhbHRoOiBudW1iZXI7IG1heEhlYWx0aDogbnVtYmVyOyBlbmVtaWVzOiBudW1iZXI7IHJlYXNvbjogRW5kUmVhc29uIHwgbnVsbCB9XG5leHBvcnQgY2xhc3MgU2ltdWxhdGlvbiB7XG4gIHJlYWRvbmx5IHBsYXllcjogU2hpcDtcbiAgZW5lbWllczogU2hpcFtdID0gW107IHByb2plY3RpbGVzOiBQcm9qZWN0aWxlW10gPSBbXTsgZWZmZWN0czogRWZmZWN0W10gPSBbXTtcbiAgc3RhdHVzOiBTbmFwc2hvdFsnc3RhdHVzJ10gPSAncGxheWluZyc7IGVsYXBzZWQgPSAwOyBzY29yZSA9IDA7IHJlYXNvbjogRW5kUmVhc29uIHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgbmV4dElkID0gMTsgcHJpdmF0ZSByYW5kb21TdGF0ZTogbnVtYmVyOyBwcml2YXRlIHNwYXduQXQ6IG51bWJlcjsgcHJpdmF0ZSBzcGF3bkNvdW50ID0gMDtcbiAgcHJpdmF0ZSBjb29sZG93biA9IHsgZnJvbnQ6IDAsIHBvcnQ6IDAsIHN0YXJib2FyZDogMCB9OyBwcml2YXRlIGV2ZW50czogR2FtZUV2ZW50W10gPSBbXTtcbiAgcHJpdmF0ZSBuYXZpZ2F0aW9uOiBOYXZpZ2F0aW9uOyBwcml2YXRlIHdhcm5lZFRpbWUgPSBmYWxzZTsgcHJpdmF0ZSB3YXJuZWRIZWFsdGggPSBmYWxzZTtcbiAgcmVhZG9ubHkgd2lkdGg6IG51bWJlcjsgcmVhZG9ubHkgaGVpZ2h0OiBudW1iZXI7XG4gIGNvbnN0cnVjdG9yKHJlYWRvbmx5IGNvbmZpZzogR2FtZUNvbmZpZywgcmVhZG9ubHkgbWFwOiBMb2FkZWRNYXApIHtcbiAgICB0aGlzLndpZHRoID0gbWFwLndpZHRoICogbWFwLnRpbGVXaWR0aDsgdGhpcy5oZWlnaHQgPSBtYXAuaGVpZ2h0ICogbWFwLnRpbGVIZWlnaHQ7XG4gICAgdGhpcy5yYW5kb21TdGF0ZSA9IGNvbmZpZy5zZWVkOyB0aGlzLnNwYXduQXQgPSBjb25maWcuc3Bhd25TZWNvbmRzO1xuICAgIHRoaXMucGxheWVyID0geyAuLi5jb25maWcucGxheWVyLCBtYXhIZWFsdGg6IGNvbmZpZy5wbGF5ZXIuaGVhbHRoLCBhbmdsZTogMCwgaWQ6IDAsXG4gICAgICBraW5kOiAncGxheWVyJywgYWxpdmU6IHRydWUsIGZpcmVBdDogMCwgcm91dGVBdDogMCwgcm91dGU6IFtdIH07XG4gICAgaWYgKCF0aGlzLmZyZWUodGhpcy5wbGF5ZXIsIHRoaXMucGxheWVyLnJhZGl1cykpIHRocm93IG5ldyBFcnJvcignQXV0aG9yZWQgcGxheWVyIHNwYXduIGlzIG9ic3RydWN0ZWQuJyk7XG4gICAgZm9yIChjb25zdCBwb2ludCBvZiBjb25maWcuc3Bhd25Qb2ludHMpIGlmICghdGhpcy5mcmVlKHBvaW50LCBjb25maWcuZW5lbXkucmFkaXVzKSlcbiAgICAgIHRocm93IG5ldyBFcnJvcignQXV0aG9yZWQgZW5lbXkgc3Bhd24gaXMgb2JzdHJ1Y3RlZC4nKTtcbiAgICB0aGlzLm5hdmlnYXRpb24gPSBuZXcgTmF2aWdhdGlvbihtYXAud2lkdGgsIG1hcC5oZWlnaHQsIG1hcC50aWxlV2lkdGgsIGNvbmZpZy5lbmVteS5yYWRpdXMsIG1hcC5jb2xsaWRlcnMpO1xuICB9XG4gIHByaXZhdGUgcmFuZG9tKCkgeyB0aGlzLnJhbmRvbVN0YXRlID0gKDE2NjQ1MjUgKiB0aGlzLnJhbmRvbVN0YXRlICsgMTAxMzkwNDIyMykgPj4+IDA7IHJldHVybiB0aGlzLnJhbmRvbVN0YXRlIC8gNDI5NDk2NzI5NjsgfVxuICBwcml2YXRlIGZyZWUocDogUG9pbnQsIHI6IG51bWJlcikgeyByZXR1cm4gcC54ID49IHIgJiYgcC55ID49IHIgJiYgcC54IDw9IHRoaXMud2lkdGggLSByXG4gICAgJiYgcC55IDw9IHRoaXMuaGVpZ2h0IC0gciAmJiAhdGhpcy5tYXAuY29sbGlkZXJzLnNvbWUoKHJlY3QpID0+IGNpcmNsZVJlY3QocCwgciwgcmVjdCkpOyB9XG4gIHByaXZhdGUgdmlzaWJsZShhOiBQb2ludCwgYjogUG9pbnQsIHBhZGRpbmc6IG51bWJlcikge1xuICAgIHJldHVybiAhdGhpcy5tYXAuY29sbGlkZXJzLnNvbWUoKHIpID0+IHNlZ21lbnRSZWN0KGEsIGIsIHIsIHBhZGRpbmcpICE9PSBudWxsKTtcbiAgfVxuICBwcml2YXRlIG1vdmUoc2hpcDogU2hpcCwgc3BlZWQ6IG51bWJlciwgZHQ6IG51bWJlcikge1xuICAgIGNvbnN0IGR4ID0gTWF0aC5zaW4oc2hpcC5hbmdsZSkgKiBzcGVlZCAqIGR0OyBjb25zdCBkeSA9IC1NYXRoLmNvcyhzaGlwLmFuZ2xlKSAqIHNwZWVkICogZHQ7XG4gICAgY29uc3QgbmV4dCA9IHsgeDogc2hpcC54ICsgZHgsIHk6IHNoaXAueSArIGR5IH07XG4gICAgaWYgKHRoaXMuZnJlZShuZXh0LCBzaGlwLnJhZGl1cykpIHsgc2hpcC54ID0gbmV4dC54OyBzaGlwLnkgPSBuZXh0Lnk7IH1cbiAgICBlbHNlIHtcbiAgICAgIC8vIEF4aXMgc2xpZGluZyBhdm9pZHMgc3RpY2tpbmcgd2hpbGUgcHJlc2VydmluZyBjaXJjbGUvcmVjdGFuZ2xlIGNvbnRhY3RzLlxuICAgICAgaWYgKHRoaXMuZnJlZSh7IHg6IG5leHQueCwgeTogc2hpcC55IH0sIHNoaXAucmFkaXVzKSkgc2hpcC54ID0gbmV4dC54O1xuICAgICAgaWYgKHRoaXMuZnJlZSh7IHg6IHNoaXAueCwgeTogbmV4dC55IH0sIHNoaXAucmFkaXVzKSkgc2hpcC55ID0gbmV4dC55O1xuICAgIH1cbiAgfVxuICBwcml2YXRlIGVmZmVjdChwOiBQb2ludCwga2luZDogRWZmZWN0WydraW5kJ10sIGFuZ2xlID0gMCkge1xuICAgIHRoaXMuZWZmZWN0cy5wdXNoKHsgLi4ucCwgaWQ6IHRoaXMubmV4dElkKyssIGtpbmQsIGFuZ2xlLCBhZ2U6IDAsIGR1cmF0aW9uOiB0aGlzLmNvbmZpZy5lZmZlY3RzW2tpbmRdIH0pO1xuICB9XG4gIHByaXZhdGUgc2hvb3Qoc2hpcDogU2hpcCwgc2lkZTogLTEgfCAwIHwgMSkge1xuICAgIGNvbnN0IHcgPSB0aGlzLmNvbmZpZy53ZWFwb247IGNvbnN0IGFuZ2xlID0gc2hpcC5hbmdsZSArIHNpZGUgKiBNYXRoLlBJIC8gMjtcbiAgICBjb25zdCBvcmlnaW4gPSB7IHg6IHNoaXAueCArIE1hdGguc2luKGFuZ2xlKSAqIChzaWRlID8gdy5zaWRlT2Zmc2V0IDogdy5mcm9udE9mZnNldCksXG4gICAgICB5OiBzaGlwLnkgLSBNYXRoLmNvcyhhbmdsZSkgKiAoc2lkZSA/IHcuc2lkZU9mZnNldCA6IHcuZnJvbnRPZmZzZXQpIH07XG4gICAgY29uc3QgZW5lbXkgPSBzaGlwLmtpbmQgIT09ICdwbGF5ZXInO1xuICAgIGZvciAoY29uc3Qgc2hpZnQgb2Ygc2lkZSA/IFstdy5wYXJhbGxlbFNwYWNpbmcsIDAsIHcucGFyYWxsZWxTcGFjaW5nXSA6IFswXSkge1xuICAgICAgdGhpcy5wcm9qZWN0aWxlcy5wdXNoKHsgaWQ6IHRoaXMubmV4dElkKyssIHg6IG9yaWdpbi54ICsgTWF0aC5zaW4oc2hpcC5hbmdsZSkgKiBzaGlmdCxcbiAgICAgICAgeTogb3JpZ2luLnkgLSBNYXRoLmNvcyhzaGlwLmFuZ2xlKSAqIHNoaWZ0LCB2eDogTWF0aC5zaW4oYW5nbGUpICogKGVuZW15ID8gdy5lbmVteVNwZWVkIDogdy5zcGVlZCksXG4gICAgICAgIHZ5OiAtTWF0aC5jb3MoYW5nbGUpICogKGVuZW15ID8gdy5lbmVteVNwZWVkIDogdy5zcGVlZCksIGRhbWFnZTogZW5lbXkgPyB3LmVuZW15RGFtYWdlIDogc2lkZSA/IHcuc2lkZURhbWFnZSA6IHcuZnJvbnREYW1hZ2UsXG4gICAgICAgIG93bmVyOiBlbmVteSA/ICdlbmVteScgOiAncGxheWVyJywgYWdlOiAwIH0pO1xuICAgIH1cbiAgICB0aGlzLmVmZmVjdChvcmlnaW4sICdtdXp6bGUnLCBhbmdsZSk7IHRoaXMuZXZlbnRzLnB1c2goZW5lbXkgPyAnZW5lbXktc2hvdCcgOiBzaWRlID8gJ3NpZGUtc2hvdCcgOiAnZnJvbnQtc2hvdCcpO1xuICB9XG4gIHByaXZhdGUgZGFtYWdlKHNoaXA6IFNoaXAsIGFtb3VudDogbnVtYmVyLCBjcmVkaXRlZDogYm9vbGVhbikge1xuICAgIGlmICghc2hpcC5hbGl2ZSkgcmV0dXJuO1xuICAgIHNoaXAuaGVhbHRoID0gTWF0aC5tYXgoMCwgc2hpcC5oZWFsdGggLSBhbW91bnQpOyB0aGlzLmV2ZW50cy5wdXNoKCdpbXBhY3QnKTsgdGhpcy5lZmZlY3Qoc2hpcCwgJ2ltcGFjdCcpO1xuICAgIGlmICghc2hpcC5oZWFsdGgpIHtcbiAgICAgIHNoaXAuYWxpdmUgPSBmYWxzZTsgdGhpcy5lZmZlY3Qoc2hpcCwgJ2V4cGxvc2lvbicpOyB0aGlzLmV2ZW50cy5wdXNoKCdleHBsb3Npb24nKTtcbiAgICAgIGlmIChzaGlwLmtpbmQgIT09ICdwbGF5ZXInICYmIGNyZWRpdGVkKSB7IHRoaXMuc2NvcmUrKzsgdGhpcy5ldmVudHMucHVzaCgnc2NvcmUnKTsgfVxuICAgIH1cbiAgICBpZiAoc2hpcC5raW5kID09PSAncGxheWVyJyAmJiBzaGlwLmhlYWx0aCA8PSBzaGlwLm1heEhlYWx0aCAqIDAuMyAmJiAhdGhpcy53YXJuZWRIZWFsdGgpIHtcbiAgICAgIHRoaXMud2FybmVkSGVhbHRoID0gdHJ1ZTsgdGhpcy5ldmVudHMucHVzaCgnbG93LWhlYWx0aCcpO1xuICAgIH1cbiAgfVxuICBwcml2YXRlIHNwYXduKCkge1xuICAgIGlmICh0aGlzLmVuZW1pZXMubGVuZ3RoID49IHRoaXMuY29uZmlnLmVuZW15Lm1heENvdW50KSByZXR1cm47XG4gICAgY29uc3QgdmFsaWQgPSB0aGlzLmNvbmZpZy5zcGF3blBvaW50cy5maWx0ZXIoKHApID0+IGRpc3RhbmNlKHAsIHRoaXMucGxheWVyKSA+PSB0aGlzLmNvbmZpZy5lbmVteS5zYWZlU3Bhd25EaXN0YW5jZVxuICAgICAgJiYgIXRoaXMuZW5lbWllcy5zb21lKChlKSA9PiBkaXN0YW5jZShlLCBwKSA8IGUucmFkaXVzICogMykpO1xuICAgIGlmICghdmFsaWQubGVuZ3RoKSByZXR1cm47XG4gICAgY29uc3QgcG9pbnQgPSB2YWxpZFtNYXRoLmZsb29yKHRoaXMucmFuZG9tKCkgKiB2YWxpZC5sZW5ndGgpXSE7XG4gICAgY29uc3Qga2luZCA9IHRoaXMuc3Bhd25Db3VudCA9PT0gMCA/ICdjaGFzZXInIDogdGhpcy5zcGF3bkNvdW50ID09PSAxID8gJ3Nob290ZXInXG4gICAgICA6IHRoaXMucmFuZG9tKCkgPCB0aGlzLmNvbmZpZy5lbmVteS5zaG9vdGVyV2VpZ2h0ID8gJ3Nob290ZXInIDogJ2NoYXNlcic7XG4gICAgY29uc3QgaGVhbHRoID0ga2luZCA9PT0gJ2NoYXNlcicgPyB0aGlzLmNvbmZpZy5lbmVteS5jaGFzZXJIZWFsdGggOiB0aGlzLmNvbmZpZy5lbmVteS5zaG9vdGVySGVhbHRoO1xuICAgIHRoaXMuZW5lbWllcy5wdXNoKHsgLi4ucG9pbnQsIGlkOiB0aGlzLm5leHRJZCsrLCBraW5kLCByYWRpdXM6IHRoaXMuY29uZmlnLmVuZW15LnJhZGl1cyxcbiAgICAgIGhlYWx0aCwgbWF4SGVhbHRoOiBoZWFsdGgsIGFuZ2xlOiBhbmdsZVRvKHBvaW50LCB0aGlzLnBsYXllciksIGFsaXZlOiB0cnVlLCBmaXJlQXQ6IDAsIHJvdXRlQXQ6IDAsIHJvdXRlOiBbXSB9KTtcbiAgICB0aGlzLnNwYXduQ291bnQrKztcbiAgfVxuICBwYXVzZSgpIHsgaWYgKHRoaXMuc3RhdHVzID09PSAncGxheWluZycpIHRoaXMuc3RhdHVzID0gJ3BhdXNlZCc7IH1cbiAgcmVzdW1lKCkgeyBpZiAodGhpcy5zdGF0dXMgPT09ICdwYXVzZWQnKSB0aGlzLnN0YXR1cyA9ICdwbGF5aW5nJzsgfVxuICBzdGVwKGR0OiBudW1iZXIsIGlucHV0OiBSZWFkb25seVNldDxBY3Rpb24+KSB7XG4gICAgaWYgKHRoaXMuc3RhdHVzICE9PSAncGxheWluZycpIHJldHVybjtcbiAgICBkdCA9IE1hdGgubWluKGR0LCB0aGlzLmNvbmZpZy5zZXNzaW9uU2Vjb25kcyAtIHRoaXMuZWxhcHNlZCk7XG4gICAgdGhpcy5lbGFwc2VkICs9IGR0O1xuICAgIHRoaXMucGxheWVyLmFuZ2xlICs9ICgoaW5wdXQuaGFzKCdyaWdodCcpID8gMSA6IDApIC0gKGlucHV0LmhhcygnbGVmdCcpID8gMSA6IDApKSAqIHRoaXMuY29uZmlnLnBsYXllci50dXJuU3BlZWQgKiBkdDtcbiAgICBpZiAoaW5wdXQuaGFzKCdmb3J3YXJkJykpIHRoaXMubW92ZSh0aGlzLnBsYXllciwgdGhpcy5jb25maWcucGxheWVyLnNwZWVkLCBkdCk7XG4gICAgZm9yIChjb25zdCBhY3Rpb24gb2YgWydmcm9udCcsICdwb3J0JywgJ3N0YXJib2FyZCddIGFzIGNvbnN0KSB7XG4gICAgICBpZiAoaW5wdXQuaGFzKGFjdGlvbikgJiYgdGhpcy5lbGFwc2VkICsgMWUtOCA+PSB0aGlzLmNvb2xkb3duW2FjdGlvbl0pIHtcbiAgICAgICAgdGhpcy5zaG9vdCh0aGlzLnBsYXllciwgYWN0aW9uID09PSAnZnJvbnQnID8gMCA6IGFjdGlvbiA9PT0gJ3BvcnQnID8gLTEgOiAxKTtcbiAgICAgICAgdGhpcy5jb29sZG93blthY3Rpb25dID0gdGhpcy5lbGFwc2VkICsgKGFjdGlvbiA9PT0gJ2Zyb250JyA/IHRoaXMuY29uZmlnLndlYXBvbi5mcm9udENvb2xkb3duIDogdGhpcy5jb25maWcud2VhcG9uLnNpZGVDb29sZG93bik7XG4gICAgICB9XG4gICAgfVxuICAgIHdoaWxlICh0aGlzLmVsYXBzZWQgKyAxZS04ID49IHRoaXMuc3Bhd25BdCkgeyB0aGlzLnNwYXduKCk7IHRoaXMuc3Bhd25BdCArPSB0aGlzLmNvbmZpZy5zcGF3blNlY29uZHM7IH1cbiAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHRoaXMuZW5lbWllcykge1xuICAgICAgaWYgKCFlbmVteS5hbGl2ZSB8fCAhdGhpcy5wbGF5ZXIuYWxpdmUpIGNvbnRpbnVlO1xuICAgICAgY29uc3Qgc2lnaHQgPSB0aGlzLnZpc2libGUoZW5lbXksIHRoaXMucGxheWVyLCBlbmVteS5yYWRpdXMpO1xuICAgICAgbGV0IHRhcmdldDogUG9pbnQgPSB0aGlzLnBsYXllcjtcbiAgICAgIGlmICghc2lnaHQpIHtcbiAgICAgICAgaWYgKHRoaXMuZWxhcHNlZCA+PSBlbmVteS5yb3V0ZUF0KSB7IGVuZW15LnJvdXRlID0gdGhpcy5uYXZpZ2F0aW9uLnJvdXRlKGVuZW15LCB0aGlzLnBsYXllcik7XG4gICAgICAgICAgZW5lbXkucm91dGVBdCA9IHRoaXMuZWxhcHNlZCArIHRoaXMuY29uZmlnLmVuZW15LnJvdXRlSW50ZXJ2YWw7IH1cbiAgICAgICAgd2hpbGUgKGVuZW15LnJvdXRlLmxlbmd0aCAmJiBkaXN0YW5jZShlbmVteSwgZW5lbXkucm91dGVbMF0hKSA8IDIyKSBlbmVteS5yb3V0ZS5zaGlmdCgpO1xuICAgICAgICB0YXJnZXQgPSBlbmVteS5yb3V0ZVswXSA/PyBlbmVteTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHR1cm4gPSBhbmdsZURpZmZlcmVuY2UoYW5nbGVUbyhlbmVteSwgdGFyZ2V0KSwgZW5lbXkuYW5nbGUpO1xuICAgICAgZW5lbXkuYW5nbGUgKz0gTWF0aC5tYXgoLXRoaXMuY29uZmlnLmVuZW15LnR1cm5TcGVlZCAqIGR0LCBNYXRoLm1pbih0aGlzLmNvbmZpZy5lbmVteS50dXJuU3BlZWQgKiBkdCwgdHVybikpO1xuICAgICAgY29uc3QgaW5SYW5nZSA9IGRpc3RhbmNlKGVuZW15LCB0aGlzLnBsYXllcikgPD0gdGhpcy5jb25maWcuZW5lbXkucmFuZ2UgJiYgc2lnaHQ7XG4gICAgICBpZiAoIShlbmVteS5raW5kID09PSAnc2hvb3RlcicgJiYgaW5SYW5nZSkgJiYgTWF0aC5hYnModHVybikgPCAxLjIpIHtcbiAgICAgICAgdGhpcy5tb3ZlKGVuZW15LCBlbmVteS5raW5kID09PSAnc2hvb3RlcicgPyB0aGlzLmNvbmZpZy5lbmVteS5zaG9vdGVyU3BlZWQgOiB0aGlzLmNvbmZpZy5lbmVteS5jaGFzZXJTcGVlZCwgZHQpO1xuICAgICAgfVxuICAgICAgaWYgKGVuZW15LmtpbmQgPT09ICdzaG9vdGVyJyAmJiBpblJhbmdlICYmIE1hdGguYWJzKHR1cm4pIDwgMC4xOCAmJiB0aGlzLmVsYXBzZWQgPj0gZW5lbXkuZmlyZUF0KSB7XG4gICAgICAgIHRoaXMuc2hvb3QoZW5lbXksIDApOyBlbmVteS5maXJlQXQgPSB0aGlzLmVsYXBzZWQgKyB0aGlzLmNvbmZpZy5lbmVteS5jb29sZG93bjtcbiAgICAgIH1cbiAgICAgIGlmIChlbmVteS5raW5kID09PSAnY2hhc2VyJyAmJiBkaXN0YW5jZShlbmVteSwgdGhpcy5wbGF5ZXIpIDwgZW5lbXkucmFkaXVzICsgdGhpcy5wbGF5ZXIucmFkaXVzKSB7XG4gICAgICAgIHRoaXMuZGFtYWdlKHRoaXMucGxheWVyLCB0aGlzLmNvbmZpZy5lbmVteS5yYW1EYW1hZ2UsIGZhbHNlKTsgdGhpcy5kYW1hZ2UoZW5lbXksIGVuZW15LmhlYWx0aCwgZmFsc2UpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXRoaXMucGxheWVyLmFsaXZlKSB7IHRoaXMucmVhc29uID0gJ2RlYXRoJzsgdGhpcy5zdGF0dXMgPSAnZW5kZWQnOyByZXR1cm47IH1cbiAgICB0aGlzLnByb2plY3RpbGVzID0gdGhpcy5wcm9qZWN0aWxlcy5maWx0ZXIoKHApID0+IHtcbiAgICAgIGlmICghdGhpcy5wbGF5ZXIuYWxpdmUpIHJldHVybiBmYWxzZTtcbiAgICAgIGNvbnN0IG5leHQgPSB7IHg6IHAueCArIHAudnggKiBkdCwgeTogcC55ICsgcC52eSAqIGR0IH07XG4gICAgICBsZXQgZmlyc3QgPSBJbmZpbml0eTsgbGV0IHZpY3RpbTogU2hpcCB8IG51bGwgPSBudWxsO1xuICAgICAgZm9yIChjb25zdCByZWN0IG9mIHRoaXMubWFwLmNvbGxpZGVycykge1xuICAgICAgICBjb25zdCB0ID0gc2VnbWVudFJlY3QocCwgbmV4dCwgcmVjdCwgdGhpcy5jb25maWcud2VhcG9uLnJhZGl1cyk7IGlmICh0ICE9PSBudWxsICYmIHQgPCBmaXJzdCkgZmlyc3QgPSB0O1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBzaGlwIG9mIHAub3duZXIgPT09ICdwbGF5ZXInID8gdGhpcy5lbmVtaWVzIDogW3RoaXMucGxheWVyXSkge1xuICAgICAgICBpZiAoIXNoaXAuYWxpdmUpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCB0ID0gc2VnbWVudENpcmNsZShwLCBuZXh0LCBzaGlwLCBzaGlwLnJhZGl1cyArIHRoaXMuY29uZmlnLndlYXBvbi5yYWRpdXMpO1xuICAgICAgICBpZiAodCAhPT0gbnVsbCAmJiB0IDwgZmlyc3QpIHsgZmlyc3QgPSB0OyB2aWN0aW0gPSBzaGlwOyB9XG4gICAgICB9XG4gICAgICBpZiAoZmlyc3QgIT09IEluZmluaXR5KSB7XG4gICAgICAgIGlmICh2aWN0aW0pIHRoaXMuZGFtYWdlKHZpY3RpbSwgcC5kYW1hZ2UsIHAub3duZXIgPT09ICdwbGF5ZXInKTtcbiAgICAgICAgZWxzZSB7IHRoaXMuZWZmZWN0KHsgeDogcC54ICsgKG5leHQueCAtIHAueCkgKiBmaXJzdCwgeTogcC55ICsgKG5leHQueSAtIHAueSkgKiBmaXJzdCB9LCAnaW1wYWN0Jyk7IHRoaXMuZXZlbnRzLnB1c2goJ2ltcGFjdCcpOyB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHAueCA9IG5leHQueDsgcC55ID0gbmV4dC55OyBwLmFnZSArPSBkdDtcbiAgICAgIHJldHVybiBwLmFnZSA8IHRoaXMuY29uZmlnLndlYXBvbi5saWZldGltZSAmJiB0aGlzLmZyZWUocCwgMCk7XG4gICAgfSk7XG4gICAgdGhpcy5lbmVtaWVzID0gdGhpcy5lbmVtaWVzLmZpbHRlcigoZSkgPT4gZS5hbGl2ZSk7XG4gICAgdGhpcy5lZmZlY3RzID0gdGhpcy5lZmZlY3RzLmZpbHRlcigoZSkgPT4geyBlLmFnZSArPSBkdDsgcmV0dXJuIGUuYWdlIDwgZS5kdXJhdGlvbjsgfSk7XG4gICAgaWYgKHRoaXMuY29uZmlnLnNlc3Npb25TZWNvbmRzIC0gdGhpcy5lbGFwc2VkIDw9IDEwICYmICF0aGlzLndhcm5lZFRpbWUpIHsgdGhpcy53YXJuZWRUaW1lID0gdHJ1ZTsgdGhpcy5ldmVudHMucHVzaCgndGltZS13YXJuaW5nJyk7IH1cbiAgICBpZiAoIXRoaXMucGxheWVyLmFsaXZlIHx8IHRoaXMuZWxhcHNlZCA+PSB0aGlzLmNvbmZpZy5zZXNzaW9uU2Vjb25kcyAtIDFlLTgpIHtcbiAgICAgIHRoaXMucmVhc29uID0gdGhpcy5wbGF5ZXIuYWxpdmUgPyAndGltZScgOiAnZGVhdGgnOyB0aGlzLnN0YXR1cyA9ICdlbmRlZCc7XG4gICAgfVxuICB9XG4gIGRyYWluRXZlbnRzKCkgeyBjb25zdCBldmVudHMgPSB0aGlzLmV2ZW50czsgdGhpcy5ldmVudHMgPSBbXTsgcmV0dXJuIGV2ZW50czsgfVxuICBzbmFwc2hvdCgpOiBTbmFwc2hvdCB7IHJldHVybiB7IHN0YXR1czogdGhpcy5zdGF0dXMsIGVsYXBzZWQ6IHRoaXMuZWxhcHNlZCxcbiAgICByZW1haW5pbmc6IE1hdGgubWF4KDAsIHRoaXMuY29uZmlnLnNlc3Npb25TZWNvbmRzIC0gdGhpcy5lbGFwc2VkKSwgc2NvcmU6IHRoaXMuc2NvcmUsXG4gICAgaGVhbHRoOiB0aGlzLnBsYXllci5oZWFsdGgsIG1heEhlYWx0aDogdGhpcy5wbGF5ZXIubWF4SGVhbHRoLCBlbmVtaWVzOiB0aGlzLmVuZW1pZXMubGVuZ3RoLCByZWFzb246IHRoaXMucmVhc29uIH07IH1cbn1cbiJdfQ==